package com.motong.app.phonecontrol.accessibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

/**
 * 墨瞳辅助功能服务 — 与架构文档 4.4 一致
 *
 * 职责：
 * - 前台应用切换检测 (TYPE_WINDOW_STATE_CHANGED)
 * - 按键拦截 (Home 键等，用于应用锁定场景)
 * - onServiceConnected 时动态设置 serviceInfo
 * - onUnbind 返回 true，支持 rebind
 */
class MoTongAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        private var instance: MoTongAccessibilityService? = null

        /** 获取当前服务实例（可能为 null） */
        fun getInstance(): MoTongAccessibilityService? = instance

        /** 服务是否正在运行 */
        fun isRunning(): Boolean = instance != null
    }

    /** 应用锁定是否启用 */
    @Volatile
    var appLockEnabled: Boolean = false

    /** 前台应用变化监听器 */
    private var foregroundAppListener: ForegroundAppListener? = null

    /** 按键拦截监听器 */
    private var keyEventListener: KeyEventListener? = null

    // ──────────────────────────────────────────────
    // 生命周期
    // ──────────────────────────────────────────────

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this

        // 动态设置 serviceInfo — 架构文档 5.2 要求
        val info = AccessibilityServiceInfo().apply {
            eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or
                    AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            flags = AccessibilityServiceInfo.DEFAULT or
                    AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS or
                    AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS
            notificationTimeout = 100
        }
        serviceInfo = info
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                val packageName = event.packageName?.toString()
                if (!packageName.isNullOrEmpty()) {
                    foregroundAppListener?.onForegroundAppChanged(
                        packageName,
                        event.className?.toString()
                    )
                }
            }
        }
    }

    override fun onInterrupt() {
        // 服务中断时的清理
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        // 按键拦截逻辑 — 架构文档 4.4
        // 应用锁定启用时拦截 Home 键等
        if (appLockEnabled && shouldBlockKey(event)) {
            keyEventListener?.onKeyBlocked(event.keyCode)
            return true // 消费事件，阻止系统处理
        }
        return super.onKeyEvent(event)
    }

    /**
     * 返回 true 支持 rebind — 架构约束 #6
     */
    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        foregroundAppListener = null
        keyEventListener = null
        return true
    }

    override fun onDestroy() {
        instance = null
        foregroundAppListener = null
        keyEventListener = null
        super.onDestroy()
    }

    // ──────────────────────────────────────────────
    // 按键判断
    // ──────────────────────────────────────────────

    private fun shouldBlockKey(event: KeyEvent): Boolean {
        if (event.action != KeyEvent.ACTION_DOWN) return false
        return when (event.keyCode) {
            KeyEvent.KEYCODE_HOME,
            KeyEvent.KEYCODE_APP_SWITCH -> true
            else -> false
        }
    }

    // ──────────────────────────────────────────────
    // 内部接口
    // ──────────────────────────────────────────────

    fun interface ForegroundAppListener {
        fun onForegroundAppChanged(packageName: String, className: String?)
    }

    fun interface KeyEventListener {
        fun onKeyBlocked(keyCode: Int)
    }

    fun setForegroundAppListener(listener: ForegroundAppListener?) {
        foregroundAppListener = listener
    }

    fun setKeyEventListener(listener: KeyEventListener?) {
        keyEventListener = listener
    }
}