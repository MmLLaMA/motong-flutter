package com.motong.app.phonecontrol

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.app.usage.UsageStatsManager
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import com.motong.app.phonecontrol.accessibility.MoTongAccessibilityService
import com.motong.app.phonecontrol.admin.MoTongDeviceAdminReceiver
import io.flutter.embedding.engine.plugins.FlutterPlugin
import io.flutter.embedding.engine.plugins.activity.ActivityAware
import io.flutter.embedding.engine.plugins.activity.ActivityPluginBinding
import io.flutter.plugin.common.BinaryMessenger
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel

/**
 * 墨瞳手机控制 MethodChannel 插件 — 与架构文档 4.3 一致
 *
 * 实现 MethodCallHandler + ActivityAware，
 * 涵盖 26 个 method + EventChannel，5 种错误码。
 */
class PhoneControlPlugin : FlutterPlugin, MethodChannel.MethodCallHandler, ActivityAware {

    companion object {
        const val CHANNEL = "com.motong/phone_control"
        const val FOREGROUND_APP_CHANNEL = "com.motong/phone_control/foreground_app"

        // 错误码 — 架构文档 3.3
        const val ERR_PERMISSION_DENIED = "PERMISSION_DENIED"
        const val ERR_DEVICE_NOT_SUPPORTED = "DEVICE_NOT_SUPPORTED"
        const val ERR_SERVICE_UNAVAILABLE = "SERVICE_UNAVAILABLE"
        const val ERR_INVALID_ARGUMENT = "INVALID_ARGUMENT"
        const val ERR_UNKNOWN = "UNKNOWN"
    }

    private var channel: MethodChannel? = null
    private var eventChannel: EventChannel? = null
    private var eventSink: EventChannel.EventSink? = null
    private var context: Context? = null
    private var activity: Activity? = null

    // ──────────────────────────────────────────────
    // FlutterPlugin
    // ──────────────────────────────────────────────

    override fun onAttachedToEngine(binding: FlutterPlugin.FlutterPluginBinding) {
        context = binding.applicationContext
        val messenger = binding.binaryMessenger
        channel = MethodChannel(messenger, CHANNEL)
        channel?.setMethodCallHandler(this)

        eventChannel = EventChannel(messenger, FOREGROUND_APP_CHANNEL)
        eventChannel?.setStreamHandler(object : EventChannel.StreamHandler {
            override fun onListen(arguments: Any?, events: EventChannel.EventSink?) {
                eventSink = events
            }

            override fun onCancel(arguments: Any?) {
                eventSink = null
            }
        })
    }

    override fun onDetachedFromEngine(binding: FlutterPlugin.FlutterPluginBinding) {
        channel?.setMethodCallHandler(null)
        channel = null
        eventChannel?.setStreamHandler(null)
        eventChannel = null
        eventSink = null
        context = null
    }

    // ──────────────────────────────────────────────
    // ActivityAware
    // ──────────────────────────────────────────────

    override fun onAttachedToActivity(binding: ActivityPluginBinding) {
        activity = binding.activity
    }

    override fun onDetachedFromActivityForConfigChanges() {
        activity = null
    }

    override fun onReattachedToActivityForConfigChanges(binding: ActivityPluginBinding) {
        activity = binding.activity
    }

    override fun onDetachedFromActivity() {
        activity = null
    }

    // ──────────────────────────────────────────────
    // MethodCallHandler — 26 methods
    // ──────────────────────────────────────────────

    override fun onMethodCall(call: MethodCall, result: MethodChannel.Result) {
        try {
            when (call.method) {
                // 权限类 (9) — 架构文档 3.2.1
                "getPermissionsStatus" -> handleGetPermissionsStatus(result)
                "requestAccessibilityPermission" -> handleRequestAccessibility(result)
                "requestDeviceAdminPermission" -> handleRequestDeviceAdmin(result)
                "requestOverlayPermission" -> handleRequestOverlay(result)
                "requestUsageStatsPermission" -> handleRequestUsageStats(result)
                "isAccessibilityServiceEnabled" -> handleIsAccessibilityEnabled(result)
                "isDeviceAdminActive" -> handleIsDeviceAdminActive(result)
                "isOverlayPermissionGranted" -> handleIsOverlayGranted(result)
                "isUsageStatsPermissionGranted" -> handleIsUsageStatsGranted(result)

                // 设备控制类 (7) — 架构文档 3.2.2
                "lockScreen" -> handleLockScreen(result)
                "lockScreenWithCountdown" -> handleLockScreenWithCountdown(call, result)
                "setScreenTimeout" -> handleSetScreenTimeout(call, result)
                "getScreenTimeout" -> handleGetScreenTimeout(result)
                "setScreenBrightness" -> handleSetScreenBrightness(call, result)
                "getScreenBrightness" -> handleGetScreenBrightness(result)
                "isScreenLocked" -> handleIsScreenLocked(result)

                // 应用锁定类 (5) — 架构文档 3.2.3
                "getInstalledApps" -> handleGetInstalledApps(result)
                "setAppLockWhitelist" -> handleSetAppLockWhitelist(call, result)
                "getAppLockWhitelist" -> handleGetAppLockWhitelist(result)
                "setAppLockEnabled" -> handleSetAppLockEnabled(call, result)
                "isAppLockEnabled" -> handleIsAppLockEnabled(result)

                // 前台应用监听类 (3) — 架构文档 3.2.4
                "startForegroundAppMonitoring" -> handleStartMonitoring(result)
                "stopForegroundAppMonitoring" -> handleStopMonitoring(result)
                "getCurrentForegroundApp" -> handleGetCurrentForegroundApp(result)

                else -> result.notImplemented()
            }
        } catch (e: Exception) {
            result.error(ERR_UNKNOWN, e.message, null)
        }
    }

    // ──────────────────────────────────────────────
    // 权限类 handlers
    // ──────────────────────────────────────────────

    private fun handleGetPermissionsStatus(result: MethodChannel.Result) {
        val ctx = context ?: run { result.error(ERR_UNKNOWN, "context null", null); return }
        val map = mapOf(
            "accessibility" to MoTongAccessibilityService.isRunning(),
            "deviceAdmin" to MoTongDeviceAdminReceiver.isActive(ctx),
            "overlay" to (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(ctx)),
            "usageStats" to isUsageStatsGranted(ctx)
        )
        result.success(map)
    }

    private fun handleRequestAccessibility(result: MethodChannel.Result) {
        val act = activity ?: run { result.error(ERR_UNKNOWN, "activity null", null); return }
        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
        act.startActivity(intent)
        result.success(MoTongAccessibilityService.isRunning())
    }

    private fun handleRequestDeviceAdmin(result: MethodChannel.Result) {
        val act = activity ?: run { result.error(ERR_UNKNOWN, "activity null", null); return }
        try {
            val intent = Intent(android.app.admin.DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                putExtra(
                    android.app.admin.DevicePolicyManager.EXTRA_DEVICE_ADMIN,
                    android.content.ComponentName(act, MoTongDeviceAdminReceiver::class.java)
                )
                putExtra(
                    android.app.admin.DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                    "墨瞳需要设备管理器权限以实现远程锁屏等安全功能"
                )
            }
            act.startActivity(intent)
            result.success(MoTongDeviceAdminReceiver.isActive(act))
        } catch (e: Exception) {
            result.error(ERR_DEVICE_NOT_SUPPORTED, e.message, null)
        }
    }

    private fun handleRequestOverlay(result: MethodChannel.Result) {
        val act = activity ?: run { result.error(ERR_UNKNOWN, "activity null", null); return }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(act)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:${act.packageName}")
            )
            act.startActivity(intent)
        }
        result.success(
            Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(act)
        )
    }

    private fun handleRequestUsageStats(result: MethodChannel.Result) {
        val act = activity ?: run { result.error(ERR_UNKNOWN, "activity null", null); return }
        val intent = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
        act.startActivity(intent)
        result.success(isUsageStatsGranted(act))
    }

    private fun handleIsAccessibilityEnabled(result: MethodChannel.Result) {
        result.success(MoTongAccessibilityService.isRunning())
    }

    private fun handleIsDeviceAdminActive(result: MethodChannel.Result) {
        val ctx = context ?: run { result.error(ERR_UNKNOWN, "context null", null); return }
        result.success(MoTongDeviceAdminReceiver.isActive(ctx))
    }

    private fun handleIsOverlayGranted(result: MethodChannel.Result) {
        val ctx = context ?: run { result.error(ERR_UNKNOWN, "context null", null); return }
        result.success(
            Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(ctx)
        )
    }

    private fun handleIsUsageStatsGranted(result: MethodChannel.Result) {
        val ctx = context ?: run { result.error(ERR_UNKNOWN, "context null", null); return }
        result.success(isUsageStatsGranted(ctx))
    }

    // ──────────────────────────────────────────────
    // 设备控制类 handlers
    // ──────────────────────────────────────────────

    private fun handleLockScreen(result: MethodChannel.Result) {
        val ctx = context ?: run { result.error(ERR_UNKNOWN, "context null", null); return }
        result.success(MoTongDeviceAdminReceiver.lockNow(ctx))
    }

    private fun handleLockScreenWithCountdown(call: MethodCall, result: MethodChannel.Result) {
        val seconds = call.argument<Int>("seconds") ?: 0
        val ctx = context ?: run { result.error(ERR_UNKNOWN, "context null", null); return }
        // 原生不做倒计时，由 Flutter 侧 UI 倒计时后调用 lockScreen
        // 这里直接锁屏或返回确认即可
        result.success(MoTongDeviceAdminReceiver.lockNow(ctx))
    }

    private fun handleSetScreenTimeout(call: MethodCall, result: MethodChannel.Result) {
        val millis = call.argument<Int>("millis") ?: return result.error(
            ERR_INVALID_ARGUMENT, "millis is required", null
        )
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (Settings.System.canWrite(context)) {
                    Settings.System.putInt(
                        context?.contentResolver,
                        Settings.System.SCREEN_OFF_TIMEOUT,
                        millis
                    )
                    result.success(true)
                } else {
                    result.error(ERR_PERMISSION_DENIED, "WRITE_SETTINGS not granted", null)
                }
            } else {
                Settings.System.putInt(
                    context?.contentResolver,
                    Settings.System.SCREEN_OFF_TIMEOUT,
                    millis
                )
                result.success(true)
            }
        } catch (e: SecurityException) {
            result.error(ERR_PERMISSION_DENIED, e.message, null)
        }
    }

    private fun handleGetScreenTimeout(result: MethodChannel.Result) {
        try {
            val timeout = Settings.System.getInt(
                context?.contentResolver,
                Settings.System.SCREEN_OFF_TIMEOUT,
                30000
            )
            result.success(timeout)
        } catch (e: Exception) {
            result.error(ERR_UNKNOWN, e.message, null)
        }
    }

    private fun handleSetScreenBrightness(call: MethodCall, result: MethodChannel.Result) {
        val brightness = call.argument<Int>("brightness") ?: return result.error(
            ERR_INVALID_ARGUMENT, "brightness is required (0-255)", null
        )
        if (brightness !in 0..255) {
            return result.error(
                ERR_INVALID_ARGUMENT, "brightness must be 0-255, got $brightness", null
            )
        }
        val act = activity
        if (act == null) {
            result.error(ERR_UNKNOWN, "activity null — cannot set brightness", null)
            return
        }
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (!Settings.System.canWrite(context)) {
                    result.error(ERR_PERMISSION_DENIED, "WRITE_SETTINGS not granted", null)
                    return
                }
            }
            val params = act.window.attributes
            params.screenBrightness = brightness / 255f
            act.window.attributes = params
            result.success(true)
        } catch (e: SecurityException) {
            result.error(ERR_PERMISSION_DENIED, e.message, null)
        }
    }

    private fun handleGetScreenBrightness(result: MethodChannel.Result) {
        try {
            val raw = Settings.System.getInt(
                context?.contentResolver,
                Settings.System.SCREEN_BRIGHTNESS,
                128
            )
            result.success(raw)
        } catch (e: Exception) {
            result.error(ERR_UNKNOWN, e.message, null)
        }
    }

    private fun handleIsScreenLocked(result: MethodChannel.Result) {
        try {
            val km = context?.getSystemService(Context.KEYGUARD_SERVICE)
                    as? android.app.KeyguardManager
            result.success(km?.isKeyguardLocked ?: false)
        } catch (e: Exception) {
            result.error(ERR_UNKNOWN, e.message, null)
        }
    }

    // ──────────────────────────────────────────────
    // 应用锁定类 handlers
    // ──────────────────────────────────────────────

    private fun handleGetInstalledApps(result: MethodChannel.Result) {
        val ctx = context ?: run { result.error(ERR_UNKNOWN, "context null", null); return }
        try {
            val pm = ctx.packageManager
            val packages = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            val list = packages.map { appInfo ->
                mapOf(
                    "packageName" to (appInfo.packageName ?: ""),
                    "appName" to (pm.getApplicationLabel(appInfo).toString())
                )
            }
            result.success(list)
        } catch (e: Exception) {
            result.error(ERR_UNKNOWN, e.message, null)
        }
    }

    private fun handleSetAppLockWhitelist(call: MethodCall, result: MethodChannel.Result) {
        val packageNames = call.argument<List<String>>("packageNames") ?: return result.error(
            ERR_INVALID_ARGUMENT, "packageNames is required", null
        )
        // 白名单持久化由 Flutter 侧 Drift 管理
        // 原生侧仅验证格式，返回成功
        result.success(true)
    }

    private fun handleGetAppLockWhitelist(result: MethodChannel.Result) {
        // 白名单由 Flutter 侧从 Drift 读取后传入
        // 原生侧返回空列表，实际数据由 Flutter 维护
        result.success(emptyList<String>())
    }

    private var _appLockEnabled = false

    private fun handleSetAppLockEnabled(call: MethodCall, result: MethodChannel.Result) {
        val enabled = call.argument<Boolean>("enabled") ?: return result.error(
            ERR_INVALID_ARGUMENT, "enabled is required", null
        )
        _appLockEnabled = enabled
        MoTongAccessibilityService.getInstance()?.appLockEnabled = enabled
        result.success(true)
    }

    private fun handleIsAppLockEnabled(result: MethodChannel.Result) {
        result.success(_appLockEnabled)
    }

    // ──────────────────────────────────────────────
    // 前台应用监听类 handlers
    // ──────────────────────────────────────────────

    private fun handleStartMonitoring(result: MethodChannel.Result) {
        val service = MoTongAccessibilityService.getInstance()
        if (service == null) {
            result.error(ERR_SERVICE_UNAVAILABLE, "AccessibilityService not running", null)
            return
        }
        service.setForegroundAppListener { packageName, className ->
            eventSink?.success(mapOf(
                "packageName" to packageName,
                "className" to (className ?: "")
            ))
        }
        result.success(true)
    }

    private fun handleStopMonitoring(result: MethodChannel.Result) {
        MoTongAccessibilityService.getInstance()?.setForegroundAppListener(null)
        result.success(true)
    }

    private fun handleGetCurrentForegroundApp(result: MethodChannel.Result) {
        val ctx = context ?: run { result.error(ERR_UNKNOWN, "context null", null); return }
        try {
            if (!isUsageStatsGranted(ctx)) {
                result.error(ERR_PERMISSION_DENIED, "UsageStats permission not granted", null)
                return
            }
            val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager
                ?: run { result.error(ERR_DEVICE_NOT_SUPPORTED, "UsageStatsManager unavailable", null); return }

            val now = System.currentTimeMillis()
            val stats = usm.queryUsageStats(
                UsageStatsManager.INTERVAL_DAILY,
                now - 60000,
                now
            )
            val top = stats.maxByOrNull { it.lastTimeUsed }
            result.success(top?.packageName)
        } catch (e: SecurityException) {
            result.error(ERR_PERMISSION_DENIED, e.message, null)
        } catch (e: Exception) {
            result.error(ERR_UNKNOWN, e.message, null)
        }
    }

    // ──────────────────────────────────────────────
    // 工具方法
    // ──────────────────────────────────────────────

    private fun isUsageStatsGranted(context: Context): Boolean {
        return try {
            val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as? android.app.AppOpsManager
            if (appOps != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                val mode = appOps.checkOpNoThrow(
                    android.app.AppOpsManager.OPSTR_GET_USAGE_STATS,
                    android.os.Process.myUid(),
                    context.packageName
                )
                mode == android.app.AppOpsManager.MODE_ALLOWED
            } else {
                // API < 19 无需此权限
                true
            }
        } catch (e: Exception) {
            false
        }
    }
}