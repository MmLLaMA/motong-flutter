package com.motong

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
