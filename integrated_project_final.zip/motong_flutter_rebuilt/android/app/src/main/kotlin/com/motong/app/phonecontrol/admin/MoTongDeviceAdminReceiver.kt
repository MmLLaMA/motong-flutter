package com.motong.app.phonecontrol.admin

import android.app.admin.DeviceAdminReceiver
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.util.Log

/**
 * 墨瞳设备管理接收器 — 与架构文档 5.1 一致
 *
 * 处理设备管理事件（激活/停用），
 * 提供 lockNow 带 SecurityException 保护。
 */
class MoTongDeviceAdminReceiver : DeviceAdminReceiver() {

    companion object {
        private const val TAG = "MoTongDeviceAdmin"

        /**
         * 安全锁屏 — 带 SecurityException 保护
         *
         * 架构约束 #5：lockNow 带 SecurityException 保护
         */
        fun lockNow(context: Context): Boolean {
            return try {
                val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE)
                        as? DevicePolicyManager ?: return false
                val component = ComponentName(context, MoTongDeviceAdminReceiver::class.java)
                if (dpm.isAdminActive(component)) {
                    dpm.lockNow()
                    true
                } else {
                    Log.w(TAG, "lockNow failed: DeviceAdmin not active")
                    false
                }
            } catch (e: SecurityException) {
                Log.e(TAG, "lockNow SecurityException: ${e.message}")
                false
            } catch (e: Exception) {
                Log.e(TAG, "lockNow failed: ${e.message}")
                false
            }
        }

        /**
         * 检查设备管理器是否已激活
         */
        fun isActive(context: Context): Boolean {
            return try {
                val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE)
                        as? DevicePolicyManager ?: return false
                val component = ComponentName(context, MoTongDeviceAdminReceiver::class.java)
                dpm.isAdminActive(component)
            } catch (e: Exception) {
                Log.e(TAG, "isActive check failed: ${e.message}")
                false
            }
        }
    }

    override fun onEnabled(context: Context, intent: Intent) {
        super.onEnabled(context, intent)
        Log.i(TAG, "DeviceAdmin enabled")
    }

    override fun onDisabled(context: Context, intent: Intent) {
        super.onDisabled(context, intent)
        Log.i(TAG, "DeviceAdmin disabled")
    }
}