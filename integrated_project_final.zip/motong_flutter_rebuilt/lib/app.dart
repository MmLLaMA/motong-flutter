/// 墨瞳应用入口（v3.1.0）
/// - MultiProvider 注册所有管理器 + Provider
/// - GoRouter 注册所有路由
/// - themeMode 监听 SettingsProvider
/// - AppDatabase 初始化 + 注入到 MemoryProvider
/// - 模块 4：PhoneControlProvider 初始化权限检测

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:go_router/go_router.dart';

import 'core/providers/provider_manager.dart';
import 'core/providers/assistant_manager.dart';
import 'core/providers/chat_provider.dart';
import 'core/providers/settings_provider.dart';
import 'core/providers/memory_provider.dart';
import 'features/phone_control/providers/phone_control_provider.dart';
import 'features/phone_control/ui/phone_control_page.dart';
import 'features/webdav_backup/providers/webdav_provider.dart';
import 'features/webdav_backup/providers/backup_provider.dart';
import 'features/webdav_backup/providers/restore_provider.dart';
import 'features/webdav_backup/services/backup_service.dart';
import 'features/webdav_backup/services/restore_service.dart';
import 'features/webdav_backup/models/models.dart';
import 'features/webdav_backup/ui/backup_control_page.dart';
import 'features/webdav_backup/ui/restore_page.dart';
import 'features/webdav_backup/ui/webdav_config_page.dart';

import 'features/memory/data/memory_database.dart';
import 'features/memory/data/memory_dao.dart';
import 'features/memory/data/memory_repository.dart';
import 'features/memory/services/memory_manager.dart';
import 'features/memory/services/memory_extractor.dart';
import 'features/memory/services/memory_retriever.dart';
import 'features/memory/services/memory_injector.dart';

import 'features/chat/pages/chat_page.dart';
import 'features/agents/pages/providers_page.dart';
import 'features/agents/pages/assistants_page.dart';
import 'features/settings/models/app_settings.dart';
import 'features/settings/pages/settings_page.dart';
import 'features/settings/pages/appearance_page.dart';
import 'features/settings/pages/voice_page.dart';
import 'features/settings/pages/conversation_page.dart';
import 'features/settings/pages/proxy_page.dart';
import 'features/settings/pages/about_page.dart';
import 'features/settings/pages/data_storage_page.dart';
import 'features/settings/pages/advanced_settings_page.dart';
import 'features/settings/pages/quick_phrases_page.dart';
import 'features/settings/pages/default_model_page.dart';
import 'features/settings/pages/chat_records_page.dart';
import 'features/settings/pages/webdav_page.dart';
import 'features/settings/pages/docs_page.dart';
import 'features/settings/pages/logs_page.dart';
import 'features/memory/ui/memory_page.dart';

class MotongApp extends StatefulWidget {
  const MotongApp({super.key});

  @override
  State<MotongApp> createState() => _MotongAppState();
}

class _MotongAppState extends State<MotongApp> {
  late final ProviderManager _providerManager;
  late final AssistantManager _assistantManager;
  late final SettingsProvider _settingsProvider;
  late final ChatProvider _chatProvider;
  late final MemoryProvider _memoryProvider;
  late final PhoneControlProvider _phoneControlProvider;
  late final WebDavProvider _webDavProvider;
  late final BackupProvider _backupProvider;
  late final RestoreProvider _restoreProvider;
  late final AppDatabase _memoryDb;
  late final GoRouter _router;

  @override
  void initState() {
    super.initState();
    // 1. 初始化所有 Provider
    _providerManager = ProviderManager();
    _assistantManager = AssistantManager();
    _settingsProvider = SettingsProvider();
    _chatProvider = ChatProvider(
      providerManager: _providerManager,
      assistantManager: _assistantManager,
      settingsProvider: _settingsProvider,
    );

    // 2. 初始化记忆数据库
    _memoryDb = AppDatabase();
    final memoryDao = MemoryDao(_memoryDb);
    final memoryRepo = MemoryRepository(memoryDao);
    final memoryManager = MemoryManager.instance;

    // 3. 初始化 MemoryProvider
    _memoryProvider = MemoryProvider();

    // 4. 初始化 PhoneControlProvider（模块 4）
    _phoneControlProvider = PhoneControlProvider();

    // 5. 初始化 WebDAV / Backup / Restore Provider（模块 6）
    _webDavProvider = WebDavProvider()..init();
    _backupProvider = BackupProvider(backupService: BackupService());
    _restoreProvider = RestoreProvider(restoreService: RestoreService());

    // 6. 注册路由
    _router = _buildRouter();

    // 7. 异步初始化子模块（不影响 UI 首屏）
    _initializeMemory(memoryManager, memoryRepo);
    _phoneControlProvider.initialize();
  }

  Future<void> _initializeMemory(
    MemoryManager manager,
    MemoryRepository repo,
  ) async {
    await manager.init(database: _memoryDb);
    // 注入提取器
    // 提取器需要 llmChat 函数 + fetchMessages 函数
    // 这里用占位实现，真实场景由 ChatProvider 提供
    final retriever = MemoryRetriever(repo);
    final injector = MemoryInjector();
    final extractor = MemoryExtractor(
      repository: repo,
      llmChat: _placeholderLlmChat,
      fetchUnprocessedMessages: _placeholderFetchMessages,
    );
    manager.attachComponents(
      retriever: retriever,
      injector: injector,
      extractor: extractor,
    );
    await _memoryProvider.init(repository: repo);
  }

  // ========== 占位 LLM 调用（待 ChatProvider 注入真实实现） ==========

  Future<String> _placeholderLlmChat({
    required List<Map<String, String>> messages,
    double temperature = 1.0,
  }) async {
    return '[]';
  }

  Future<List<Map<String, dynamic>>> _placeholderFetchMessages(
    String conversationId,
  ) async {
    return [];
  }

  GoRouter _buildRouter() {
    return GoRouter(
      initialLocation: '/chat',
      routes: [
        GoRoute(path: '/chat', builder: (_, __) => const ChatPage()),
        GoRoute(path: '/settings', builder: (_, __) => const SettingsPage()),
        GoRoute(path: '/settings/appearance', builder: (_, __) => const AppearancePage()),
        GoRoute(path: '/settings/voice', builder: (_, __) => const VoicePage()),
        GoRoute(path: '/settings/conversation', builder: (_, __) => const ConversationPage()),
        GoRoute(path: '/settings/proxy', builder: (_, __) => const ProxyPage()),
        GoRoute(path: '/settings/phone-control', builder: (_, __) => const PhoneControlPage()),
        // 模块 6：WebDAV 备份路由
        GoRoute(path: '/backup', builder: (_, __) => const BackupControlPage()),
        GoRoute(
          path: '/backup/restore',
          builder: (_, state) {
            final pre = state.extra;
            return RestorePage(preselectedFile: pre is String ? pre : null);
          },
        ),
        GoRoute(
          path: '/backup/webdav-config',
          builder: (_, state) {
            final cfg = state.extra;
            return WebDavConfigPage(existingConfig: cfg is WebDavConfig ? cfg : null);
          },
        ),
        GoRoute(path: '/settings/about', builder: (_, __) => const AboutPage()),
        GoRoute(path: '/settings/data-storage', builder: (_, __) => const DataStoragePage()),
        GoRoute(path: '/settings/advanced', builder: (_, __) => const AdvancedSettingsPage()),
        GoRoute(path: '/settings/quick-phrases', builder: (_, __) => const QuickPhrasesPage()),
        GoRoute(path: '/settings/default-model', builder: (_, __) => const DefaultModelPage()),
        GoRoute(path: '/settings/chat-records', builder: (_, __) => const ChatRecordsPage()),
        GoRoute(path: '/settings/webdav', builder: (_, __) => const WebDavPage()),
        GoRoute(path: '/settings/docs', builder: (_, __) => const DocsPage()),
        GoRoute(path: '/settings/logs', builder: (_, __) => const LogsPage()),
        GoRoute(path: '/settings/data-storage/memory', builder: (_, __) => const MemoryPage()),
        GoRoute(path: '/providers', builder: (_, __) => const ProvidersPage()),
        GoRoute(path: '/assistants', builder: (_, __) => const AssistantsPage()),
        GoRoute(path: '/memory', builder: (_, __) => const MemoryPage()),
      ],
    );
  }

  @override
  void dispose() {
    _providerManager.dispose();
    _assistantManager.dispose();
    _settingsProvider.dispose();
    _chatProvider.dispose();
    _memoryProvider.dispose();
    _phoneControlProvider.dispose();
    _webDavProvider.dispose();
    _backupProvider.dispose();
    _restoreProvider.dispose();
    _memoryDb.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider.value(value: _providerManager),
        ChangeNotifierProvider.value(value: _assistantManager),
        ChangeNotifierProvider.value(value: _settingsProvider),
        ChangeNotifierProvider.value(value: _chatProvider),
        ChangeNotifierProvider.value(value: _memoryProvider),
        ChangeNotifierProvider.value(value: _phoneControlProvider),
        // 模块 6：WebDAV / Backup / Restore
        ChangeNotifierProvider.value(value: _webDavProvider),
        ChangeNotifierProvider.value(value: _backupProvider),
        ChangeNotifierProvider.value(value: _restoreProvider),
      ],
      child: Consumer<SettingsProvider>(
        builder: (context, settings, _) {
          return MaterialApp.router(
            title: '墨瞳',
            debugShowCheckedModeBanner: false,
            theme: ThemeData(
              colorScheme: ColorScheme.fromSeed(
                seedColor: const Color(0xFF6B8E9F),
                brightness: Brightness.light,
              ),
              useMaterial3: true,
              appBarTheme: const AppBarTheme(centerTitle: true),
            ),
            darkTheme: ThemeData(
              colorScheme: ColorScheme.fromSeed(
                seedColor: const Color(0xFF6B8E9F),
                brightness: Brightness.dark,
              ),
              useMaterial3: true,
              appBarTheme: const AppBarTheme(centerTitle: true),
            ),
            themeMode: _toThemeMode(settings.colorMode),
            routerConfig: _router,
          );
        },
      ),
    );
  }

  ThemeMode _toThemeMode(AppColorMode mode) {
    switch (mode) {
      case AppColorMode.system:
        return ThemeMode.system;
      case AppColorMode.light:
        return ThemeMode.light;
      case AppColorMode.dark:
        return ThemeMode.dark;
      default:
        return ThemeMode.system;
    }
  }
}