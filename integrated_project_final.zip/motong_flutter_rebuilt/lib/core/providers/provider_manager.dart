/// 供应商管理器
/// 管理 LlmProvider 实例的 CRUD + ChangeNotifier

import 'package:flutter/foundation.dart';
import 'package:uuid/uuid.dart';
import '../../features/agents/models/provider.dart';
import '../network/llm_provider.dart';

class ProviderManager extends ChangeNotifier {
  final List<LlmProvider> _providers = [];
  final Map<String, OpenAiCompatibleProvider> _activeClients = {};

  List<LlmProvider> get providers => List.unmodifiable(_providers);

  ProviderManager() {
    _initBuiltinProviders();
  }

  // ========== 内置供应商 ==========

  void _initBuiltinProviders() {
    _providers.addAll([
      LlmProvider(
        id: 'builtin-deepseek',
        name: 'DeepSeek',
        baseUrl: 'https://api.deepseek.com',
        apiKey: '',
        isBuiltin: true,
        models: [
          ModelInfo(
            id: 'deepseek-chat',
            displayName: 'DeepSeek V3',
            maxTokens: 65536,
          ),
          ModelInfo(
            id: 'deepseek-reasoner',
            displayName: 'DeepSeek R1',
            maxTokens: 65536,
          ),
        ],
      ),
      LlmProvider(
        id: 'builtin-zhipu',
        name: '智谱 AI',
        baseUrl: 'https://open.bigmodel.cn/api/paas/v4',
        apiKey: '',
        isBuiltin: true,
        models: [
          ModelInfo(
            id: 'glm-4-flash',
            displayName: 'GLM-4 Flash',
            maxTokens: 32768,
          ),
          ModelInfo(
            id: 'glm-4-plus',
            displayName: 'GLM-4 Plus',
            maxTokens: 128000,
          ),
        ],
      ),
    ]);
  }

  // ========== CRUD ==========

  void addProvider(LlmProvider provider) {
    _providers.add(provider);
    notifyListeners();
  }

  void updateProvider(String id, LlmProvider updated) {
    final idx = _providers.indexWhere((p) => p.id == id);
    if (idx == -1) return;
    _providers[idx] = updated;
    _activeClients.remove(id);
    notifyListeners();
  }

  void deleteProvider(String id) {
    final provider = _providers.firstWhere((p) => p.id == id);
    if (provider.isBuiltin) return; // 内置供应商禁止删除
    _providers.removeWhere((p) => p.id == id);
    _activeClients.remove(id)?.dispose();
    notifyListeners();
  }

  // ========== 客户端管理 ==========

  /// 为指定供应商+模型构建 LlmProvider 实例
  OpenAiCompatibleProvider buildProviderForModel({
    required String providerId,
    String? modelOverride,
  }) {
    final provider = _providers.firstWhere(
      (p) => p.id == providerId,
      orElse: () => _providers.first,
    );
    final key = '$providerId:${modelOverride ?? 'default'}';

    return _activeClients.putIfAbsent(key, () {
      return OpenAiCompatibleProvider(
        baseUrl: provider.baseUrl,
        apiKey: provider.apiKey,
        defaultModel: modelOverride ?? provider.models.first.id,
      );
    });
  }

  LlmProvider? getProvider(String id) {
    try {
      return _providers.firstWhere((p) => p.id == id);
    } catch (_) {
      return null;
    }
  }

  /// 测试供应商连接
  Future<bool> testProviderConnection(String id) async {
    final p = getProvider(id);
    if (p == null) return false;
    final client = OpenAiCompatibleProvider(
      baseUrl: p.baseUrl,
      apiKey: p.apiKey,
    );
    try {
      final result = await client.testConnection();
      client.dispose();
      return result;
    } catch (_) {
      client.dispose();
      return false;
    }
  }

  @override
  void dispose() {
    for (final c in _activeClients.values) {
      c.dispose();
    }
    _activeClients.clear();
    super.dispose();
  }
}