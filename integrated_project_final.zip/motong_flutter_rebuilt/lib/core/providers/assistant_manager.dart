/// 助手管理器
/// 管理 Assistant 的 CRUD + 切换 + 当前助手状态

import 'package:flutter/foundation.dart';
import '../../features/agents/models/provider.dart';

class AssistantManager extends ChangeNotifier {
  final List<Assistant> _assistants = [];
  String? _currentAssistantId;

  List<Assistant> get assistants => List.unmodifiable(_assistants);

  String? get currentAssistantId => _currentAssistantId;

  Assistant? get currentAssistant {
    if (_assistants.isEmpty) return null;
    if (_currentAssistantId == null) return _assistants.first;
    return _assistants.firstWhere(
      (a) => a.id == _currentAssistantId,
      orElse: () => _assistants.first,
    );
  }

  AssistantManager() {
    _initDefaultAssistant();
  }

  void _initDefaultAssistant() {
    // 创建一个默认助手
    final defaultAssistant = Assistant(
      name: '墨瞳',
      emoji: '👁️',
      modelProviderId: 'builtin-deepseek',
      modelId: 'deepseek-chat',
      systemPrompt: '你是墨瞳，一个温暖、善解人意的 AI 陪伴助手。请用自然流畅的中文回复，保持友好亲切的语气。',
      isDefault: true,
    );
    _assistants.add(defaultAssistant);
    _currentAssistantId = defaultAssistant.id;
  }

  // ========== 切换助手 ==========

  void switchAssistant(String assistantId) {
    if (_assistants.any((a) => a.id == assistantId)) {
      _currentAssistantId = assistantId;
      notifyListeners();
    }
  }

  // ========== CRUD ==========

  void addAssistant(Assistant assistant) {
    _assistants.add(assistant);
    notifyListeners();
  }

  void updateAssistant(String id, Assistant updated) {
    final idx = _assistants.indexWhere((a) => a.id == id);
    if (idx == -1) return;
    _assistants[idx] = updated;
    notifyListeners();
  }

  void deleteAssistant(String id) {
    final a = _assistants.firstWhere((x) => x.id == id);
    if (a.isDefault) return;
    _assistants.removeWhere((x) => x.id == id);
    if (_currentAssistantId == id) {
      _currentAssistantId = _assistants.isNotEmpty ? _assistants.first.id : null;
    }
    notifyListeners();
  }

  // ========== 对话管理 ==========

  void addConversation(String assistantId, Conversation conversation) {
    final idx = _assistants.indexWhere((a) => a.id == assistantId);
    if (idx == -1) return;
    final a = _assistants[idx];
    final conversations = List<Conversation>.from(a.conversations)
      ..add(conversation);
    _assistants[idx] = a.copyWith(
      conversations: conversations,
      currentConversationIndex: conversations.length - 1,
    );
    notifyListeners();
  }

  void switchConversation(String assistantId, int index) {
    final idx = _assistants.indexWhere((a) => a.id == assistantId);
    if (idx == -1) return;
    _assistants[idx] =
        _assistants[idx].copyWith(currentConversationIndex: index);
    notifyListeners();
  }
}