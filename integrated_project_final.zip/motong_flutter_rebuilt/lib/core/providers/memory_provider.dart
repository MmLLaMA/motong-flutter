/// 模块 3 — re-export 以兼容 core/providers 路径
export '../../features/memory/providers/memory_provider.dart';