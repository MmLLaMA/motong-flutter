/// 聊天状态管理（模块 2 + 模块 3 集成版）
/// 支持多对话、多助手、按 conversationId 隔离
/// 通过 ProviderManager 构建 LlmProvider 实例

import 'package:flutter/foundation.dart';
import 'package:uuid/uuid.dart';
import '../../features/chat/models/message.dart';
import '../../features/agents/models/provider.dart';
import '../network/llm_provider.dart';
import 'provider_manager.dart';
import 'assistant_manager.dart';
import 'settings_provider.dart';

class ChatProvider extends ChangeNotifier {
  final ProviderManager _providerManager;
  final AssistantManager _assistantManager;
  final SettingsProvider? _settingsProvider;
  final Uuid _uuid = const Uuid();

  /// 按 conversationId 隔离的消息列表
  final Map<String, List<Message>> _messagesByConversation = {};

  /// 当前助手 ID
  String? _currentAssistantId;
  String? get currentAssistantId => _currentAssistantId;

  /// 当前对话 ID
  String? _currentConversationId;
  String? get currentConversationId => _currentConversationId;

  /// 当前对话的消息列表
  List<Message> get messages {
    if (_currentConversationId == null) return [];
    return List.unmodifiable(
        _messagesByConversation[_currentConversationId] ?? []);
  }

  /// 是否正在等待 AI 回复
  bool _isLoading = false;
  bool get isLoading => _isLoading;

  /// 当前流式输出内容
  String _streamingContent = '';
  String get streamingContent => _streamingContent;

  String? _streamingMessageId;
  String? get streamingMessageId => _streamingMessageId;

  ChatProvider({
    required ProviderManager providerManager,
    required AssistantManager assistantManager,
    SettingsProvider? settingsProvider,
  })  : _providerManager = providerManager,
        _assistantManager = assistantManager,
        _settingsProvider = settingsProvider {
    _initCurrentAssistant();
  }

  void _initCurrentAssistant() {
    final current = _assistantManager.currentAssistant;
    if (current != null) {
      _currentAssistantId = current.id;
      _currentConversationId = current.currentConversation.id;
    }
  }

  /// 切换到指定助手
  void switchAssistant(String assistantId) {
    final assistant = _assistantManager.assistants
        .where((a) => a.id == assistantId)
        .firstOrNull;
    if (assistant == null) return;
    _assistantManager.switchAssistant(assistantId);
    _currentAssistantId = assistantId;
    _currentConversationId = assistant.currentConversation.id;
    notifyListeners();
  }

  /// 切换到指定对话
  void switchConversation(String assistantId, int index) {
    final assistant = _assistantManager.assistants
        .where((a) => a.id == assistantId)
        .firstOrNull;
    if (assistant == null) return;
    if (index < 0 || index >= assistant.conversations.length) return;
    _assistantManager.switchConversation(assistantId, index);
    _currentAssistantId = assistantId;
    _currentConversationId = assistant.conversations[index].id;
    notifyListeners();
  }

  // ========== 消息发送 ==========

  Future<void> sendMessage(String content) async {
    if (content.trim().isEmpty) return;
    final conversationId = _currentConversationId;
    if (conversationId == null) return;

    final currentAssistant = _assistantManager.currentAssistant;
    if (currentAssistant == null) return;

    // 创建并添加用户消息
    final userMessage = Message(
      id: _uuid.v4(),
      conversationId: conversationId,
      role: MessageRole.user,
      content: content.trim(),
    );
    (_messagesByConversation[conversationId] ??= []).add(userMessage);
    notifyListeners();

    // 创建占位 AI 消息
    final assistantMessageId = _uuid.v4();
    final assistantMessage = Message(
      id: assistantMessageId,
      conversationId: conversationId,
      role: MessageRole.assistant,
      content: '',
      parentMessageId: userMessage.id,
      status: MessageStatus.streaming,
    );
    (_messagesByConversation[conversationId] ??= []).add(assistantMessage);
    _streamingMessageId = assistantMessageId;
    _streamingContent = '';
    _isLoading = true;
    notifyListeners();

    // 构建 LlmProvider 实例
    final client = _providerManager.buildProviderForModel(
      providerId: currentAssistant.modelProviderId,
      modelOverride: currentAssistant.modelId,
    );

    // 构建上下文（最近 20 条 + system + 记忆注入）
    final contextMessages = _buildContextMessages(
      userMessage,
      currentAssistant.systemPrompt,
    );

    try {
      await client.chatCompletionStream(
        messages: contextMessages,
        model: currentAssistant.modelId,
        onChunk: (delta) {
          _streamingContent += delta;
          final list = _messagesByConversation[_currentConversationId];
          if (list != null) {
            final idx = list.indexWhere((m) => m.id == assistantMessageId);
            if (idx != -1) {
              list[idx].content = _streamingContent;
              notifyListeners();
            }
          }
        },
      );
      final list = _messagesByConversation[_currentConversationId];
      if (list != null) {
        final idx = list.indexWhere((m) => m.id == assistantMessageId);
        if (idx != -1) list[idx].status = MessageStatus.done;
      }

      // 自动更新对话标题
      _maybeUpdateConversationTitle(currentAssistant, content);
    } catch (e) {
      final list = _messagesByConversation[_currentConversationId];
      if (list != null) {
        final idx = list.indexWhere((m) => m.id == assistantMessageId);
        if (idx != -1) {
          list[idx].content = '请求失败: $e';
          list[idx].status = MessageStatus.error;
        }
      }
    } finally {
      _isLoading = false;
      _streamingMessageId = null;
      _streamingContent = '';
      notifyListeners();
    }
  }

  /// 首次对话自动用用户首句作为标题
  void _maybeUpdateConversationTitle(Assistant assistant, String firstContent) {
    final convIdx = assistant.currentConversationIndex;
    final conv = assistant.currentConversation;
    if (conv.title == '新对话') {
      final newTitle = firstContent.length > 20
          ? '${firstContent.substring(0, 20)}...'
          : firstContent;
      final updated = conv.copyWith(title: newTitle);
      final conversations = List<Conversation>.from(assistant.conversations);
      conversations[convIdx] = updated;
      _assistantManager.updateAssistant(
        assistant.id,
        assistant.copyWith(conversations: conversations),
      );
    }
  }

  // ========== 重新生成 ==========

  Future<void> regenerateMessage(String assistantMessageId) async {
    final conversationId = _currentConversationId;
    if (conversationId == null) return;
    final list = _messagesByConversation[conversationId];
    if (list == null) return;
    final msgIdx = list.indexWhere((m) => m.id == assistantMessageId);
    if (msgIdx == -1) return;

    final assistantMsg = list[msgIdx];
    final parentId = assistantMsg.parentMessageId;
    if (parentId == null) return;
    final userMsgIdx = list.indexWhere((m) => m.id == parentId);
    if (userMsgIdx == -1) return;
    final userMessage = list[userMsgIdx];

    list.removeAt(msgIdx);
    notifyListeners();

    final currentAssistant = _assistantManager.currentAssistant;
    if (currentAssistant == null) return;

    final newAssistantId = _uuid.v4();
    final newAssistant = Message(
      id: newAssistantId,
      conversationId: conversationId,
      role: MessageRole.assistant,
      content: '',
      parentMessageId: userMessage.id,
      status: MessageStatus.streaming,
    );
    list.add(newAssistant);
    _streamingMessageId = newAssistantId;
    _streamingContent = '';
    _isLoading = true;
    notifyListeners();

    final client = _providerManager.buildProviderForModel(
      providerId: currentAssistant.modelProviderId,
      modelOverride: currentAssistant.modelId,
    );
    final contextMessages = _buildContextMessages(
      userMessage,
      currentAssistant.systemPrompt,
    );

    try {
      await client.chatCompletionStream(
        messages: contextMessages,
        model: currentAssistant.modelId,
        onChunk: (delta) {
          _streamingContent += delta;
          final idx = list.indexWhere((m) => m.id == newAssistantId);
          if (idx != -1) {
            list[idx].content = _streamingContent;
            notifyListeners();
          }
        },
      );
      final idx = list.indexWhere((m) => m.id == newAssistantId);
      if (idx != -1) list[idx].status = MessageStatus.done;
    } catch (e) {
      final idx = list.indexWhere((m) => m.id == newAssistantId);
      if (idx != -1) {
        list[idx].content = '请求失败: $e';
        list[idx].status = MessageStatus.error;
      }
    } finally {
      _isLoading = false;
      _streamingMessageId = null;
      _streamingContent = '';
      notifyListeners();
    }
  }

  // ========== 消息删除 ==========

  void deleteMessage(String messageId) {
    final list = _messagesByConversation[_currentConversationId];
    if (list == null) return;
    list.removeWhere((m) => m.id == messageId);
    notifyListeners();
  }

  void editMessage(String messageId, String newContent) {
    final list = _messagesByConversation[_currentConversationId];
    if (list == null) return;
    final idx = list.indexWhere((m) => m.id == messageId);
    if (idx != -1) {
      list[idx].content = newContent;
      notifyListeners();
    }
  }

  // ========== 翻译 ==========

  Future<void> translateMessage(String messageId, String targetLanguage) async {
    final list = _messagesByConversation[_currentConversationId];
    if (list == null) return;
    final idx = list.indexWhere((m) => m.id == messageId);
    if (idx == -1) return;

    final msg = list[idx];
    if (msg.originalContent == null) {
      list[idx] = msg.copyWith(originalContent: msg.content);
    }

    final currentAssistant = _assistantManager.currentAssistant;
    if (currentAssistant == null) return;
    final client = _providerManager.buildProviderForModel(
      providerId: currentAssistant.modelProviderId,
      modelOverride: currentAssistant.modelId,
    );

    try {
      final translated = await client.chatCompletion(
        messages: [
          {'role': 'system', 'content': _translatePrompt(targetLanguage)},
          {'role': 'user', 'content': msg.originalContent ?? msg.content},
        ],
        temperature: 0.3,
      );
      list[idx].content = translated;
      notifyListeners();
    } catch (e) {
      debugPrint('翻译失败: $e');
    }
  }

  String _translatePrompt(String target) => '你是一个专业的翻译助手。请将用户输入的内容翻译成$target。'
      '只输出翻译结果，不要添加任何解释、注释或额外内容。'
      '保持原文的语气、风格和格式。';

  void undoTranslation(String messageId) {
    final list = _messagesByConversation[_currentConversationId];
    if (list == null) return;
    final idx = list.indexWhere((m) => m.id == messageId);
    if (idx == -1) return;
    final msg = list[idx];
    if (msg.originalContent != null) {
      list[idx] = msg.copyWith(
        content: msg.originalContent!,
        clearOriginalContent: true,
      );
      notifyListeners();
    }
  }

  // ========== 清空对话 ==========

  void clearMessages() {
    if (_currentConversationId == null) return;
    _messagesByConversation[_currentConversationId] = [];
    notifyListeners();
  }

  // ========== 上下文构建 ==========

  List<Map<String, String>> _buildContextMessages(
    Message currentUserMsg,
    String systemPrompt,
  ) {
    final messages = <Map<String, String>>[];
    messages.add({
      'role': 'system',
      'content': systemPrompt.isNotEmpty
          ? systemPrompt
          : '你是墨瞳，一个温暖、善解人意的 AI 陪伴助手。',
    });

    final list = _messagesByConversation[_currentConversationId] ?? [];
    final currentIdx = list.indexWhere((m) => m.id == currentUserMsg.id);
    if (currentIdx == -1) return messages;
    final startIdx = (currentIdx - 20).clamp(0, currentIdx);
    for (int i = startIdx; i <= currentIdx; i++) {
      final msg = list[i];
      if (msg.status == MessageStatus.error) continue;
      messages.add({'role': msg.role.name, 'content': msg.content});
    }
    return messages;
  }
}

extension _IterableFirstOrNull<E> on Iterable<E> {
  E? get firstOrNull => isEmpty ? null : first;
}