/// 模块 5 — re-export 到 core/providers 路径
/// 真实实现在 lib/features/settings/providers/settings_provider.dart
library motong.core.providers.settings;

export '../../features/settings/providers/settings_provider.dart'
    show SettingsProvider;
export '../../features/settings/models/app_settings.dart' show AppSettings;