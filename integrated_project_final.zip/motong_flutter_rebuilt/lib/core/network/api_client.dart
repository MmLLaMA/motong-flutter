import 'dart:convert';
import 'package:http/http.dart' as http;

/// API 客户端，统一管理 BaseURL 和 APIKey
/// 支持 OpenAI 兼容协议的聊天补全和 Cloudflare TTS
class ApiClient {
  /// 大模型 API 基础地址（OpenAI 兼容接口）
  String baseUrl;

  /// API 密钥
  String apiKey;

  /// TTS 服务地址
  final String ttsUrl;

  /// HTTP 客户端实例
  final http.Client _client;

  ApiClient({
    required this.baseUrl,
    required this.apiKey,
    this.ttsUrl = 'https://motong.2807118872.workers.dev',
    http.Client? client,
  }) : _client = client ?? http.Client();

  /// 更新 API 配置
  void updateConfig({String? baseUrl, String? apiKey}) {
    if (baseUrl != null) this.baseUrl = baseUrl;
    if (apiKey != null) this.apiKey = apiKey;
  }

  /// 调用大模型聊天补全（非流式）
  /// 返回 AI 回复文本
  Future<String> chatCompletion({
    required List<Map<String, String>> messages,
    String model = 'gpt-4o-mini',
    double temperature = 0.7,
    int maxTokens = 2048,
  }) async {
    final uri = Uri.parse('$baseUrl/v1/chat/completions');
    final response = await _client.post(
      uri,
      headers: _headers,
      body: jsonEncode({
        'model': model,
        'messages': messages,
        'temperature': temperature,
        'max_tokens': maxTokens,
      }),
    );

    if (response.statusCode != 200) {
      throw ApiException(
        statusCode: response.statusCode,
        message: 'API 请求失败: ${response.body}',
      );
    }

    final data = jsonDecode(response.body) as Map<String, dynamic>;
    final choices = data['choices'] as List<dynamic>;
    if (choices.isEmpty) {
      throw ApiException(message: 'API 返回空响应');
    }

    return (choices[0]['message']['content'] ?? '') as String;
  }

  /// 调用大模型聊天补全（流式 SSE）
  /// 通过 [onChunk] 回调逐 token 返回内容
  /// 返回完整的 AI 回复文本
  Future<String> chatCompletionStream({
    required List<Map<String, String>> messages,
    String model = 'gpt-4o-mini',
    double temperature = 0.7,
    int maxTokens = 2048,
    required void Function(String delta) onChunk,
  }) async {
    final uri = Uri.parse('$baseUrl/v1/chat/completions');
    final request = http.StreamedRequest('POST', uri);
    request.headers.addAll(_headers);
    request.headers['Accept'] = 'text/event-stream';
    request.sink.add(utf8.encode(jsonEncode({
      'model': model,
      'messages': messages,
      'temperature': temperature,
      'max_tokens': maxTokens,
      'stream': true,
    })));
    request.sink.close();

    final response = await _client.send(request);
    if (response.statusCode != 200) {
      final body = await response.stream.bytesToString();
      throw ApiException(
        statusCode: response.statusCode,
        message: '流式 API 请求失败: $body',
      );
    }

    final buffer = StringBuffer();
    await for (final chunk in response.stream.transform(utf8.decoder)) {
      // 解析 SSE 数据行
      for (final line in chunk.split('\n')) {
        if (!line.startsWith('data: ')) continue;
        final data = line.substring(6).trim();
        if (data == '[DONE]') break;

        try {
          final json = jsonDecode(data) as Map<String, dynamic>;
          final choices = json['choices'] as List<dynamic>?;
          if (choices == null || choices.isEmpty) continue;

          final delta = choices[0]['delta'] as Map<String, dynamic>?;
          final content = delta?['content'] as String?;
          if (content != null && content.isNotEmpty) {
            buffer.write(content);
            onChunk(content);
          }
        } catch (_) {
          // 忽略解析失败的数据行
        }
      }
    }

    return buffer.toString();
  }

  /// 调用 Cloudflare TTS 服务
  /// 返回音频字节数据
  Future<List<int>> textToSpeech(String text) async {
    final uri = Uri.parse(ttsUrl);
    final response = await _client.post(
      uri,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'text': text}),
    );

    if (response.statusCode != 200) {
      throw ApiException(
        statusCode: response.statusCode,
        message: 'TTS 请求失败: ${response.body}',
      );
    }

    return response.bodyBytes.toList();
  }

  /// 调用大模型翻译
  Future<String> translate({
    required String content,
    required String targetLanguage,
  }) async {
    final systemPrompt = _buildTranslatePrompt(targetLanguage);
    final response = await chatCompletion(
      messages: [
        {'role': 'system', 'content': systemPrompt},
        {'role': 'user', 'content': content},
      ],
      temperature: 0.3,
    );
    return response;
  }

  /// 构建翻译 System Prompt
  String _buildTranslatePrompt(String targetLanguage) {
    final langMap = {
      '中文': '简体中文',
      'English': 'English',
      '日本語': '日本語',
      '한국어': '한국어',
    };
    final lang = langMap[targetLanguage] ?? targetLanguage;
    return '你是一个专业的翻译助手。请将用户输入的内容翻译成$lang。'
        '只输出翻译结果，不要添加任何解释、注释或额外内容。'
        '保持原文的语气、风格和格式。';
  }

  /// 统一请求头
  Map<String, String> get _headers => {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $apiKey',
      };

  /// 释放资源
  void dispose() {
    _client.close();
  }
}

/// API 异常
class ApiException implements Exception {
  final int? statusCode;
  final String message;

  ApiException({this.statusCode, required this.message});

  @override
  String toString() => 'ApiException($statusCode): $message';
}