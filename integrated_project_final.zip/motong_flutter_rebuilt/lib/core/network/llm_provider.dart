/// 大模型供应商抽象接口 + OpenAI 兼容实现
library llm_provider;

import 'dart:convert';
import 'package:http/http.dart' as http;

/// 大模型供应商抽象接口
abstract class LlmProviderInterface {
  /// 流式聊天补全
  Future<String> chatCompletionStream({
    required List<Map<String, String>> messages,
    String? model,
    double temperature = 0.7,
    int maxTokens = 2048,
    required void Function(String delta) onChunk,
  });

  /// 非流式聊天补全
  Future<String> chatCompletion({
    required List<Map<String, String>> messages,
    String? model,
    double temperature = 0.7,
    int maxTokens = 2048,
  });

  /// 测试连接
  Future<bool> testConnection();

  /// 获取可用模型列表
  Future<List<String>> fetchModels();
}

/// OpenAI 兼容协议供应商
class OpenAiCompatibleProvider implements LlmProviderInterface {
  final String baseUrl;
  final String apiKey;
  final String defaultModel;
  final http.Client _client;

  OpenAiCompatibleProvider({
    required this.baseUrl,
    required this.apiKey,
    this.defaultModel = 'gpt-4o-mini',
    http.Client? client,
  }) : _client = client ?? http.Client();

  Map<String, String> get _headers => {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $apiKey',
      };

  @override
  Future<String> chatCompletion({
    required List<Map<String, String>> messages,
    String? model,
    double temperature = 0.7,
    int maxTokens = 2048,
  }) async {
    final uri = Uri.parse('$baseUrl/v1/chat/completions');
    final response = await _client.post(
      uri,
      headers: _headers,
      body: jsonEncode({
        'model': model ?? defaultModel,
        'messages': messages,
        'temperature': temperature,
        'max_tokens': maxTokens,
      }),
    );

    if (response.statusCode != 200) {
      throw LlmProviderException(
        statusCode: response.statusCode,
        message: 'API 请求失败: ${response.body}',
      );
    }

    final data = jsonDecode(response.body) as Map<String, dynamic>;
    final choices = data['choices'] as List<dynamic>;
    if (choices.isEmpty) {
      throw LlmProviderException(message: 'API 返回空响应');
    }
    return (choices[0]['message']['content'] ?? '') as String;
  }

  @override
  Future<String> chatCompletionStream({
    required List<Map<String, String>> messages,
    String? model,
    double temperature = 0.7,
    int maxTokens = 2048,
    required void Function(String delta) onChunk,
  }) async {
    final uri = Uri.parse('$baseUrl/v1/chat/completions');
    final request = http.StreamedRequest('POST', uri);
    request.headers.addAll(_headers);
    request.headers['Accept'] = 'text/event-stream';
    request.sink.add(utf8.encode(jsonEncode({
      'model': model ?? defaultModel,
      'messages': messages,
      'temperature': temperature,
      'max_tokens': maxTokens,
      'stream': true,
    })));
    request.sink.close();

    final response = await _client.send(request);
    if (response.statusCode != 200) {
      final body = await response.stream.bytesToString();
      throw LlmProviderException(
        statusCode: response.statusCode,
        message: '流式 API 请求失败: $body',
      );
    }

    final buffer = StringBuffer();
    await for (final chunk in response.stream.transform(utf8.decoder)) {
      for (final line in chunk.split('\n')) {
        if (!line.startsWith('data: ')) continue;
        final data = line.substring(6).trim();
        if (data == '[DONE]') break;
        try {
          final json = jsonDecode(data) as Map<String, dynamic>;
          final choices = json['choices'] as List<dynamic>?;
          if (choices == null || choices.isEmpty) continue;
          final delta = choices[0]['delta'] as Map<String, dynamic>?;
          final content = delta?['content'] as String?;
          if (content != null && content.isNotEmpty) {
            buffer.write(content);
            onChunk(content);
          }
        } catch (_) {}
      }
    }
    return buffer.toString();
  }

  @override
  Future<bool> testConnection() async {
    try {
      final uri = Uri.parse('$baseUrl/v1/models');
      final response = await _client
          .get(uri, headers: _headers)
          .timeout(const Duration(seconds: 10));
      return response.statusCode == 200;
    } catch (_) {
      return false;
    }
  }

  @override
  Future<List<String>> fetchModels() async {
    try {
      final uri = Uri.parse('$baseUrl/v1/models');
      final response = await _client
          .get(uri, headers: _headers)
          .timeout(const Duration(seconds: 10));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body) as Map<String, dynamic>;
        final models = data['data'] as List<dynamic>?;
        return models
                ?.map((m) => (m as Map<String, dynamic>)['id'] as String)
                .toList() ??
            [];
      }
      return [];
    } catch (_) {
      return [];
    }
  }

  void dispose() => _client.close();
}

class LlmProviderException implements Exception {
  final int? statusCode;
  final String message;
  LlmProviderException({this.statusCode, required this.message});
  @override
  String toString() => 'LlmProviderException($statusCode): $message';
}