import 'package:flutter/material.dart';

/// 自定义底部弹出面板
class CustomBottomSheet extends StatelessWidget {
  final String? title;
  final Widget child;
  final double? height;

  const CustomBottomSheet({
    super.key,
    this.title,
    required this.child,
    this.height,
  });

  /// 显示通用底部面板（任意 Widget）
  static Future<T?> show<T>({
    required BuildContext context,
    String? title,
    required Widget child,
    double? height,
  }) {
    return Navigator.of(context).push(
      _BottomSheetRoute<T>(
        builder: (_) => CustomBottomSheet(
          title: title,
          child: child,
          height: height,
        ),
      ),
    );
  }

  /// 显示选项型面板（数组 + labelBuilder）
  static Future<T?> showOptions<T>({
    required BuildContext context,
    String? title,
    required List<T> options,
    required String Function(T) labelBuilder,
    T? selectedValue,
  }) async {
    return Navigator.of(context).push(
      _BottomSheetRoute<T>(
        builder: (_) => CustomBottomSheet(
          title: title,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: options
                .map(
                  (o) => ListTile(
                    title: Text(labelBuilder(o)),
                    trailing: selectedValue == o
                        ? const Icon(Icons.check, color: Colors.blue)
                        : null,
                    onTap: () => Navigator.of(_).pop(o),
                  ),
                )
                .toList(),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final bottomPadding = MediaQuery.of(context).padding.bottom;
    return Container(
      constraints: height != null
          ? BoxConstraints(maxHeight: height!)
          : const BoxConstraints(maxHeight: 400),
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Center(
            child: Container(
              margin: const EdgeInsets.only(top: 12, bottom: 8),
              width: 36,
              height: 4,
              decoration: BoxDecoration(
                color: Colors.grey[300],
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ),
          if (title != null) ...[
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Text(
                title!,
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
              ),
            ),
            const Divider(height: 1),
          ],
          Flexible(child: SingleChildScrollView(child: child)),
          SizedBox(height: bottomPadding),
        ],
      ),
    );
  }
}

/// 弹出选项面板（数组 + labelBuilder）

class _BottomSheetRoute<T> extends PopupRoute<T> {
  final WidgetBuilder builder;
  _BottomSheetRoute({required this.builder});

  @override
  Color? get barrierColor => Colors.black54;

  @override
  bool get barrierDismissible => true;

  @override
  String? get barrierLabel => '关闭面板';

  @override
  Widget buildPage(BuildContext context, Animation<double> animation,
      Animation<double> secondaryAnimation) {
    return _BottomSheetOverlay(builder: builder);
  }

  @override
  Duration get transitionDuration => const Duration(milliseconds: 250);
}

class _BottomSheetOverlay extends StatelessWidget {
  final WidgetBuilder builder;
  const _BottomSheetOverlay({required this.builder});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => Navigator.of(context).pop(),
      behavior: HitTestBehavior.opaque,
      child: Align(
        alignment: Alignment.bottomCenter,
        child: GestureDetector(
          onTap: () {},
          child: builder(context),
        ),
      ),
    );
  }
}