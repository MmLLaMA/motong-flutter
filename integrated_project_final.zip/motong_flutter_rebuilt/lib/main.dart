import 'package:flutter/material.dart';
import 'app.dart';

/// 应用启动入口
void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MotongApp());
}