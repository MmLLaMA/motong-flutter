import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/webdav_config.dart';
import '../services/webdav_client.dart';

/// 连接测试结果。
class ConnectionTestResult {
  final bool success;
  final String message;
  final WebDavErrorCode? errorCode;

  const ConnectionTestResult({
    required this.success,
    required this.message,
    this.errorCode,
  });
}

/// WebDAV 配置管理 Provider — 多配置 / 切换 / 连接测试 / 结果回调。
class WebDavProvider extends ChangeNotifier {
  final FlutterSecureStorage _secureStorage;
  SharedPreferences? _prefs;

  List<WebDavConfig> _configs = [];
  WebDavConfig? _defaultConfig;
  bool _isLoading = false;
  ConnectionTestResult? _lastTestResult;

  List<WebDavConfig> get configs => List.unmodifiable(_configs);
  WebDavConfig? get defaultConfig => _defaultConfig;
  bool get isLoading => _isLoading;
  ConnectionTestResult? get lastTestResult => _lastTestResult;

  WebDavProvider({
    FlutterSecureStorage? secureStorage,
  }) : _secureStorage = secureStorage ?? const FlutterSecureStorage();

  static const String _configsKey = 'webdav_configs_json';

  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
    await _loadConfigs();
  }

  Future<void> _loadConfigs() async {
    _isLoading = true;
    notifyListeners();

    try {
      final json = _prefs?.getString(_configsKey);
      if (json != null) {
        final list = jsonDecode(json) as List<dynamic>;
        _configs = list
            .map((m) => WebDavConfig.fromJson(m as Map<String, dynamic>))
            .toList();
        _defaultConfig = _configs.cast<WebDavConfig?>().firstWhere(
            (c) => c?.isDefault == true,
            orElse: () => _configs.isNotEmpty ? _configs.first : null);
      }
    } catch (_) {
      _configs = [];
    }

    _isLoading = false;
    notifyListeners();
  }

  Future<void> _saveConfigs() async {
    final json = jsonEncode(_configs.map((c) => c.toJson()).toList());
    await _prefs?.setString(_configsKey, json);
  }

  /// 新增配置。
  Future<void> addConfig(WebDavConfig config, String password) async {
    _configs.add(config);
    await _secureStorage.write(
        key: 'webdav_${config.configId}_password', value: password);
    if (_configs.length == 1) {
      _configs[0] = _configs[0].copyWith(isDefault: true);
      _defaultConfig = _configs[0];
    }
    await _saveConfigs();
    notifyListeners();
  }

  /// 更新配置。密码为空字符串或 null 时不修改。
  Future<void> updateConfig(WebDavConfig config, {String? password}) async {
    final idx = _configs.indexWhere((c) => c.configId == config.configId);
    if (idx == -1) return;
    _configs[idx] = config;
    if (password != null && password.isNotEmpty) {
      await _secureStorage.write(
          key: 'webdav_${config.configId}_password', value: password);
    }
    if (config.isDefault) {
      _defaultConfig = config;
      for (int i = 0; i < _configs.length; i++) {
        if (i != idx && _configs[i].isDefault) {
          _configs[i] = _configs[i].copyWith(isDefault: false);
        }
      }
    }
    await _saveConfigs();
    notifyListeners();
  }

  /// 删除配置，同步清理密码。
  Future<void> deleteConfig(String configId) async {
    final wasDefault =
        _configs.any((c) => c.configId == configId && c.isDefault);
    _configs.removeWhere((c) => c.configId == configId);
    await _secureStorage.delete(key: 'webdav_${configId}_password');

    if (wasDefault && _configs.isNotEmpty) {
      _configs[0] = _configs[0].copyWith(isDefault: true);
      _defaultConfig = _configs[0];
    } else if (_configs.isEmpty) {
      _defaultConfig = null;
    }

    await _saveConfigs();
    notifyListeners();
  }

  /// 设为默认配置。
  Future<void> setDefault(String configId) async {
    for (int i = 0; i < _configs.length; i++) {
      _configs[i] = _configs[i]
          .copyWith(isDefault: _configs[i].configId == configId);
    }
    _defaultConfig = _configs.cast<WebDavConfig?>().firstWhere(
        (c) => c?.configId == configId,
        orElse: () => null);
    await _saveConfigs();
    notifyListeners();
  }

  /// 获取配置的密码。
  Future<String?> getPassword(String configId) async {
    return _secureStorage.read(key: 'webdav_${configId}_password');
  }

  /// 测试 WebDAV 连接。
  Future<ConnectionTestResult> testConnection({
    required String url,
    required String username,
    required String password,
    String uploadPath = '/motong/backups',
  }) async {
    _isLoading = true;
    notifyListeners();

    try {
      final client = WebDavClient(
        baseUrl: url,
        username: username,
        password: password,
        connectTimeoutSeconds: 3,
        readTimeoutSeconds: 10,
      );

      final propResult = await client.propfind(uploadPath, depth: 0);
      if (!propResult.success) {
        final mkResult = await client.makeCollection(uploadPath);
        client.dispose();
        if (!mkResult.success) {
          _lastTestResult = ConnectionTestResult(
            success: false,
            message: '备份目录不存在且无法自动创建，请在服务器上手动创建',
            errorCode: mkResult.errorCode,
          );
          _isLoading = false;
          notifyListeners();
          return _lastTestResult!;
        }
      }

      client.dispose();
      _lastTestResult = const ConnectionTestResult(
        success: true,
        message: '连接成功，备份目录已就绪',
      );
    } catch (_) {
      _lastTestResult = const ConnectionTestResult(
        success: false,
        message: '连接失败：未知错误',
      );
    }

    _isLoading = false;
    notifyListeners();
    return _lastTestResult!;
  }
}