import 'package:flutter/foundation.dart';

import '../models/backup_manifest.dart';
import '../services/backup_service.dart';

/// 单条备份历史记录。
class BackupHistoryEntry {
  final String backupId;
  final String remoteFileName;
  final int sizeBytes;
  final String sha256;
  final String backupTimeUtc;
  final String appVersion;
  final BackupTrigger trigger;

  const BackupHistoryEntry({
    required this.backupId,
    required this.remoteFileName,
    required this.sizeBytes,
    required this.sha256,
    required this.backupTimeUtc,
    required this.appVersion,
    this.trigger = BackupTrigger.manual,
  });
}

/// 备份 Provider — 状态管理 + 进度 + 历史列表 + 清理。
class BackupProvider extends ChangeNotifier {
  final BackupService _backupService;

  BackupStatus _status = BackupStatus.idle;
  double _progress = 0.0;
  String _currentStage = '';
  int _transferredBytes = 0;
  int _totalBytes = 0;
  BackupResult? _lastResult;
  String? _lastError;
  final List<BackupHistoryEntry> _history = [];

  BackupStatus get status => _status;
  double get progress => _progress;
  String get currentStage => _currentStage;
  int get transferredBytes => _transferredBytes;
  int get totalBytes => _totalBytes;
  BackupResult? get lastResult => _lastResult;
  String? get lastError => _lastError;
  List<BackupHistoryEntry> get history => List.unmodifiable(_history);

  BackupProvider({required BackupService backupService})
      : _backupService = backupService;

  /// 触发手动备份。
  Future<void> startBackup({
    required dynamic config,
    BackupTrigger trigger = BackupTrigger.manual,
    bool wifiOnly = true,
  }) async {
    if (_status == BackupStatus.preparing ||
        _status == BackupStatus.uploading ||
        _status == BackupStatus.verifying) {
      _lastError = '备份已在进行中';
      notifyListeners();
      return;
    }

    _status = BackupStatus.preparing;
    _progress = 0.0;
    _currentStage = '准备…';
    _lastError = null;
    notifyListeners();

    final result = await _backupService.backupNow(
      config: config,
      trigger: trigger,
      wifiOnly: wifiOnly,
    );

    // P1-6: 根据 result.success 设置状态
    _status = result.success ? BackupStatus.done : BackupStatus.failed;
    _lastResult = result;
    if (!result.success) {
      _lastError = result.errorMessage;
    } else {
      // P1-7 修复：使用 BackupResult 中的 backupId / appVersion
      _history.add(BackupHistoryEntry(
        backupId: result.backupId ?? '',
        remoteFileName: result.remoteFileName ?? '',
        sizeBytes: result.sizeBytes ?? 0,
        sha256: result.sha256 ?? '',
        backupTimeUtc: DateTime.now().toUtc().toIso8601String(),
        appVersion: result.appVersion ?? '',
        trigger: trigger,
      ));
    }
    _progress = result.success ? 1.0 : _progress;
    notifyListeners();
  }

  /// 取消备份。
  Future<void> cancel() async {
    await _backupService.cancel();
    _status = BackupStatus.idle;
    notifyListeners();
  }

  /// 加载备份历史列表（从 WebDAV PROPFIND 获取）。
  Future<void> loadHistory({
    required String url,
    required String username,
    required String password,
    required String uploadPath,
  }) async {
    // 需要 WebDavClient 实例
    // _history 填充逻辑由 UI 层通过 WebDavProvider 获取后调用
  }

  /// 手动添加历史条目（由 UI 层在 PROPFIND 解析后调用）。
  void setHistory(List<BackupHistoryEntry> entries) {
    _history
      ..clear()
      ..addAll(entries);
    notifyListeners();
  }

  /// 重置状态。
  void reset() {
    _status = BackupStatus.idle;
    _progress = 0.0;
    _lastResult = null;
    _lastError = null;
    notifyListeners();
  }
}