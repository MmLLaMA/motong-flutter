import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

import '../models/restore_strategy.dart';
import '../models/webdav_config.dart';
import '../services/restore_service.dart';
import '../services/webdav_client.dart';

/// 恢复 Provider — 状态（校验 / 下载 / 解析 / 恢复中 / 完成 / 失败）+ 部分恢复选择。
class RestoreProvider extends ChangeNotifier {
  final RestoreService _restoreService;
  final FlutterSecureStorage _secureStorage;

  RestoreStatus _status = RestoreStatus.idle;
  RestoreStage _stage = RestoreStage.verifying;
  double _progress = 0.0;
  String _currentMessage = '';
  RestoreResult? _lastResult;
  String? _lastError;

  /// 云端备份文件列表（由 UI 层调用 PROPFIND 后填充）
  List<String> _remoteBackupFiles = [];

  /// 用户选择的恢复范围
  Set<String> _selectedSections = {};

  /// 冲突预览信息
  RestorePreview? _preview;

  /// 加载中标记
  bool _isLoadingFiles = false;

  RestoreStatus get status => _status;
  RestoreStage get stage => _stage;
  double get progress => _progress;
  String get currentMessage => _currentMessage;
  RestoreResult? get lastResult => _lastResult;
  String? get lastError => _lastError;
  List<String> get remoteBackupFiles => List.unmodifiable(_remoteBackupFiles);
  Set<String> get selectedSections => Set.unmodifiable(_selectedSections);
  RestorePreview? get preview => _preview;
  bool get isLoadingFiles => _isLoadingFiles;

  RestoreProvider({
    required RestoreService restoreService,
    FlutterSecureStorage? secureStorage,
  })  : _restoreService = restoreService,
        _secureStorage = secureStorage ?? const FlutterSecureStorage();

  /// P1-8 修复：从 WebDAV PROPFIND 加载远端备份文件列表。
  Future<void> loadRemoteFiles(WebDavConfig config) async {
    _isLoadingFiles = true;
    notifyListeners();

    try {
      final password =
          await _secureStorage.read(key: 'webdav_${config.configId}_password');
      if (password == null || password.isEmpty) {
        _remoteBackupFiles = [];
        _isLoadingFiles = false;
        notifyListeners();
        return;
      }

      final client = WebDavClient(
        baseUrl: config.url,
        username: config.username,
        password: password,
      );

      final propResult = await client.propfind(config.uploadPath, depth: 1);
      client.dispose();

      if (propResult.success) {
        _remoteBackupFiles = propResult.entries
            .where((e) =>
                !e.isCollection &&
                e.href.contains('motong_backup_') &&
                e.href.endsWith('.json.gz'))
            .map((e) => e.href.split('/').last)
            .toList()
          ..sort((a, b) => b.compareTo(a)); // 最新文件排前面
      } else {
        _remoteBackupFiles = [];
      }
    } catch (_) {
      _remoteBackupFiles = [];
    }

    _isLoadingFiles = false;
    notifyListeners();
  }

  /// 设置远端备份文件列表（手动模式）。
  void setRemoteFiles(List<String> files) {
    _remoteBackupFiles = files;
    notifyListeners();
  }

  /// 设置恢复范围选择。
  void setSelectedSections(Set<String> sections) {
    _selectedSections = sections;
    notifyListeners();
  }

  /// 预览备份内容。
  Future<void> previewBackup({
    required dynamic config,
    required String remoteFileName,
  }) async {
    _status = RestoreStatus.verifying;
    _preview = null;
    notifyListeners();

    _preview = await _restoreService.preview(
      config: config,
      remoteFileName: remoteFileName,
    );
    _status = RestoreStatus.idle;
    notifyListeners();
  }

  /// 执行恢复。
  Future<void> startRestore({
    required dynamic config,
    required String remoteFileName,
    required RestoreStrategy strategy,
    RestoreConflictPolicy conflictPolicy = RestoreConflictPolicy.overwrite,
  }) async {
    if (_status == RestoreStatus.downloading ||
        _status == RestoreStatus.writing ||
        _status == RestoreStatus.parsing) {
      _lastError = '恢复已在进行中';
      notifyListeners();
      return;
    }

    _status = RestoreStatus.verifying;
    _progress = 0.0;
    _currentMessage = '准备恢复…';
    _lastError = null;
    notifyListeners();

    final result = await _restoreService.restore(
      config: config,
      remoteFileName: remoteFileName,
      strategy: strategy,
      conflictPolicy: conflictPolicy,
      selectedSections: _selectedSections,
    );

    _lastResult = result;
    if (result.success) {
      _status = RestoreStatus.done;
      _progress = 1.0;
      _currentMessage = '恢复完成：'
          '${result.conversationsRestored} 条对话、'
          '${result.memoriesRestored} 条记忆、'
          '${result.settingsRestored} 项设置';
    } else {
      _status = RestoreStatus.failed;
      _lastError = result.errorMessage;
    }
    notifyListeners();
  }

  /// 取消恢复。
  Future<void> cancel() async {
    await _restoreService.cancel();
    _status = RestoreStatus.idle;
    notifyListeners();
  }

  /// 重置状态。
  void reset() {
    _status = RestoreStatus.idle;
    _progress = 0.0;
    _lastResult = null;
    _lastError = null;
    _selectedSections = {};
    _preview = null;
    notifyListeners();
  }
}