/// 备份频率枚举。
enum BackupFrequency {
  /// 手动触发
  manual('手动'),

  /// 每日定时（默认凌晨 3:00）
  daily('每日'),

  /// 每周定时（默认周日凌晨 3:00）
  weekly('每周'),

  /// 退出应用时触发
  onExit('退出时');

  const BackupFrequency(this.label);
  final String label;
}

/// 备份调度配置 — 控制自动备份的触发策略。
class BackupSchedule {
  /// 备份频率
  final BackupFrequency frequency;

  /// 是否仅在 WiFi 下执行
  final bool wifiOnly;

  /// 下次计划执行时间（UTC 毫秒时间戳）；手动触发时可为 null
  final int? nextScheduledAtMs;

  /// 退出时备份的超时秒数（默认 30）
  final int exitBackupTimeoutSeconds;

  /// 是否启用定时自动备份
  final bool autoBackupEnabled;

  /// 是否启用退出时备份
  final bool exitBackupEnabled;

  const BackupSchedule({
    this.frequency = BackupFrequency.manual,
    this.wifiOnly = true,
    this.nextScheduledAtMs,
    this.exitBackupTimeoutSeconds = 30,
    this.autoBackupEnabled = false,
    this.exitBackupEnabled = true,
  });

  Map<String, dynamic> toJson() => {
        'frequency': frequency.name,
        'wifi_only': wifiOnly,
        'next_scheduled_at_ms': nextScheduledAtMs,
        'exit_backup_timeout_seconds': exitBackupTimeoutSeconds,
        'auto_backup_enabled': autoBackupEnabled,
        'exit_backup_enabled': exitBackupEnabled,
      };

  factory BackupSchedule.fromJson(Map<String, dynamic> json) {
    return BackupSchedule(
      frequency: BackupFrequency.values.firstWhere(
        (f) => f.name == json['frequency'],
        orElse: () => BackupFrequency.manual,
      ),
      wifiOnly: (json['wifi_only'] as bool?) ?? true,
      nextScheduledAtMs: (json['next_scheduled_at_ms'] as num?)?.toInt(),
      exitBackupTimeoutSeconds:
          (json['exit_backup_timeout_seconds'] as num?)?.toInt() ?? 30,
      autoBackupEnabled: (json['auto_backup_enabled'] as bool?) ?? false,
      exitBackupEnabled: (json['exit_backup_enabled'] as bool?) ?? true,
    );
  }

  BackupSchedule copyWith({
    BackupFrequency? frequency,
    bool? wifiOnly,
    int? nextScheduledAtMs,
    int? exitBackupTimeoutSeconds,
    bool? autoBackupEnabled,
    bool? exitBackupEnabled,
  }) {
    return BackupSchedule(
      frequency: frequency ?? this.frequency,
      wifiOnly: wifiOnly ?? this.wifiOnly,
      nextScheduledAtMs: nextScheduledAtMs ?? this.nextScheduledAtMs,
      exitBackupTimeoutSeconds:
          exitBackupTimeoutSeconds ?? this.exitBackupTimeoutSeconds,
      autoBackupEnabled: autoBackupEnabled ?? this.autoBackupEnabled,
      exitBackupEnabled: exitBackupEnabled ?? this.exitBackupEnabled,
    );
  }
}