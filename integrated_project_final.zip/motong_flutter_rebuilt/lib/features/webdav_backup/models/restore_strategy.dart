/// 恢复策略枚举 — 控制恢复时如何处理已存在的数据。
enum RestoreStrategy {
  /// 完整恢复：清空目标表，写入备份全部数据
  full,

  /// 部分恢复：仅覆盖用户选中的数据段，其余保持不变
  partial,

  /// 合并恢复：保留本地已有数据，追加备份中不重复的记录
  merge,
}

/// 冲突解决策略 — 当本地数据与备份数据冲突时的处理方式。
enum RestoreConflictPolicy {
  /// 以云端备份为准，覆盖本地
  overwrite,

  /// 保留本地数据，跳过冲突条目
  keepLocal,

  /// 恢复时发现冲突则让用户逐条选择
  manual,
}

/// 恢复范围 — 描述一次恢复操作涉及的备份文件与数据段选择。
class RestoreScope {
  /// 远端备份文件名
  final String remoteFileName;

  /// 恢复策略
  final RestoreStrategy strategy;

  /// 冲突解决策略
  final RestoreConflictPolicy conflictPolicy;

  /// 部分恢复时所选数据段；strategy=full 时为空表示全部
  final Set<String> selectedSections;

  const RestoreScope({
    required this.remoteFileName,
    this.strategy = RestoreStrategy.full,
    this.conflictPolicy = RestoreConflictPolicy.overwrite,
    this.selectedSections = const {},
  });
}