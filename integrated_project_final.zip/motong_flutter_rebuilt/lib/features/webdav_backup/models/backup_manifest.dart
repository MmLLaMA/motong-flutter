import 'backup_section.dart';

/// 备份清单 — 描述单次备份的元数据，嵌入备份包顶层。
class BackupManifest {
  /// 备份唯一标识（客户端生成 UUID v4）
  final String backupId;

  /// 归档格式版本号（当前 "1.0"）
  final String version;

  /// 备份开始本地时间（UTC ISO-8601）
  final String timestamp;

  /// 设备标识（ANDROID_ID 前 8 位 hex）
  final String deviceId;

  /// 备份包含的数据段元数据列表
  final List<BackupSectionMetadata> sections;

  /// 压缩后归档文件的 SHA-256 校验和（hex 字符串）
  final String checksum;

  /// 压缩算法标识（gzip）
  final String compression;

  /// 备份时 App 版本号
  final String appVersion;

  const BackupManifest({
    required this.backupId,
    this.version = '1.0',
    required this.timestamp,
    required this.deviceId,
    required this.sections,
    required this.checksum,
    this.compression = 'gzip',
    required this.appVersion,
  });

  Map<String, dynamic> toJson() => {
        'backup_id': backupId,
        'format_version': version,
        'backup_time_utc': timestamp,
        'device_id': deviceId,
        'checksum_sha256': checksum,
        'compression': compression,
        'app_version': appVersion,
        'sections': sections
            .map((s) => {
                  'section': s.section.key,
                  'record_count': s.recordCount,
                  'estimated_size_bytes': s.estimatedSizeBytes,
                })
            .toList(),
      };

  factory BackupManifest.fromJson(Map<String, dynamic> json) {
    final sectionsRaw = json['sections'] as List<dynamic>? ?? [];
    final sections = sectionsRaw.map((s) {
      final m = s as Map<String, dynamic>;
      return BackupSectionMetadata(
        section: BackupSection.fromKey(m['section'] as String) ??
            BackupSection.chats,
        recordCount: (m['record_count'] as num).toInt(),
        estimatedSizeBytes: (m['estimated_size_bytes'] as num).toInt(),
      );
    }).toList();

    return BackupManifest(
      backupId: (json['backup_id'] as String?) ?? '',
      version: (json['format_version'] as String?) ?? '1.0',
      timestamp: (json['backup_time_utc'] as String?) ?? '',
      deviceId: (json['device_id'] as String?) ?? '',
      checksum: (json['checksum_sha256'] as String?) ?? '',
      compression: (json['compression'] as String?) ?? 'gzip',
      appVersion: (json['app_version'] as String?) ?? '',
      sections: sections,
    );
  }
}