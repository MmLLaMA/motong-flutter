/// WebDAV 连接配置领域模型。
///
/// 密码存储在 FlutterSecureStorage 中，不参与 JSON 序列化。
/// Key 格式：`webdav_{configId}_password`
class WebDavConfig {
  final String configId;
  final String name;
  final String url;
  final String username;

  /// 认证方式：password / digest / token
  final String authType;

  /// WebDAV 服务端子路径，以 / 开头、不以 / 结尾
  final String uploadPath;

  /// 保留备份数量，默认 5
  final int retentionCount;

  /// 是否为默认配置
  final bool isDefault;

  /// 最近一次连接测试是否成功
  final bool? lastConnectionOk;

  /// 最近一次连接测试时间（UTC 毫秒时间戳）
  final int? lastTestedAtMs;

  const WebDavConfig({
    required this.configId,
    required this.name,
    required this.url,
    required this.username,
    this.authType = 'password',
    this.uploadPath = '/motong/backups',
    this.retentionCount = 5,
    this.isDefault = false,
    this.lastConnectionOk,
    this.lastTestedAtMs,
  });

  /// toJson() 不序列化密码 — 密码由调用方从 FlutterSecureStorage 实时读取
  Map<String, dynamic> toJson() => {
        'config_id': configId,
        'name': name,
        'url': url,
        'username': username,
        'auth_type': authType,
        'upload_path': uploadPath,
        'retention_count': retentionCount,
        'is_default': isDefault,
        'last_connection_ok': lastConnectionOk,
        'last_tested_at_ms': lastTestedAtMs,
      };

  factory WebDavConfig.fromJson(Map<String, dynamic> json) {
    return WebDavConfig(
      configId: json['config_id'] as String,
      name: json['name'] as String,
      url: json['url'] as String,
      username: json['username'] as String,
      authType: (json['auth_type'] as String?) ?? 'password',
      uploadPath: (json['upload_path'] as String?) ?? '/motong/backups',
      retentionCount: (json['retention_count'] as num?)?.toInt() ?? 5,
      isDefault: (json['is_default'] as bool?) ?? false,
      lastConnectionOk: json['last_connection_ok'] as bool?,
      lastTestedAtMs: (json['last_tested_at_ms'] as num?)?.toInt(),
    );
  }

  WebDavConfig copyWith({
    String? configId,
    String? name,
    String? url,
    String? username,
    String? authType,
    String? uploadPath,
    int? retentionCount,
    bool? isDefault,
    bool? lastConnectionOk,
    int? lastTestedAtMs,
  }) {
    return WebDavConfig(
      configId: configId ?? this.configId,
      name: name ?? this.name,
      url: url ?? this.url,
      username: username ?? this.username,
      authType: authType ?? this.authType,
      uploadPath: uploadPath ?? this.uploadPath,
      retentionCount: retentionCount ?? this.retentionCount,
      isDefault: isDefault ?? this.isDefault,
      lastConnectionOk: lastConnectionOk ?? this.lastConnectionOk,
      lastTestedAtMs: lastTestedAtMs ?? this.lastTestedAtMs,
    );
  }
}