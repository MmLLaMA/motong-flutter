/// 备份数据段枚举 — 对应各模块可独立备份 / 恢复的数据类别。
enum BackupSection {
  /// 对话记录（ConversationLogEntity）
  chats('chats', '对话记录'),

  /// 记忆系统（MemoryEntity + DesireSnapshotEntity）
  memories('memories', '记忆系统'),

  /// 用户设置（模型/TTS/代理/手机控制；不含 WebDAV 密码）
  settings('settings', '用户设置'),

  /// 角色/人物设定
  characters('characters', '角色设定');

  const BackupSection(this.key, this.label);

  /// 备份包 JSON 中的段 key
  final String key;

  /// UI 展示用中文标签
  final String label;

  /// 从 key 反查枚举
  static BackupSection? fromKey(String key) {
    for (final s in BackupSection.values) {
      if (s.key == key) return s;
    }
    return null;
  }
}

/// 备份段元数据 — 描述单个数据段的统计信息。
class BackupSectionMetadata {
  final BackupSection section;
  final int recordCount;
  final int estimatedSizeBytes;

  const BackupSectionMetadata({
    required this.section,
    required this.recordCount,
    required this.estimatedSizeBytes,
  });

  Map<String, dynamic> toJson() => {
        'section': section.key,
        'record_count': recordCount,
        'estimated_size_bytes': estimatedSizeBytes,
      };

  factory BackupSectionMetadata.fromJson(Map<String, dynamic> json) {
    return BackupSectionMetadata(
      section: BackupSection.fromKey(json['section'] as String) ??
          BackupSection.chats,
      recordCount: (json['record_count'] as num).toInt(),
      estimatedSizeBytes: (json['estimated_size_bytes'] as num).toInt(),
    );
  }
}