import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../models/backup_schedule.dart';
import '../models/webdav_config.dart';
import '../providers/backup_provider.dart';
import '../providers/webdav_provider.dart';
import '../services/backup_service.dart';

/// 备份控制页 — 手动备份按钮 + 定时配置 + 备份历史列表 + 存储空间用量。
class BackupControlPage extends StatelessWidget {
  const BackupControlPage({super.key});

  @override
  Widget build(BuildContext context) {
    final backupProvider = context.watch<BackupProvider>();
    final webdavProvider = context.watch<WebDavProvider>();
    final status = backupProvider.status;
    final isBusy = status == BackupStatus.preparing ||
        status == BackupStatus.uploading ||
        status == BackupStatus.verifying;

    return Scaffold(
      appBar: AppBar(title: const Text('数据备份')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // ---- 当前状态卡片 ----
          _buildStatusCard(context, backupProvider, isBusy),

          const SizedBox(height: 16),

          // ---- 备份操作区 ----
          _buildBackupActionCard(context, backupProvider, webdavProvider, isBusy),

          const SizedBox(height: 16),

          // ---- 定时配置 ----
          _buildScheduleCard(context),

          const SizedBox(height: 16),

          // ---- 备份历史 ----
          _buildHistoryCard(context, backupProvider),
        ],
      ),
    );
  }

  Widget _buildStatusCard(
      BuildContext context, BackupProvider provider, bool isBusy) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                _statusIcon(provider.status),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    provider.currentStage.isNotEmpty
                        ? provider.currentStage
                        : _statusText(provider.status),
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                ),
              ],
            ),
            if (isBusy) ...[
              const SizedBox(height: 12),
              LinearProgressIndicator(value: provider.progress),
              const SizedBox(height: 4),
              Text(
                provider.totalBytes > 0
                    ? '${_formatBytes(provider.transferredBytes)} / ${_formatBytes(provider.totalBytes)}'
                    : '处理中…',
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ],
            if (provider.lastError != null) ...[
              const SizedBox(height: 8),
              Text(
                provider.lastError!,
                style: TextStyle(color: Colors.red.shade700, fontSize: 13),
              ),
            ],
            if (provider.lastResult != null && provider.lastResult!.success) ...[
              const SizedBox(height: 8),
              Text(
                '上次备份：${provider.lastResult!.remoteFileName ?? "—"}\n'
                '大小：${_formatBytes(provider.lastResult!.sizeBytes ?? 0)}',
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildBackupActionCard(BuildContext context, BackupProvider backupProvider,
      WebDavProvider webdavProvider, bool isBusy) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('备份操作', style: Theme.of(context).textTheme.titleSmall),
            const SizedBox(height: 12),

            // 配置选择
            if (webdavProvider.configs.isEmpty)
              const Padding(
                padding: EdgeInsets.only(bottom: 12),
                child: Text(
                  '尚未配置 WebDAV 连接',
                  style: TextStyle(color: Colors.grey),
                ),
              ),

            // 立即备份
            ElevatedButton.icon(
              onPressed: isBusy || webdavProvider.configs.isEmpty
                  ? null
                  : () => _triggerBackup(context, backupProvider, webdavProvider),
              icon: const Icon(Icons.cloud_upload),
              label: Text(isBusy ? '备份进行中…' : '立即备份'),
              style: ElevatedButton.styleFrom(
                minimumSize: const Size.fromHeight(48),
              ),
            ),
            if (isBusy)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: TextButton(
                  onPressed: () => backupProvider.cancel(),
                  child: const Text('取消备份'),
                ),
              ),

            const SizedBox(height: 12),

            // 恢复入口
            OutlinedButton.icon(
              onPressed: webdavProvider.configs.isEmpty
                  ? null
                  : () => context.push('/backup/restore'),
              icon: const Icon(Icons.cloud_download),
              label: const Text('从备份恢复'),
              style: OutlinedButton.styleFrom(
                minimumSize: const Size.fromHeight(48),
              ),
            ),

            // 配置管理
            TextButton.icon(
              onPressed: () =>
                  context.push('/backup/webdav-config'),
              icon: const Icon(Icons.settings),
              label: Text(webdavProvider.configs.isEmpty
                  ? '添加 WebDAV 配置'
                  : '管理 WebDAV 配置 (${webdavProvider.configs.length})'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildScheduleCard(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('自动备份', style: Theme.of(context).textTheme.titleSmall),
            const SizedBox(height: 12),

            // 定时备份开关
            SwitchListTile(
              title: const Text('定时自动备份'),
              subtitle: const Text('每日凌晨自动备份'),
              value: false, // TODO: 从 BackupScheduleProvider 读取
              onChanged: (_) {},
              contentPadding: EdgeInsets.zero,
            ),

            // 退出时备份开关
            SwitchListTile(
              title: const Text('退出时备份'),
              subtitle: const Text('退出应用时自动备份（30 秒超时）'),
              value: true, // TODO: 从 BackupScheduleProvider 读取
              onChanged: (_) {},
              contentPadding: EdgeInsets.zero,
            ),

            // WiFi-only
            SwitchListTile(
              title: const Text('仅 WiFi 下备份'),
              subtitle: const Text('仅在 WiFi 连接时触发自动备份'),
              value: true, // TODO: 从 BackupScheduleProvider 读取
              onChanged: (_) {},
              contentPadding: EdgeInsets.zero,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHistoryCard(
      BuildContext context, BackupProvider backupProvider) {
    final history = backupProvider.history;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('备份历史', style: Theme.of(context).textTheme.titleSmall),
                if (history.isNotEmpty)
                  Text(
                    '${history.length} 个备份',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
              ],
            ),
            const SizedBox(height: 8),

            if (history.isEmpty)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 16),
                child: Center(
                    child: Text('暂无备份记录',
                        style: TextStyle(color: Colors.grey))),
              )
            else
              ...history.take(10).map((entry) => ListTile(
                    dense: true,
                    leading: const Icon(Icons.archive_outlined, size: 28),
                    title: Text(
                      entry.remoteFileName,
                      style: const TextStyle(fontSize: 13),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    subtitle: Text(
                      '${_formatBytes(entry.sizeBytes)} · ${entry.backupTimeUtc}',
                      style: const TextStyle(fontSize: 12),
                    ),
                    trailing: IconButton(
                      icon: const Icon(Icons.restore, size: 20),
                      onPressed: () => context.push('/backup/restore',
                          extra: entry.remoteFileName),
                    ),
                  )),
          ],
        ),
      ),
    );
  }

  Future<void> _triggerBackup(BuildContext context, BackupProvider backupProvider, WebDavProvider webdavProvider) async {
    final config = webdavProvider.defaultConfig;
    if (config == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('请先配置 WebDAV 连接')),
      );
      return;
    }
    await backupProvider.startBackup(config: config);
  }

  Widget _statusIcon(BackupStatus status) {
    switch (status) {
      case BackupStatus.idle:
        return const Icon(Icons.cloud_outlined, color: Colors.grey);
      case BackupStatus.preparing:
      case BackupStatus.uploading:
      case BackupStatus.verifying:
        return const SizedBox(
          width: 24,
          height: 24,
          child: CircularProgressIndicator(strokeWidth: 2),
        );
      case BackupStatus.done:
        return const Icon(Icons.check_circle, color: Colors.green);
      case BackupStatus.failed:
        return const Icon(Icons.error, color: Colors.red);
    }
  }

  String _statusText(BackupStatus status) {
    switch (status) {
      case BackupStatus.idle:
        return '就绪';
      case BackupStatus.preparing:
        return '准备数据…';
      case BackupStatus.uploading:
        return '上传中…';
      case BackupStatus.verifying:
        return '校验中…';
      case BackupStatus.done:
        return '备份完成';
      case BackupStatus.failed:
        return '备份失败';
    }
  }

  String _formatBytes(int bytes) {
    if (bytes < 1024) return '$bytes B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
    return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
  }
}