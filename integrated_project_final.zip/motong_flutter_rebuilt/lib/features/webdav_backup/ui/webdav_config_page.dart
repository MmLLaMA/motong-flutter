import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/webdav_config.dart';
import '../providers/webdav_provider.dart';

/// WebDAV 配置编辑页 — URL / 用户名 / 密码 / 路径 / 测试连接按钮 + 状态反馈。
class WebDavConfigPage extends StatefulWidget {
  /// 为空表示新增模式，非空表示编辑模式。
  final WebDavConfig? existingConfig;

  const WebDavConfigPage({super.key, this.existingConfig});

  @override
  State<WebDavConfigPage> createState() => _WebDavConfigPageState();
}

class _WebDavConfigPageState extends State<WebDavConfigPage> {
  final _formKey = GlobalKey<FormState>();
  final _urlCtrl = TextEditingController();
  final _usernameCtrl = TextEditingController();
  final _passwordCtrl = TextEditingController();
  final _pathCtrl = TextEditingController();
  final _nameCtrl = TextEditingController();
  final _retentionCtrl = TextEditingController(text: '5');

  bool _isTesting = false;
  bool _obscurePassword = true;
  String? _testFeedback;
  bool _testSuccess = false;

  @override
  void initState() {
    super.initState();
    final c = widget.existingConfig;
    if (c != null) {
      _urlCtrl.text = c.url;
      _usernameCtrl.text = c.username;
      _pathCtrl.text = c.uploadPath;
      _nameCtrl.text = c.name;
      _retentionCtrl.text = c.retentionCount.toString();
    }
  }

  @override
  void dispose() {
    _urlCtrl.dispose();
    _usernameCtrl.dispose();
    _passwordCtrl.dispose();
    _pathCtrl.dispose();
    _nameCtrl.dispose();
    _retentionCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<WebDavProvider>();

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.existingConfig != null ? '编辑配置' : '新增配置'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // 配置名称
              TextFormField(
                controller: _nameCtrl,
                decoration: const InputDecoration(
                  labelText: '配置名称',
                  hintText: '如：家里的 NAS',
                  prefixIcon: Icon(Icons.label_outline),
                ),
                validator: (v) {
                  if (v == null || v.trim().isEmpty) return '请输入配置名称';
                  if (v.trim().length > 32) return '名称不超过 32 个字符';
                  return null;
                },
              ),
              const SizedBox(height: 12),

              // 服务器 URL
              TextFormField(
                controller: _urlCtrl,
                decoration: const InputDecoration(
                  labelText: '服务器 URL',
                  hintText: 'https://nas.example.com:8080',
                  prefixIcon: Icon(Icons.link),
                ),
                keyboardType: TextInputType.url,
                validator: (v) {
                  if (v == null || v.trim().isEmpty) return '请输入服务器 URL';
                  final trimmed = v.trim();
                  if (!trimmed.startsWith('http://') &&
                      !trimmed.startsWith('https://')) {
                    return 'URL 必须以 http:// 或 https:// 开头';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 12),

              // 用户名
              TextFormField(
                controller: _usernameCtrl,
                decoration: const InputDecoration(
                  labelText: '用户名',
                  prefixIcon: Icon(Icons.person_outline),
                ),
                validator: (v) {
                  if (v == null || v.trim().isEmpty) return '请输入用户名';
                  if (v.trim().length > 128) return '用户名不超过 128 个字符';
                  return null;
                },
              ),
              const SizedBox(height: 12),

              // 密码
              TextFormField(
                controller: _passwordCtrl,
                obscureText: _obscurePassword,
                decoration: InputDecoration(
                  labelText: widget.existingConfig != null ? '密码（留空则不修改）' : '密码',
                  prefixIcon: const Icon(Icons.lock_outline),
                  suffixIcon: IconButton(
                    icon: Icon(_obscurePassword
                        ? Icons.visibility_off
                        : Icons.visibility),
                    onPressed: () =>
                        setState(() => _obscurePassword = !_obscurePassword),
                  ),
                ),
                validator: (v) {
                  if (widget.existingConfig != null) return null; // 编辑模式可选
                  if (v == null || v.isEmpty) return '请输入密码';
                  if (v.length > 256) return '密码不超过 256 个字符';
                  return null;
                },
              ),
              const SizedBox(height: 12),

              // 路径前缀
              TextFormField(
                controller: _pathCtrl,
                decoration: const InputDecoration(
                  labelText: '路径前缀（选填）',
                  hintText: '/motong/backups',
                  prefixIcon: Icon(Icons.folder_outline),
                ),
                validator: (v) {
                  if (v != null && v.isNotEmpty) {
                    if (!v.startsWith('/')) return '路径必须以 / 开头';
                    if (v.endsWith('/')) return '路径不能以 / 结尾';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 12),

              // 保留数量
              TextFormField(
                controller: _retentionCtrl,
                decoration: const InputDecoration(
                  labelText: '保留备份数量',
                  prefixIcon: Icon(Icons.history),
                ),
                keyboardType: TextInputType.number,
                validator: (v) {
                  if (v == null || v.isEmpty) return '请输入保留数量';
                  final n = int.tryParse(v);
                  if (n == null || n < 1 || n > 100) return '保留数量为 1~100';
                  return null;
                },
              ),
              const SizedBox(height: 24),

              // 测试连接按钮
              ElevatedButton.icon(
                onPressed: _isTesting ? null : _testConnection,
                icon: _isTesting
                    ? const SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Icon(Icons.wifi_find),
                label: Text(_isTesting ? '测试中…' : '测试连接'),
                style: ElevatedButton.styleFrom(
                  minimumSize: const Size.fromHeight(48),
                ),
              ),
              if (_testFeedback != null) ...[
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: _testSuccess
                        ? Colors.green.shade50
                        : Colors.red.shade50,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(
                      color: _testSuccess
                          ? Colors.green.shade300
                          : Colors.red.shade300,
                    ),
                  ),
                  child: Row(
                    children: [
                      Icon(
                        _testSuccess ? Icons.check_circle : Icons.error,
                        color: _testSuccess ? Colors.green : Colors.red,
                        size: 20,
                      ),
                      const SizedBox(width: 8),
                      Expanded(child: Text(_testFeedback!)),
                    ],
                  ),
                ),
              ],
              const SizedBox(height: 24),

              // 保存按钮
              ElevatedButton(
                onPressed: _isTesting ? null : _saveConfig,
                style: ElevatedButton.styleFrom(
                  minimumSize: const Size.fromHeight(48),
                  backgroundColor: Theme.of(context).primaryColor,
                  foregroundColor: Colors.white,
                ),
                child: Text(
                    widget.existingConfig != null ? '保存修改' : '保存配置'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _testConnection() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() {
      _isTesting = true;
      _testFeedback = null;
    });

    final provider = context.read<WebDavProvider>();
    final result = await provider.testConnection(
      url: _urlCtrl.text.trim(),
      username: _usernameCtrl.text.trim(),
      password: _passwordCtrl.text,
      uploadPath: _pathCtrl.text.trim().isEmpty
          ? '/motong/backups'
          : _pathCtrl.text.trim(),
    );

    setState(() {
      _isTesting = false;
      _testFeedback = result.message;
      _testSuccess = result.success;
    });
  }

  Future<void> _saveConfig() async {
    if (!_formKey.currentState!.validate()) return;

    final provider = context.read<WebDavProvider>();
    final configId = widget.existingConfig?.configId ??
        DateTime.now().millisecondsSinceEpoch.toString();
    final config = WebDavConfig(
      configId: configId,
      name: _nameCtrl.text.trim(),
      url: _urlCtrl.text.trim().replaceAll(RegExp(r'/$'), ''),
      username: _usernameCtrl.text.trim(),
      uploadPath: _pathCtrl.text.trim().isEmpty
          ? '/motong/backups'
          : _pathCtrl.text.trim(),
      retentionCount: int.tryParse(_retentionCtrl.text) ?? 5,
      isDefault: widget.existingConfig?.isDefault ?? false,
    );

    if (widget.existingConfig != null) {
      await provider.updateConfig(config, password: _passwordCtrl.text);
    } else {
      await provider.addConfig(config, _passwordCtrl.text);
    }

    if (mounted) Navigator.of(context).pop();
  }
}