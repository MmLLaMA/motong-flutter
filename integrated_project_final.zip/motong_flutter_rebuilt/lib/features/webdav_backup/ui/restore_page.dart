import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/restore_strategy.dart';
import '../providers/restore_provider.dart';
import '../providers/webdav_provider.dart';
import '../services/restore_service.dart';

/// 恢复页 — 云端备份列表 + 选择恢复范围 + 冲突预览 + 恢复确认。
class RestorePage extends StatefulWidget {
  /// P1-3 修复：接受预选文件名参数（从 backup_control_page 历史列表点击进入时传入）。
  final String? preselectedFile;

  const RestorePage({super.key, this.preselectedFile});

  @override
  State<RestorePage> createState() => _RestorePageState();
}

class _RestorePageState extends State<RestorePage> {
  String? _selectedFile;
  RestoreStrategy _strategy = RestoreStrategy.full;
  RestoreConflictPolicy _conflictPolicy = RestoreConflictPolicy.overwrite;
  final Set<String> _selectedSections = {};

  @override
  void initState() {
    super.initState();
    _selectedFile = widget.preselectedFile;
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // P1-8 修复：进入页面时自动加载远端备份文件列表
    _loadRemoteFilesIfNeeded();
  }

  void _loadRemoteFilesIfNeeded() {
    final restoreProvider = context.read<RestoreProvider>();
    final webdavProvider = context.read<WebDavProvider>();
    final config = webdavProvider.defaultConfig;
    if (config != null && restoreProvider.remoteBackupFiles.isEmpty && !restoreProvider.isLoadingFiles) {
      restoreProvider.loadRemoteFiles(config);
    }
  }

  @override
  Widget build(BuildContext context) {
    final restoreProvider = context.watch<RestoreProvider>();
    final webdavProvider = context.watch<WebDavProvider>();
    final isBusy = restoreProvider.status == RestoreStatus.downloading ||
        restoreProvider.status == RestoreStatus.writing ||
        restoreProvider.status == RestoreStatus.parsing ||
        restoreProvider.status == RestoreStatus.verifying;

    return Scaffold(
      appBar: AppBar(title: const Text('从备份恢复')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // ---- 恢复进度状态 ----
          if (isBusy || restoreProvider.status == RestoreStatus.done) ...[
            _buildProgressCard(context, restoreProvider),
            const SizedBox(height: 16),
          ],

          // ---- 文件选择 ----
          _buildFileSelector(context, restoreProvider, webdavProvider, isBusy),

          if (_selectedFile != null && !isBusy) ...[
            const SizedBox(height: 16),

            // ---- 恢复策略 ----
            _buildStrategySelector(context),

            const SizedBox(height: 16),

            // ---- 部分恢复范围 ----
            if (_strategy == RestoreStrategy.partial)
              _buildSectionSelector(context),

            const SizedBox(height: 16),

            // ---- 冲突预览 ----
            _buildConflictPreview(context, restoreProvider),

            const SizedBox(height: 24),

            // ---- 确认恢复按钮 ----
            _buildConfirmButton(context, restoreProvider, webdavProvider, isBusy),
          ],

          // ---- 错误信息 ----
          if (restoreProvider.lastError != null) ...[
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.red.shade50,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                restoreProvider.lastError!,
                style: TextStyle(color: Colors.red.shade700),
              ),
            ),
          ],

          // ---- 完成结果 ----
          if (restoreProvider.lastResult != null && restoreProvider.lastResult!.success) ...[
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.green.shade50,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(Icons.check_circle, color: Colors.green.shade700),
                      const SizedBox(width: 8),
                      const Text('恢复完成',
                          style: TextStyle(fontWeight: FontWeight.bold)),
                    ],
                  ),
                  const SizedBox(height: 8),
                  const Text('已恢复：'),
                  Text(
                      '  · ${restoreProvider.lastResult!.conversationsRestored} 条对话'),
                  Text(
                      '  · ${restoreProvider.lastResult!.memoriesRestored} 条记忆'),
                  Text(
                      '  · ${restoreProvider.lastResult!.settingsRestored} 项设置'),
                  const SizedBox(height: 12),
                  const Text('建议重启应用以完全生效',
                      style: TextStyle(color: Colors.grey)),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildProgressCard(
      BuildContext context, RestoreProvider restoreProvider) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                if (restoreProvider.status != RestoreStatus.done)
                  const SizedBox(
                    width: 24,
                    height: 24,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                else
                  const Icon(Icons.check_circle, color: Colors.green),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    restoreProvider.currentMessage.isNotEmpty
                        ? restoreProvider.currentMessage
                        : _stageText(restoreProvider.status),
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                ),
              ],
            ),
            if (restoreProvider.status != RestoreStatus.done &&
                restoreProvider.status != RestoreStatus.idle) ...[
              const SizedBox(height: 8),
              LinearProgressIndicator(value: restoreProvider.progress),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildFileSelector(BuildContext context, RestoreProvider restoreProvider,
      WebDavProvider webdavProvider, bool isBusy) {
    final files = restoreProvider.remoteBackupFiles;
    final isLoading = restoreProvider.isLoadingFiles;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('选择备份文件', style: Theme.of(context).textTheme.titleSmall),
            const SizedBox(height: 8),

            if (isLoading)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 24),
                child: Center(child: CircularProgressIndicator()),
              )
            else if (files.isEmpty)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 16),
                child: Center(
                  child: Column(
                    children: [
                      Icon(Icons.cloud_off, size: 40, color: Colors.grey),
                      SizedBox(height: 8),
                      Text('云端暂无备份文件',
                          style: TextStyle(color: Colors.grey)),
                    ],
                  ),
                ),
              )
            else
              ...files.map((file) => RadioListTile<String>(
                    title: Text(
                      file,
                      style: const TextStyle(fontSize: 13),
                    ),
                    value: file,
                    groupValue: _selectedFile,
                    onChanged: isBusy
                        ? null
                        : (v) {
                            setState(() => _selectedFile = v);
                            // 选择文件时自动触发预览
                            _previewSelected(restoreProvider, webdavProvider, v);
                          },
                  )),

            const SizedBox(height: 8),

            // P1-8 修复：刷新按钮调用真实 PROPFIND
            TextButton.icon(
              onPressed: isBusy
                  ? null
                  : () {
                      final config = webdavProvider.defaultConfig;
                      if (config != null) {
                        restoreProvider.loadRemoteFiles(config);
                      }
                    },
              icon: const Icon(Icons.refresh, size: 18),
              label: const Text('刷新列表'),
            ),
          ],
        ),
      ),
    );
  }

  void _previewSelected(RestoreProvider restoreProvider, WebDavProvider webdavProvider, String? fileName) {
    if (fileName == null) return;
    final config = webdavProvider.defaultConfig;
    if (config != null) {
      restoreProvider.previewBackup(config: config, remoteFileName: fileName);
    }
  }

  Widget _buildStrategySelector(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('恢复方式', style: Theme.of(context).textTheme.titleSmall),
            const SizedBox(height: 8),
            RadioListTile<RestoreStrategy>(
              title: const Text('完整恢复'),
              subtitle: const Text('清空本地数据，以备份为准'),
              value: RestoreStrategy.full,
              groupValue: _strategy,
              onChanged: (v) => setState(() {
                _strategy = v!;
                if (_strategy != RestoreStrategy.partial) {
                  _selectedSections.clear();
                }
              }),
            ),
            RadioListTile<RestoreStrategy>(
              title: const Text('部分恢复'),
              subtitle: const Text('仅恢复选中的数据类别'),
              value: RestoreStrategy.partial,
              groupValue: _strategy,
              onChanged: (v) => setState(() => _strategy = v!),
            ),
            RadioListTile<RestoreStrategy>(
              title: const Text('合并恢复'),
              subtitle: const Text('保留本地数据，追加备份数据'),
              value: RestoreStrategy.merge,
              groupValue: _strategy,
              onChanged: (v) => setState(() {
                _strategy = v!;
                if (_strategy != RestoreStrategy.partial) {
                  _selectedSections.clear();
                }
              }),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionSelector(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('选择恢复范围', style: Theme.of(context).textTheme.titleSmall),
            const SizedBox(height: 8),
            CheckboxListTile(
              title: const Text('对话记录'),
              value: _selectedSections.contains('chats'),
              onChanged: (v) => _toggleSection('chats', v),
            ),
            CheckboxListTile(
              title: const Text('记忆系统'),
              value: _selectedSections.contains('memories'),
              onChanged: (v) => _toggleSection('memories', v),
            ),
            CheckboxListTile(
              title: const Text('用户设置'),
              subtitle: const Text('（不含 WebDAV 密码）'),
              value: _selectedSections.contains('settings'),
              onChanged: (v) => _toggleSection('settings', v),
            ),
            CheckboxListTile(
              title: const Text('角色设定'),
              value: _selectedSections.contains('characters'),
              onChanged: (v) => _toggleSection('characters', v),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildConflictPreview(
      BuildContext context, RestoreProvider restoreProvider) {
    final preview = restoreProvider.preview;
    if (preview == null) return const SizedBox.shrink();

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('冲突预览', style: Theme.of(context).textTheme.titleSmall),
            const SizedBox(height: 8),
            Text('备份文件大小：${_formatBytes(preview.fileSizeBytes)}'),
            if (preview.manifest.timestamp.isNotEmpty)
              Text('备份时间：${preview.manifest.timestamp}'),
            if (preview.manifest.deviceId.isNotEmpty)
              Text('设备：${preview.manifest.deviceId}'),
            if (preview.manifest.appVersion.isNotEmpty)
              Text('版本：${preview.manifest.appVersion}'),
            if (preview.manifest.sections.isNotEmpty)
              Text('数据段：${preview.manifest.sections.map((s) => '${s.section.label}(${s.recordCount})').join(', ')}'),
            const SizedBox(height: 8),
            if (preview.localCounts.isNotEmpty)
              ...preview.localCounts.entries.map((e) =>
                  Text('本地 ${e.key}：${e.value} 条')),
            const SizedBox(height: 8),
            Text(
              '注意：恢复将覆盖当前本地数据。',
              style: TextStyle(color: Colors.orange.shade700, fontSize: 13),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildConfirmButton(BuildContext context, RestoreProvider restoreProvider,
      WebDavProvider webdavProvider, bool isBusy) {
    return ElevatedButton.icon(
      onPressed: (_selectedFile != null && !isBusy)
          ? () => _startRestore(context, restoreProvider, webdavProvider)
          : null,
      icon: const Icon(Icons.restore),
      label: const Text('开始恢复'),
      style: ElevatedButton.styleFrom(
        minimumSize: const Size.fromHeight(48),
        backgroundColor: Colors.red.shade600,
        foregroundColor: Colors.white,
      ),
    );
  }

  void _toggleSection(String section, bool? value) {
    setState(() {
      if (value == true) {
        _selectedSections.add(section);
      } else {
        _selectedSections.remove(section);
      }
    });
  }

  Future<void> _startRestore(BuildContext context, RestoreProvider restoreProvider,
      WebDavProvider webdavProvider) async {
    final config = webdavProvider.defaultConfig;
    if (config == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('请先配置 WebDAV 连接')),
      );
      return;
    }

    // 二次确认
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('确认恢复'),
        content: Text(_strategy == RestoreStrategy.full
            ? '完整恢复将清空当前所有本地数据，'
                '替换为备份内容。确定继续？'
            : '将恢复选中的数据类别。确定继续？'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: const Text('取消'),
          ),
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(true),
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('确认恢复'),
          ),
        ],
      ),
    );

    if (confirmed != true) return;

    restoreProvider.setSelectedSections(_selectedSections);
    await restoreProvider.startRestore(
      config: config,
      remoteFileName: _selectedFile!,
      strategy: _strategy,
    );
  }

  String _stageText(RestoreStatus status) {
    switch (status) {
      case RestoreStatus.idle:
        return '就绪';
      case RestoreStatus.verifying:
        return '校验中…';
      case RestoreStatus.downloading:
        return '下载中…';
      case RestoreStatus.parsing:
        return '解析中…';
      case RestoreStatus.writing:
        return '写入中…';
      case RestoreStatus.done:
        return '恢复完成';
      case RestoreStatus.failed:
        return '恢复失败';
    }
  }

  String _formatBytes(int bytes) {
    if (bytes < 1024) return '$bytes B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
    return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
  }
}