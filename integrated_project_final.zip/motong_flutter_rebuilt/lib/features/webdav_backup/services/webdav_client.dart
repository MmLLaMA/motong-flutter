import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:http/http.dart' as http;
import 'package:xml/xml.dart';

/// WebDAV 客户端错误码。
enum WebDavErrorCode {
  /// 网络不可达 / DNS 解析失败 / 连接超时
  connectionFailed,

  /// HTTP 401 Unauthorized
  authFailed,

  /// HTTP 403 Forbidden
  permissionDenied,

  /// HTTP 404 Not Found
  notFound,

  /// HTTP 507 Insufficient Storage
  storageFull,

  /// SSL / TLS 握手失败
  sslError,

  /// 请求超时（读超时）
  readTimeout,

  /// 服务器内部错误 5xx
  serverError,

  /// 其他未知错误
  unknown,
}

/// WebDAV 操作结果。
class WebDavResult {
  final bool success;
  final int? statusCode;
  final WebDavErrorCode? errorCode;
  final String? errorMessage;

  const WebDavResult._({
    required this.success,
    this.statusCode,
    this.errorCode,
    this.errorMessage,
  });

  factory WebDavResult.ok({int? statusCode}) =>
      WebDavResult._(success: true, statusCode: statusCode);

  factory WebDavResult.fail(
          {int? statusCode,
          required WebDavErrorCode errorCode,
          String? errorMessage}) =>
      WebDavResult._(
        success: false,
        statusCode: statusCode,
        errorCode: errorCode,
        errorMessage: errorMessage,
      );
}

/// PROPFIND 返回的条目。
class WebDavEntry {
  final String href;
  final bool isCollection;
  final int? contentLength;
  final String? lastModified;
  final String? etag;

  const WebDavEntry({
    required this.href,
    this.isCollection = false,
    this.contentLength,
    this.lastModified,
    this.etag,
  });
}

/// PROPFIND 查询结果。
class WebDavPropfindResult {
  final bool success;
  final List<WebDavEntry> entries;

  const WebDavPropfindResult({required this.success, this.entries = const []});
}

/// WebDAV HEAD 结果。
class WebDavHeadResult {
  final bool success;
  final int? contentLength;
  final String? etag;

  const WebDavHeadResult(
      {required this.success, this.contentLength, this.etag});
}

/// WebDAV 客户端 — 基于 `http` 包实现 RFC 4918 必要方法。
///
/// 支持：MKCOL / PROPFIND / PUT / GET / DELETE / HEAD + Basic Auth + 超时重试。
class WebDavClient {
  final String baseUrl;
  final String username;
  final String password;
  final http.Client _client;

  /// 连接超时（秒），默认 10
  final int connectTimeoutSeconds;

  /// 读超时（秒），默认 30
  final int readTimeoutSeconds;

  /// P1-2 修复：上传专用超时（秒），默认 120
  final int uploadTimeoutSeconds;

  /// P1-2 修复：下载专用超时（秒），默认 120
  final int downloadTimeoutSeconds;

  /// 最大重试次数，默认 3
  final int maxRetries;

  /// 请求之间的延迟基础值（秒），指数退避 2^n * baseDelay
  final double baseDelaySeconds;

  WebDavClient({
    required this.baseUrl,
    required this.username,
    required this.password,
    http.Client? client,
    this.connectTimeoutSeconds = 10,
    this.readTimeoutSeconds = 30,
    this.uploadTimeoutSeconds = 120,
    this.downloadTimeoutSeconds = 120,
    this.maxRetries = 3,
    this.baseDelaySeconds = 1.0,
  }) : _client = client ?? http.Client();

  String _stripSlash(String s) => s.endsWith('/') ? s.substring(0, s.length - 1) : s;

  String _ensureSlash(String s) => s.startsWith('/') ? s : '/$s';

  String _fullUrl(String path) {
    final base = _stripSlash(baseUrl);
    final p = _ensureSlash(path);
    return '$base$p';
  }

  Map<String, String> get _headers => {
        'Authorization':
            'Basic ${base64Encode(utf8.encode('$username:$password'))}',
      };

  // ---- MKCOL ----

  /// P1-4 修复：makeCollection 直接 MKCOL，405 时 fallback PUT。
  /// 不再发无意义的 PUT。
  Future<WebDavResult> makeCollection(String path) async {
    return _withRetry(() async {
      final uri = Uri.parse(_fullUrl(path));

      // 先尝试 MKCOL（RFC 4918 §9.1）
      final mkReq = http.Request('MKCOL', uri);
      mkReq.headers.addAll(_headers);
      try {
        final streamResp = await http.Client()
            .send(mkReq)
            .timeout(Duration(seconds: connectTimeoutSeconds));
        final body = await streamResp.stream.bytesToString();
        final status = streamResp.statusCode;
        if (status == 201 || status == 200) {
          return WebDavResult.ok(statusCode: status);
        }
        if (status == 405) {
          // 目录已存在或 MKCOL 不支持——视为成功
          return WebDavResult.ok(statusCode: status);
        }
        // 其他错误：尝试 PUT fallback
      } catch (_) {
        // MKCOL 失败，回退到 PUT
      }

      // PUT fallback（创建空文件标记目录，部分服务器兼容）
      final resp = await _client
          .put(uri, headers: _headers)
          .timeout(Duration(seconds: connectTimeoutSeconds));
      if (resp.statusCode == 201 ||
          resp.statusCode == 200 ||
          resp.statusCode == 405) {
        return WebDavResult.ok(statusCode: resp.statusCode);
      }
      return _mapError(resp.statusCode, 'MKCOL failed');
    });
  }

  // ---- PROPFIND ----

  Future<WebDavPropfindResult> propfind(String path, {int depth = 0}) async {
    final result = await _withRetry(() async {
      final uri = Uri.parse(_fullUrl(path));
      final request = http.Request('PROPFIND', uri);
      request.headers.addAll(_headers);
      request.headers['Depth'] = depth.toString();
      request.body = '''<?xml version="1.0" encoding="utf-8"?>
<d:propfind xmlns:d="DAV:">
  <d:prop>
    <d:resourcetype/>
    <d:getcontentlength/>
    <d:getlastmodified/>
    <d:getetag/>
  </d:prop>
</d:propfind>''';

      final streamResp = await http.Client()
          .send(request)
          .timeout(Duration(seconds: connectTimeoutSeconds + readTimeoutSeconds));
      final body = await streamResp.stream.bytesToString();
      if (streamResp.statusCode == 207) {
        return WebDavPropfindResult(
            success: true, entries: _parsePropfindXml(body));
      }
      return WebDavPropfindResult(success: false);
    });
    return result;
  }

  /// P2-6 修复：使用 xml 包做真正的 XML 解析，兼容各种 namespace 前缀写法。
  List<WebDavEntry> _parsePropfindXml(String xml) {
    final entries = <WebDavEntry>[];
    try {
      final document = XmlDocument.parse(xml);
      // 查找所有 <response> 元素（忽略 namespace 前缀）
      final responses = document.findAllElements('response');

      for (final resp in responses) {
        final hrefElem = _findChildIgnoreNs(resp, 'href');
        if (hrefElem == null) continue;

        final href = hrefElem.innerText;
        final isCollection =
            _findChildIgnoreNs(resp, 'collection', rootFilter: (e) =>
                e.name.local == 'collection') != null;

        final lengthElem = _findChildIgnoreNs(resp, 'getcontentlength');
        final contentLength = lengthElem != null
            ? int.tryParse(lengthElem.innerText)
            : null;

        final modifiedElem = _findChildIgnoreNs(resp, 'getlastmodified');
        final lastModified = modifiedElem?.innerText;

        final etagElem = _findChildIgnoreNs(resp, 'getetag');
        final etag = etagElem?.innerText;

        entries.add(WebDavEntry(
          href: href,
          isCollection: isCollection,
          contentLength: contentLength,
          lastModified: lastModified,
          etag: etag,
        ));
      }
    } catch (_) {
      // XML 解析失败：回退到正则（保持向下兼容）
      return _parsePropfindRegex(xml);
    }
    return entries;
  }

  /// 在元素树中忽略 namespace 前缀查找子元素。
  XmlElement? _findChildIgnoreNs(XmlElement parent, String localName,
      {bool Function(XmlElement)? rootFilter}) {
    for (final child in parent.children) {
      if (child is XmlElement) {
        if (child.name.local == localName) {
          if (rootFilter == null || rootFilter(child)) return child;
        }
        // 递归查找（应对多层嵌套，如 <propstat><prop><resourcetype><collection/></prop>...）
        final found = _findChildIgnoreNs(child, localName, rootFilter: rootFilter);
        if (found != null) return found;
      }
    }
    return null;
  }

  /// 正则兜底解析（XML 包不可用时）。
  List<WebDavEntry> _parsePropfindRegex(String xml) {
    final entries = <WebDavEntry>[];
    final responseRegExp =
        RegExp(r'<[^>]*:?response[^>]*>(.*?)</[^>]*:?response>', dotAll: true);
    for (final match in responseRegExp.allMatches(xml)) {
      final block = match.group(1)!;
      final hrefMatch = RegExp(r'<[^>]*:?href>(.*?)</[^>]*:?href>').firstMatch(block);
      // 忽略 namespace 前缀，大小写不敏感
      final isCollection =
          RegExp(r'<[^>]*:?collection\s*/>', caseSensitive: false).hasMatch(block);
      final lengthMatch =
          RegExp(r'<[^>]*:?getcontentlength>(\d+)</[^>]*:?getcontentlength>')
              .firstMatch(block);
      final modifiedMatch =
          RegExp(r'<[^>]*:?getlastmodified>(.*?)</[^>]*:?getlastmodified>')
              .firstMatch(block);
      final etagMatch =
          RegExp(r'<[^>]*:?getetag>(.*?)</[^>]*:?getetag>').firstMatch(block);

      if (hrefMatch != null) {
        entries.add(WebDavEntry(
          href: hrefMatch.group(1)!,
          isCollection: isCollection,
          contentLength:
              lengthMatch != null ? int.tryParse(lengthMatch.group(1)!) : null,
          lastModified: modifiedMatch?.group(1),
          etag: etagMatch?.group(1),
        ));
      }
    }
    return entries;
  }

  // ---- PUT ----

  /// P1-2 修复：PUT 使用 uploadTimeoutSeconds 专用超时。
  Future<WebDavResult> put(String remotePath, List<int> body) async {
    return _withRetry(() async {
      final uri = Uri.parse(_fullUrl(remotePath));
      final resp = await _client
          .put(uri, headers: _headers, body: body)
          .timeout(Duration(seconds: uploadTimeoutSeconds));
      if (resp.statusCode == 200 || resp.statusCode == 201 || resp.statusCode == 204) {
        return WebDavResult.ok(statusCode: resp.statusCode);
      }
      return _mapError(resp.statusCode, 'PUT failed');
    });
  }

  /// 流式上传（V1.1 分片扩展点）
  Future<WebDavResult> putStream(String remotePath, Stream<List<int>> stream,
      {required int contentLength}) async {
    return _withRetry(() async {
      final uri = Uri.parse(_fullUrl(remotePath));
      final request = http.StreamedRequest('PUT', uri);
      request.headers.addAll(_headers);
      request.headers['Content-Length'] = contentLength.toString();
      request.contentLength = contentLength;

      // 将 stream 的字节写入请求体
      final sink = request.sink;
      await for (final chunk in stream) {
        sink.add(chunk);
      }
      await sink.close();

      final resp = await request.send();
      if (resp.statusCode == 200 || resp.statusCode == 201 || resp.statusCode == 204) {
        return WebDavResult.ok(statusCode: resp.statusCode);
      }
      return _mapError(resp.statusCode, 'PUT stream failed');
    });
  }

  // ---- GET ----

  /// P1-2 修复：GET 使用 downloadTimeoutSeconds 专用超时。
  Future<List<int>?> get(String remotePath,
      {int? rangeStart, int? rangeEnd}) async {
    final result = await _withRetry<List<int>?>(() async {
      final uri = Uri.parse(_fullUrl(remotePath));
      final headers = Map<String, String>.from(_headers);
      if (rangeStart != null || rangeEnd != null) {
        headers['Range'] =
            'bytes=${rangeStart ?? 0}-${rangeEnd ?? ''}';
      }

      final resp = await _client
          .get(uri, headers: headers)
          .timeout(Duration(seconds: downloadTimeoutSeconds));
      if (resp.statusCode == 200 || resp.statusCode == 206) {
        return resp.bodyBytes;
      }
      return null;
    });
    return result;
  }

  // ---- HEAD ----

  Future<WebDavHeadResult> head(String remotePath) async {
    return _withRetry(() async {
      final uri = Uri.parse(_fullUrl(remotePath));
      final resp = await _client
          .head(uri, headers: _headers)
          .timeout(Duration(seconds: connectTimeoutSeconds + readTimeoutSeconds));
      if (resp.statusCode == 200) {
        return WebDavHeadResult(
          success: true,
          contentLength:
              int.tryParse(resp.headers['content-length'] ?? ''),
          etag: resp.headers['etag'],
        );
      }
      return const WebDavHeadResult(success: false);
    });
  }

  // ---- DELETE ----

  Future<WebDavResult> delete(String remotePath) async {
    return _withRetry(() async {
      final uri = Uri.parse(_fullUrl(remotePath));
      final resp = await _client
          .delete(uri, headers: _headers)
          .timeout(Duration(seconds: connectTimeoutSeconds + readTimeoutSeconds));
      if (resp.statusCode == 200 || resp.statusCode == 204 || resp.statusCode == 404) {
        return WebDavResult.ok(statusCode: resp.statusCode);
      }
      return _mapError(resp.statusCode, 'DELETE failed');
    });
  }

  // ---- 重试与错误映射 ----

  /// P1-1 修复：重试逻辑覆盖 HTTP 5xx 错误。
  ///
  /// 对网络异常（SocketException / TimeoutException / ClientException）与 HTTP 5xx
  /// 均做指数退避重试；401/403/404/422 等客户端错误不重试。
  Future<T> _withRetry<T>(Future<T> Function() fn) async {
    Exception? lastError;
    for (int attempt = 0; attempt <= maxRetries; attempt++) {
      try {
        final result = await fn();

        // P1-1: 检查是否为 WebDavResult fail + serverError
        // 仅对 5xx 重试；客户端错误（4xx）直接返回
        if (result is WebDavResult && !result.success) {
          if (result.errorCode == WebDavErrorCode.serverError ||
              result.errorCode == WebDavErrorCode.readTimeout ||
              result.errorCode == WebDavErrorCode.connectionFailed) {
            if (attempt < maxRetries) {
              final delay =
                  baseDelaySeconds * pow(2, attempt).toDouble();
              await Future.delayed(
                  Duration(milliseconds: (delay * 1000).toInt()));
              continue;
            }
          }
        }

        return result;
      } on SocketException catch (e) {
        lastError = e;
      } on TimeoutException catch (e) {
        lastError = e;
      } on HandshakeException catch (e) {
        // SSL error — don't retry
        if (T == WebDavResult || T == WebDavHeadResult || T == WebDavPropfindResult) {
          return _mapClientError(e) as T;
        }
        throw _mapClientError(e);
      } on http.ClientException catch (e) {
        lastError = e;
      }

      if (attempt < maxRetries) {
        final delay =
            baseDelaySeconds * pow(2, attempt).toDouble();
        await Future.delayed(Duration(milliseconds: (delay * 1000).toInt()));
      }
    }
    if (lastError != null) {
      if (T == WebDavResult || T == WebDavHeadResult || T == WebDavPropfindResult) {
        return _mapClientError(lastError!) as T;
      }
      throw lastError!;
    }
    // Should never reach here
    throw Exception('Request failed after $maxRetries retries');
  }

  WebDavResult _mapError(int statusCode, String context) {
    return WebDavResult.fail(
      statusCode: statusCode,
      errorCode: _statusToErrorCode(statusCode),
      errorMessage: '$context: HTTP $statusCode',
    );
  }

  WebDavResult _mapClientError(Exception e) {
    if (e is SocketException) {
      return WebDavResult.fail(
        errorCode: WebDavErrorCode.connectionFailed,
        errorMessage: '无法连接到服务器: ${e.message}',
      );
    }
    if (e is HandshakeException) {
      return WebDavResult.fail(
        errorCode: WebDavErrorCode.sslError,
        errorMessage: 'SSL 证书不受信任',
      );
    }
    if (e is TimeoutException) {
      return WebDavResult.fail(
        errorCode: WebDavErrorCode.readTimeout,
        errorMessage: '请求超时',
      );
    }
    return WebDavResult.fail(
      errorCode: WebDavErrorCode.unknown,
      errorMessage: e.toString(),
    );
  }

  static WebDavErrorCode _statusToErrorCode(int statusCode) {
    if (statusCode == 401) return WebDavErrorCode.authFailed;
    if (statusCode == 403) return WebDavErrorCode.permissionDenied;
    if (statusCode == 404) return WebDavErrorCode.notFound;
    if (statusCode == 507) return WebDavErrorCode.storageFull;
    if (statusCode >= 500) return WebDavErrorCode.serverError;
    return WebDavErrorCode.unknown;
  }

  void dispose() {
    _client.close();
  }
}