import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:workmanager/workmanager.dart';

import '../models/backup_schedule.dart';
import '../models/webdav_config.dart';
import 'backup_service.dart';

/// 备份调度器 — WorkManager 周期任务 + App lifecycle 监听。
///
/// 注册 `backupPeriodicTask`（最小间隔 15min，PRD 允许），
/// 监听 AppLifecycleState 变化以触发退出时备份。
class BackupScheduler with WidgetsBindingObserver {
  final BackupService _backupService;
  final void Function(String configId)? onPeriodicBackupTriggered;
  final VoidCallback? onExitBackupTriggered;

  BackupSchedule _schedule;
  BackupSchedule get schedule => _schedule;

  /// WorkManager callback dispatcher 名称（必须在顶层函数注册）
  static const String periodicTaskName = 'backupPeriodicTask';
  static const String exitTaskName = 'backupExitTask';

  BackupScheduler({
    required BackupService backupService,
    required BackupSchedule schedule,
    this.onPeriodicBackupTriggered,
    this.onExitBackupTriggered,
  })  : _backupService = backupService,
        _schedule = schedule {
    WidgetsBinding.instance.addObserver(this);
  }

  // ---- App Lifecycle ----

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused && _schedule.exitBackupEnabled) {
      _onAppExit();
    }
  }

  void _onAppExit() {
    // 退出时备份：注册 OneTimeWorkRequest，30 秒超时
    // workmanager 0.5.2 在某些 Android 设备上 registerOneOffTask 可能抛 PlatformException，
    // 这里静默吞掉异常，避免阻塞 app 退出流程
    try {
      Workmanager().registerOneOffTask(
        exitTaskName,
        exitTaskName,
        initialDelay: Duration.zero,
        existingWorkPolicy: ExistingWorkPolicy.replace,
        constraints: Constraints(
          networkType: _schedule.wifiOnly
              ? NetworkType.unmetered
              : NetworkType.connected,
          requiresBatteryNotLow: true,
        ),
      );
    } catch (e) {
      debugPrint('WorkManager registerOneOffTask failed: $e');
    }
    onExitBackupTriggered?.call();
  }

  // ---- WorkManager 调度 ----

  /// 启动或更新定时备份调度。
  Future<void> schedulePeriodic() async {
    try {
      await Workmanager().initialize(
        callbackDispatcher,
        isInDebugMode: kDebugMode,
      );
    } catch (e) {
      debugPrint('WorkManager initialize failed: $e');
      return;
    }

    if (_schedule.autoBackupEnabled &&
        _schedule.frequency != BackupFrequency.manual) {
      await Workmanager().registerPeriodicTask(
        periodicTaskName,
        periodicTaskName,
        frequency: Duration(
          hours: _schedule.frequency == BackupFrequency.weekly ? 168 : 24,
        ),
        constraints: Constraints(
          networkType: _schedule.wifiOnly
              ? NetworkType.unmetered
              : NetworkType.connected,
          requiresBatteryNotLow: true,
        ),
        existingWorkPolicy: ExistingWorkPolicy.update,
      );
    } else {
      await Workmanager().cancelByUniqueName(periodicTaskName);
    }
  }

  /// 取消所有调度任务。
  Future<void> cancelAll() async {
    await Workmanager().cancelByUniqueName(periodicTaskName);
    await Workmanager().cancelByUniqueName(exitTaskName);
  }

  /// 更新调度配置并同步 WorkManager。
  Future<void> updateSchedule(BackupSchedule newSchedule) async {
    _schedule = newSchedule;
    await schedulePeriodic();
  }

  /// P0-2 修复：退出时备份 —— 从 SharedPreferences 读取配置、密码，执行真实备份。
  Future<void> executeExitBackup(String configId) async {
    final stopwatch = Stopwatch()..start();
    const exitTimeout = Duration(seconds: 30);

    try {
      // 从本地存储读取完整 WebDavConfig
      final prefs = await SharedPreferences.getInstance();
      final configsJson = prefs.getString(_configsKey);
      if (configsJson == null) return;

      final configsList = jsonDecode(configsJson) as List<dynamic>;
      final configJson = configsList.cast<Map<String, dynamic>?>().firstWhere(
          (m) => m?['config_id'] == configId,
          orElse: () => null);
      if (configJson == null) return;

      final config = WebDavConfig.fromJson(configJson);

      // 非阻塞执行，超时自动放弃
      await _backupService
          .backupNow(
        config: config,
        trigger: BackupTrigger.onExit,
        wifiOnly: _schedule.wifiOnly,
      )
          .timeout(exitTimeout);
    } on TimeoutException {
      // 超时静默放弃
    } catch (_) {
      // 失败静默处理
    }
  }

  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
  }

  static const String _configsKey = 'webdav_configs_json';
}

/// P0-2 修复：WorkManager 顶层 callback dispatcher —— 实际执行备份。
///
/// 从 SharedPreferences 读取默认 configId → 读取密码 → 构建 BackupService → backupNow。
/// 必须在 main() 或 WorkManager().initialize() 之前定义为顶层函数。
@pragma('vm:entry-point')
void callbackDispatcher() {
  Workmanager().executeTask((taskName, inputData) async {
    try {
      switch (taskName) {
        case BackupScheduler.periodicTaskName:
          return await _executePeriodicBackup();
        case BackupScheduler.exitTaskName:
          return await _executeExitBackup();
        default:
          return true;
      }
    } catch (_) {
      return false;
    }
  });
}

/// 执行定时备份：读取默认配置 → 执行 backupNow。
Future<bool> _executePeriodicBackup() async {
  try {
    final prefs = await SharedPreferences.getInstance();
    final configsJson = prefs.getString('webdav_configs_json');
    if (configsJson == null) return true; // 无配置，不算失败

    final configsList = jsonDecode(configsJson) as List<dynamic>;
    // 取默认配置或第一个配置
    Map<String, dynamic>? configJson;
    for (final m in configsList) {
      final c = m as Map<String, dynamic>;
      if (c['is_default'] == true) {
        configJson = c;
        break;
      }
    }
    configJson ??= configsList.isNotEmpty
        ? configsList.first as Map<String, dynamic>
        : null;
    if (configJson == null) return true;

    final config = WebDavConfig.fromJson(configJson);

    final password = await _readPassword(config.configId);
    if (password == null || password.isEmpty) return true;

    final backupService = BackupService();
    // WorkManager isolate 下不注入数据采集回调——定时备份仅做存量备份，
    // 数据采集需在应用主进程完成后再触发，或通过文件系统缓存
    // 实际集成时由模块 1/2/3 通过 SharedPreferences 缓存数据供 WorkManager 读取
    await backupService.backupNow(
      config: config,
      trigger: BackupTrigger.scheduled,
    );

    return true;
  } catch (_) {
    return false;
  }
}

/// 执行退出时备份。
Future<bool> _executeExitBackup() async {
  try {
    final prefs = await SharedPreferences.getInstance();
    final configsJson = prefs.getString('webdav_configs_json');
    if (configsJson == null) return true;

    final configsList = jsonDecode(configsJson) as List<dynamic>;
    Map<String, dynamic>? configJson;
    for (final m in configsList) {
      final c = m as Map<String, dynamic>;
      if (c['is_default'] == true) {
        configJson = c;
        break;
      }
    }
    configJson ??= configsList.isNotEmpty
        ? configsList.first as Map<String, dynamic>
        : null;
    if (configJson == null) return true;

    final config = WebDavConfig.fromJson(configJson);

    final backupService = BackupService();
    await backupService
        .backupNow(
      config: config,
      trigger: BackupTrigger.onExit,
    )
        .timeout(const Duration(seconds: 30));

    return true;
  } catch (_) {
    return false;
  }
}

/// 从 FlutterSecureStorage 读取密码。
/// WorkManager isolate 下 FlutterSecureStorage 仍可使用（底层依赖 SharedPreferences/KeyStore）。
Future<String?> _readPassword(String configId) async {
  try {
    const storage = FlutterSecureStorage();
    return await storage.read(key: 'webdav_${configId}_password');
  } catch (_) {
    return null;
  }
}