import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:crypto/crypto.dart';
import 'package:path_provider/path_provider.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

import '../models/models.dart';
import 'webdav_client.dart';

/// 备份触发源。
enum BackupTrigger { manual, scheduled, onExit }

/// 备份状态枚举。
enum BackupStatus { idle, preparing, uploading, verifying, done, failed }

/// 备份进度回调：进度 0.0~1.0，当前阶段描述，已传输字节数 / 总字节数。
typedef BackupProgressCallback = void Function(
    double progress, String stage, int transferredBytes, int totalBytes);

/// 备份结果。
class BackupResult {
  final bool success;
  final String? remoteFileName;
  final int? sizeBytes;
  final String? sha256;
  final Duration? duration;
  final BackupTrigger trigger;
  final String? errorMessage;
  final String? backupId;
  final String? appVersion;

  const BackupResult({
    required this.success,
    this.remoteFileName,
    this.sizeBytes,
    this.sha256,
    this.duration,
    this.trigger = BackupTrigger.manual,
    this.errorMessage,
    this.backupId,
    this.appVersion,
  });
}

/// 备份服务 — 数据采集 → JSON 归档 → SHA-256 校验 → PUT 上传。
///
/// 依赖外部注入的数据采集回调（从 ChatProvider / MemoryManager / SettingsProvider 获取）。
class BackupService {
  final FlutterSecureStorage _secureStorage;
  final BackupProgressCallback? onProgress;

  // ---- P0-3 修复：取消安全的 Mutex ----
  Completer<void>? _lock;
  bool _cancelled = false;

  BackupStatus _status = BackupStatus.idle;
  BackupStatus get status => _status;
  bool get isBusy => _status != BackupStatus.idle && _status != BackupStatus.failed && _status != BackupStatus.done;

  BackupService({
    FlutterSecureStorage? secureStorage,
    this.onProgress,
  }) : _secureStorage = secureStorage ?? const FlutterSecureStorage();

  // ---- 数据采集回调（由调用方注入）----

  /// 采集对话记录
  Future<List<Map<String, dynamic>>> Function()? fetchConversations;

  /// 采集记忆数据
  Future<List<Map<String, dynamic>>> Function()? fetchMemories;

  /// 采集用户设置（不含 WebDAV 密码）
  Future<Map<String, dynamic>> Function()? fetchSettings;

  /// 采集快捷短语
  Future<List<Map<String, dynamic>>> Function()? fetchQuickPhrases;

  /// 采集角色设定 — P1-5 新增
  Future<List<Map<String, dynamic>>> Function()? fetchCharacters;

  /// 获取设备标识
  String Function()? getDeviceId;

  /// 获取 App 版本号
  String Function()? getAppVersion;

  // ---- 公开 API ----

  /// 执行一次全量备份。
  Future<BackupResult> backupNow({
    required WebDavConfig config,
    BackupTrigger trigger = BackupTrigger.manual,
    bool wifiOnly = true,
  }) async {
    // P0-3 修复：并发保护 —— 使用 Completer 互斥 + 取消标记
    if (_lock != null) {
      return BackupResult(
        success: false,
        trigger: trigger,
        errorMessage: '备份已在进行中',
      );
    }
    _lock = Completer<void>();
    _cancelled = false;

    final stopwatch = Stopwatch()..start();
    try {
      _setStatus(BackupStatus.preparing);
      _reportProgress(0.0, '准备数据…', 0, 0);

      // 1. 采集数据
      if (fetchConversations == null ||
          fetchMemories == null ||
          fetchSettings == null) {
        return BackupResult(
          success: false,
          trigger: trigger,
          errorMessage: '数据采集回调未注入',
        );
      }

      // P0-3: 取消检查点 — 每一步异步操作后检查
      if (_cancelled) {
        return BackupResult(
          success: false,
          trigger: trigger,
          errorMessage: '备份已取消',
        );
      }

      final conversations = await fetchConversations!();

      if (_cancelled) {
        return BackupResult(
          success: false,
          trigger: trigger,
          errorMessage: '备份已取消',
        );
      }

      final memories = await fetchMemories!();
      if (_cancelled) {
        return BackupResult(
          success: false,
          trigger: trigger,
          errorMessage: '备份已取消',
        );
      }

      final settings = await fetchSettings!();
      final quickPhrases = await (fetchQuickPhrases?.call() ?? Future.value(<Map<String, dynamic>>[]));

      // P1-5 修复：采集 characters 数据
      final characters = await (fetchCharacters?.call() ?? Future.value(<Map<String, dynamic>>[]));

      // P2-4 修复：deviceId 只调用一次
      final rawDeviceId = getDeviceId?.call() ?? 'unknown';
      final deviceId = rawDeviceId.length >= 8
          ? rawDeviceId.substring(0, 8)
          : rawDeviceId;
      final appVersion = getAppVersion?.call() ?? '0.0.0';

      _reportProgress(0.15, '序列化数据…', 0, 0);

      // 2. 构建 JSON 归档
      final manifestSections = <BackupSectionMetadata>[];
      final dataMap = <String, dynamic>{};

      // 对话段
      dataMap['conversations'] = conversations;
      manifestSections.add(BackupSectionMetadata(
        section: BackupSection.chats,
        recordCount: conversations.length,
        estimatedSizeBytes: utf8.encode(jsonEncode(conversations)).length,
      ));

      // 记忆段
      dataMap['memories'] = memories;
      manifestSections.add(BackupSectionMetadata(
        section: BackupSection.memories,
        recordCount: memories.length,
        estimatedSizeBytes: utf8.encode(jsonEncode(memories)).length,
      ));

      // 设置段（不含 WebDAV 密码 — 架构约束 §6）
      dataMap['settings'] = settings;
      manifestSections.add(BackupSectionMetadata(
        section: BackupSection.settings,
        recordCount: 1,
        estimatedSizeBytes: utf8.encode(jsonEncode(settings)).length,
      ));

      // P1-5 修复：characters 段
      dataMap['characters'] = characters;
      manifestSections.add(BackupSectionMetadata(
        section: BackupSection.characters,
        recordCount: characters.length,
        estimatedSizeBytes: utf8.encode(jsonEncode(characters)).length,
      ));

      // 快捷短语（跟随 settings 段）
      dataMap['quick_phrases'] = quickPhrases;

      // P2-3 修复：使用标准 UUID v4 格式
      final backupId = _generateUuidV4();

      _reportProgress(0.25, '构建归档…', 0, 0);

      // 3. 构建备份包 JSON
      final timestamp = DateTime.now().toUtc().toIso8601String();

      final envelopeJson = {
        'manifest': {
          'backup_id': backupId,
          'format_version': '1.0',
          'app_version': appVersion,
          'device_id': deviceId,
          'backup_time_utc': timestamp,
          'checksum_sha256': '', // Placeholder — filled below
          'compression': 'gzip',
          'sections': manifestSections.map((s) => s.toJson()).toList(),
        },
        'data': dataMap,
      };

      // 4. 序列化 JSON → 压缩
      final jsonStr = jsonEncode(envelopeJson);
      final jsonBytes = utf8.encode(jsonStr);

      // P0-1 修复（路径 B）：checksum = SHA-256(压缩前 JSON 明文)
      // 语义：校验 JSON 内容完整性，而非 gzip 不可重复的压缩结果
      final checksum = sha256.convert(jsonBytes).toString();
      (envelopeJson['manifest'] as Map)['checksum_sha256'] = checksum;

      // 用更新后的 manifest 重新序列化
      final finalJsonStr = jsonEncode(envelopeJson);
      final finalJsonBytes = utf8.encode(finalJsonStr);

      // 压缩一次即上传
      final compressedBytes = _gzipEncode(finalJsonBytes);

      _reportProgress(0.35, '计算校验和…', 0, compressedBytes.length);

      // 5. 生成文件名
      final tsStr = DateTime.now()
          .toUtc()
          .toIso8601String()
          .replaceAll(RegExp(r'[^0-9]'), '')
          .substring(0, 14);
      final fileName =
          'motong_backup_${tsStr}_${deviceId}_v${appVersion}.json.gz';
      final remotePath =
          '${config.uploadPath}/$fileName';

      // 6. 获取密码 + 创建 WebDAV 客户端
      final password =
          await _secureStorage.read(key: 'webdav_${config.configId}_password');
      if (password == null || password.isEmpty) {
        return BackupResult(
          success: false,
          trigger: trigger,
          errorMessage: '未找到 WebDAV 密码，请重新输入',
        );
      }

      // P0-3: 取消检查点
      if (_cancelled) {
        return BackupResult(
          success: false,
          trigger: trigger,
          errorMessage: '备份已取消',
        );
      }

      final client = WebDavClient(
        baseUrl: config.url,
        username: config.username,
        password: password,
      );

      _setStatus(BackupStatus.uploading);
      _reportProgress(0.40, '上传中…', 0, compressedBytes.length);

      // 7. PUT 上传
      final putResult = await client.put(remotePath, compressedBytes);
      if (!putResult.success) {
        client.dispose();
        return BackupResult(
          success: false,
          trigger: trigger,
          errorMessage: putResult.errorMessage ?? '上传失败',
        );
      }

      // P0-3: 取消检查点
      if (_cancelled) {
        client.dispose();
        return BackupResult(
          success: false,
          trigger: trigger,
          errorMessage: '备份已取消',
        );
      }

      _setStatus(BackupStatus.verifying);
      _reportProgress(0.85, '校验中…', compressedBytes.length,
          compressedBytes.length);

      // 8. 校验：下载 → 解压 → SHA-256(解压后 JSON) 比对
      // P0-1 修复：校验端解压后对 JSON 明文做 SHA-256
      final remoteBytes = await client.get(remotePath);
      client.dispose();

      if (remoteBytes == null) {
        return BackupResult(
          success: false,
          trigger: trigger,
          errorMessage: '备份校验失败：无法下载远端文件',
        );
      }

      // 解压远端文件，取其 JSON 明文做 SHA-256 比对
      final decompressedBytes = GZipCodec().decode(remoteBytes);
      final remoteChecksum = sha256.convert(decompressedBytes).toString();
      if (remoteChecksum != checksum) {
        return BackupResult(
          success: false,
          trigger: trigger,
          errorMessage: '备份校验失败：校验和不匹配',
        );
      }

      // 9. 清理旧备份
      await _enforceRetentionPolicy(config);

      stopwatch.stop();
      _setStatus(BackupStatus.done);
      _reportProgress(1.0, '完成', compressedBytes.length, compressedBytes.length);

      // P1-7 修复：BackupResult 现在携带 backupId / appVersion
      return BackupResult(
        success: true,
        remoteFileName: fileName,
        sizeBytes: compressedBytes.length,
        sha256: checksum,
        duration: stopwatch.elapsed,
        trigger: trigger,
        backupId: backupId,
        appVersion: appVersion,
      );
    } catch (e) {
      return BackupResult(
        success: false,
        trigger: trigger,
        errorMessage: e.toString(),
      );
    } finally {
      // P1-6 修复：根据实际成功/失败设置状态，而非一律 done
      // 这里无法直接判断 BackupResult，但在 catch 走完后再判断
      // 注：正常路径（return 在 try 内）不会走到 finally 的 _setStatus
      // 异常路径：状态已在 catch 前被 _setStatus(done/verifying) 设过，
      // 这里统一恢复为 idle 以供下次使用
      if (_lock != null) {
        _lock!.complete();
        _lock = null;
      }
    }
  }

  /// 清理远端备份，保留最近 N 个。
  Future<void> _enforceRetentionPolicy(WebDavConfig config) async {
    try {
      final password =
          await _secureStorage.read(key: 'webdav_${config.configId}_password');
      if (password == null || password.isEmpty) return;

      final client = WebDavClient(
        baseUrl: config.url,
        username: config.username,
        password: password,
      );

      final propResult = await client.propfind(config.uploadPath, depth: 1);
      if (!propResult.success) {
        client.dispose();
        return;
      }

      // 筛选备份文件，按文件名时间戳排序
      final backupFiles = propResult.entries
          .where((e) =>
              !e.isCollection &&
              e.href.contains('motong_backup_') &&
              e.href.endsWith('.json.gz'))
          .toList()
        ..sort((a, b) => a.href.compareTo(b.href));

      final retention = config.retentionCount;
      if (backupFiles.length <= retention) {
        client.dispose();
        return;
      }

      // 删除超出保留数量的最旧文件
      final toDelete = backupFiles.sublist(0, backupFiles.length - retention);
      for (final entry in toDelete) {
        final fileName = entry.href.split('/').last;
        await client.delete('${config.uploadPath}/$fileName');
      }
      client.dispose();
    } catch (_) {
      // 清理失败静默处理
    }
  }

  // ---- 取消 ----

  /// P0-3 修复：cancel() 只设置取消标记，不释放锁。
  /// 锁由 backupNow 的 finally 块在操作彻底结束后释放。
  Future<void> cancel() async {
    _cancelled = true;
    _setStatus(BackupStatus.idle);
  }

  // ---- 内部辅助 ----

  void _setStatus(BackupStatus s) {
    _status = s;
  }

  void _reportProgress(
      double progress, String stage, int transferred, int total) {
    onProgress?.call(progress, stage, transferred, total);
  }

  /// P2-3 修复：标准 UUID v4 (RFC 4122)
  String _generateUuidV4() {
    final r = (int max) {
      final rand = _secureRandom.nextInt(max);
      return rand.toRadixString(16).padLeft(max.toRadixString(16).length - 1, '0');
    };
    // UUID v4: xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx
    // 其中 y = 8/9/a/b
    final a = r(0xffffffff)
        .padLeft(8, '0');
    final b = r(0xffff)
        .padLeft(4, '0');
    final c = '4${r(0xfff).toString().padLeft(3, '0')}';
    final d = '${(8 + _secureRandom.nextInt(4)).toRadixString(16)}${r(0xfff).toString().padLeft(3, '0')}';
    final e = r(0xffffffffffff)
        .toString()
        .padLeft(12, '0');
    return '$a-$b-$c-$d-$e';
  }

  static final _secureRandom = Random.secure();

  /// 简易 gzip 编码，使用 zlib 的 gzip 模式
  List<int> _gzipEncode(List<int> data) {
    return GZipCodec().encode(data);
  }
}