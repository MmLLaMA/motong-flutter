import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:crypto/crypto.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

import '../models/models.dart';
import 'webdav_client.dart';

/// 恢复阶段枚举。
enum RestoreStage {
  /// 校验备份文件完整性
  verifying,

  /// 下载备份文件
  downloading,

  /// 解析 JSON
  parsing,

  /// 写入数据到目标表
  writing,

  /// 完成
  done,

  /// 失败
  failed,
}

/// 恢复阶段回调。
typedef RestoreStageCallback = void Function(
    RestoreStage stage, double progress, String message);

/// 恢复结果。
class RestoreResult {
  final bool success;
  final int conversationsRestored;
  final int memoriesRestored;
  final int settingsRestored;
  final String? errorMessage;

  const RestoreResult({
    required this.success,
    this.conversationsRestored = 0,
    this.memoriesRestored = 0,
    this.settingsRestored = 0,
    this.errorMessage,
  });
}

/// 恢复预览信息。
class RestorePreview {
  final BackupManifest manifest;
  final int fileSizeBytes;
  final Map<String, int> localCounts;

  const RestorePreview({
    required this.manifest,
    required this.fileSizeBytes,
    this.localCounts = const {},
  });
}

/// 恢复服务 — GET 下载 → SHA-256 校验 → 解析 → 冲突检测 → 写入各模块。
class RestoreService {
  final FlutterSecureStorage _secureStorage;
  final RestoreStageCallback? onStageChange;
  bool _isBusy = false;

  RestoreStatus _status = RestoreStatus.idle;
  RestoreStatus get status => _status;
  bool get isBusy => _isBusy;

  /// 本地各表当前记录数查询回调
  Future<Map<String, int>> Function()? fetchLocalCountsHook;

  /// 写入对话记录回调
  Future<int> Function(List<Map<String, dynamic>> rows)? writeConversationsHook;

  /// 写入记忆数据回调
  Future<int> Function(List<Map<String, dynamic>> rows)? writeMemoriesHook;

  /// 写入设置数据回调
  Future<int> Function(Map<String, dynamic> settings)? writeSettingsHook;

  /// 清空所有表回调
  Future<void> Function()? wipeAllTablesHook;

  /// 清空对话表回调
  Future<void> Function()? wipeConversationsHook;

  /// 清空记忆表回调
  Future<void> Function()? wipeMemoriesHook;

  /// 清空设置表回调
  Future<void> Function()? wipeSettingsHook;

  RestoreService({
    FlutterSecureStorage? secureStorage,
    this.onStageChange,
  }) : _secureStorage = secureStorage ?? const FlutterSecureStorage();

  // ---- 公开 API ----

  /// P0-4 修复：预览备份内容——GET 下载、解压、解析 manifest。
  Future<RestorePreview?> preview({
    required WebDavConfig config,
    required String remoteFileName,
  }) async {
    try {
      final password =
          await _secureStorage.read(key: 'webdav_${config.configId}_password');
      if (password == null || password.isEmpty) return null;

      final client = WebDavClient(
        baseUrl: config.url,
        username: config.username,
        password: password,
      );

      // P0-4: 改为 GET 下载 + 解压 + 解析 manifest
      // 先尝试只下载前 64 KB（Range GET）以节省带宽
      final remoteBytes = await client.get(
        '${config.uploadPath}/$remoteFileName',
        rangeStart: 0,
        rangeEnd: 65535, // 64 KB
      );

      client.dispose();

      if (remoteBytes == null || remoteBytes.isEmpty) {
        return null;
      }

      // 尝试解压（gzip 支持截断流）
      final decompressed = _tryDecompressPartial(remoteBytes);
      if (decompressed == null) return null;

      final jsonStr = utf8.decode(decompressed);
      final envelope = jsonDecode(jsonStr) as Map<String, dynamic>?;
      if (envelope == null) return null;

      final manifestJson = envelope['manifest'] as Map<String, dynamic>?;
      if (manifestJson == null) return null;

      final manifest = BackupManifest.fromJson(manifestJson);

      // 完整文件大小（从 HEAD 获取，fallback 为 0）
      final headResult =
          await _head(config, remoteFileName);
      final fileSizeBytes = headResult?.contentLength ?? remoteBytes.length;

      // 获取本地计数与 manifest sections 对比
      Map<String, int> rawLocalCounts = <String, int>{};
      if (fetchLocalCountsHook != null) {
        rawLocalCounts = await fetchLocalCountsHook!.call();
      }
      final localCounts = <String, int>{};
      for (final section in manifest.sections) {
        final key = section.section.toString();
        localCounts[key] = rawLocalCounts[key] ?? 0;
      }

      return RestorePreview(
        manifest: manifest,
        fileSizeBytes: fileSizeBytes,
        localCounts: localCounts,
      );
    } catch (_) {
      return null;
    }
  }

  /// 辅助：HEAD 请求获取文件大小。
  Future<WebDavHeadResult?> _head(WebDavConfig config, String remoteFileName) async {
    try {
      final password =
          await _secureStorage.read(key: 'webdav_${config.configId}_password');
      if (password == null || password.isEmpty) return null;

      final client = WebDavClient(
        baseUrl: config.url,
        username: config.username,
        password: password,
      );
      final result = await client.head('${config.uploadPath}/$remoteFileName');
      client.dispose();
      return result;
    } catch (_) {
      return null;
    }
  }

  /// 尝试解压截断的 gzip 流。gzip 的 zlib 实现通常可在截断时输出已解码部分。
  List<int>? _tryDecompressPartial(List<int> data) {
    try {
      return GZipCodec().decode(data);
    } catch (_) {
      // 截断的 gzip 可能无法解压；尝试用 ZLibCodec（raw deflate）fallback
      try {
        return ZLibCodec(raw: true).decode(data);
      } catch (_) {
        return null;
      }
    }
  }

  /// 执行恢复操作。
  Future<RestoreResult> restore({
    required WebDavConfig config,
    required String remoteFileName,
    required RestoreStrategy strategy,
    RestoreConflictPolicy conflictPolicy = RestoreConflictPolicy.overwrite,
    Set<String> selectedSections = const {},
  }) async {
    if (_isBusy) {
      return const RestoreResult(success: false, errorMessage: '恢复已在进行中');
    }
    _isBusy = true;
    _setStatus(RestoreStatus.verifying);
    _reportStage(RestoreStage.verifying, 0.0, '准备恢复…');

    try {
      // 1. 获取密码
      final password =
          await _secureStorage.read(key: 'webdav_${config.configId}_password');
      if (password == null || password.isEmpty) {
        return const RestoreResult(
            success: false, errorMessage: '未找到 WebDAV 密码');
      }

      final client = WebDavClient(
        baseUrl: config.url,
        username: config.username,
        password: password,
      );

      final remotePath = '${config.uploadPath}/$remoteFileName';

      // 2. 下载
      _setStatus(RestoreStatus.downloading);
      _reportStage(RestoreStage.downloading, 0.1, '下载备份文件…');
      final bytes = await client.get(remotePath);
      client.dispose();

      if (bytes == null) {
        return const RestoreResult(
            success: false, errorMessage: '下载备份文件失败');
      }

      // 3. 解压
      _reportStage(RestoreStage.parsing, 0.3, '解压归档…');
      final decompressed = GZipCodec().decode(bytes);
      final jsonStr = utf8.decode(decompressed);
      final envelope = jsonDecode(jsonStr) as Map<String, dynamic>;

      // 4. 校验
      _setStatus(RestoreStatus.verifying);
      _reportStage(RestoreStage.verifying, 0.5, '校验数据完整性…');

      final manifest = envelope['manifest'] as Map<String, dynamic>?;
      if (manifest == null) {
        return const RestoreResult(
            success: false, errorMessage: '备份文件格式无效：缺少 manifest');
      }

      // 版本检查
      final formatVersion = manifest['format_version'] as String? ?? '';
      if (formatVersion != '1.0') {
        return RestoreResult(
          success: false,
          errorMessage: formatVersion.isEmpty
              ? '数据格式不支持'
              : '备份来自更高版本 App ($formatVersion)，请先更新墨瞳',
        );
      }

      // P0-1 修复（方案A）：SHA-256 校验 —— 对不含 checksum 的 JSON 明文做校验
      final expectedChecksum = manifest['checksum_sha256'] as String? ?? '';
      if (expectedChecksum.isNotEmpty) {
        // 构建不含 checksum 的 JSON 副本，重新序列化后计算 SHA-256
        final envelopeCopy = Map<String, dynamic>.from(envelope);
        final manifestCopy = Map<String, dynamic>.from(
            envelopeCopy['manifest'] as Map<String, dynamic>);
        manifestCopy['checksum_sha256'] = '';
        envelopeCopy['manifest'] = manifestCopy;
        final canonicalBytes = utf8.encode(jsonEncode(envelopeCopy));
        final actualChecksum = sha256.convert(canonicalBytes).toString();
        if (actualChecksum != expectedChecksum) {
          return const RestoreResult(
              success: false, errorMessage: '备份文件已损坏（校验和不匹配）');
        }
      }

      // 5. 解析数据段
      _reportStage(RestoreStage.parsing, 0.6, '解析数据段…');
      final data = envelope['data'] as Map<String, dynamic>;

      // 6. 写入
      _setStatus(RestoreStatus.writing);
      _reportStage(RestoreStage.writing, 0.7, '写入数据…');

      int chatsCount = 0;
      int memsCount = 0;
      int setsCount = 0;

      final conversations =
          (data['conversations'] as List<dynamic>?)?.cast<Map<String, dynamic>>() ?? [];
      final memories =
          (data['memories'] as List<dynamic>?)?.cast<Map<String, dynamic>>() ?? [];
      final settings = data['settings'] as Map<String, dynamic>?;

      if (strategy == RestoreStrategy.full) {
        // P2-5 修复：wipe 钩子为 null 时报错
        if (wipeAllTablesHook == null) {
          return const RestoreResult(
              success: false,
              errorMessage: '完整恢复需要清空所有表，但 wipe 钩子未注入');
        }
        await wipeAllTablesHook!();
        if (writeConversationsHook != null) {
          chatsCount = await writeConversationsHook!(conversations);
        }
        if (writeMemoriesHook != null) {
          memsCount = await writeMemoriesHook!(memories);
        }
        if (writeSettingsHook != null && settings != null) {
          setsCount = await writeSettingsHook!(settings);
        }
      } else if (strategy == RestoreStrategy.partial) {
        // 部分恢复
        if (selectedSections.contains('chats')) {
          if (wipeConversationsHook == null) {
            return const RestoreResult(
                success: false,
                errorMessage: '部分恢复需要清空对话表，但 wipeConversationsHook 未注入');
          }
          await wipeConversationsHook!();
          if (writeConversationsHook != null) {
            chatsCount = await writeConversationsHook!(conversations);
          }
        }
        if (selectedSections.contains('memories')) {
          if (wipeMemoriesHook == null) {
            return const RestoreResult(
                success: false,
                errorMessage: '部分恢复需要清空记忆表，但 wipeMemoriesHook 未注入');
          }
          await wipeMemoriesHook!();
          if (writeMemoriesHook != null) {
            memsCount = await writeMemoriesHook!(memories);
          }
        }
        if (selectedSections.contains('settings')) {
          if (wipeSettingsHook == null) {
            return const RestoreResult(
                success: false,
                errorMessage: '部分恢复需要清空设置表，但 wipeSettingsHook 未注入');
          }
          await wipeSettingsHook!();
          if (writeSettingsHook != null && settings != null) {
            setsCount = await writeSettingsHook!(settings);
          }
        }
      } else {
        // merge：追加
        if (selectedSections.isEmpty ||
            selectedSections.contains('chats')) {
          if (writeConversationsHook != null) {
            chatsCount = await writeConversationsHook!(conversations);
          }
        }
        if (selectedSections.isEmpty ||
            selectedSections.contains('memories')) {
          if (writeMemoriesHook != null) {
            memsCount = await writeMemoriesHook!(memories);
          }
        }
        if (selectedSections.isEmpty ||
            selectedSections.contains('settings')) {
          if (writeSettingsHook != null && settings != null) {
            setsCount = await writeSettingsHook!(settings);
          }
        }
      }

      _setStatus(RestoreStatus.done);
      _reportStage(RestoreStage.done, 1.0, '恢复完成');

      return RestoreResult(
        success: true,
        conversationsRestored: chatsCount,
        memoriesRestored: memsCount,
        settingsRestored: setsCount,
      );
    } catch (e) {
      return RestoreResult(success: false, errorMessage: e.toString());
    } finally {
      _isBusy = false;
    }
  }

  Future<void> cancel() async {
    _isBusy = false;
    _setStatus(RestoreStatus.idle);
  }

  // ---- 内部 ----

  void _setStatus(RestoreStatus s) {
    _status = s;
  }

  void _reportStage(RestoreStage stage, double progress, String message) {
    onStageChange?.call(stage, progress, message);
  }
}

/// 恢复状态枚举。
enum RestoreStatus {
  idle,
  verifying,
  downloading,
  parsing,
  writing,
  done,
  failed,
}