/// 模块 5 — 默认模型选择
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/providers/provider_manager.dart';

class DefaultModelPage extends StatelessWidget {
  const DefaultModelPage({super.key});

  @override
  Widget build(BuildContext context) {
    final pm = context.watch<ProviderManager>();
    return Scaffold(
      appBar: AppBar(title: const Text('默认模型')),
      body: ListView(
        children: pm.providers
            .map((p) => ExpansionTile(
                        title: Text(p.name),
                        children: p.models
                            .map((m) => RadioListTile<String>(
                                  title: Text(m.displayName),
                                  subtitle: Text(m.id,
                                      style: const TextStyle(fontSize: 11)),
                                  value: '${p.id}::${m.id}',
                                  groupValue: null,
                                  onChanged: (v) {},
                                ))
                            .toList(),
                      ))
            .toList(),
      ),
    );
  }
}