/// 模块 5 — 快捷短语管理
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/providers/settings_provider.dart';

class QuickPhrasesPage extends StatelessWidget {
  const QuickPhrasesPage({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<SettingsProvider>();
    final phrases = provider.settings.conversationSettings.quickPhrases;
    return Scaffold(
      appBar: AppBar(title: const Text('快捷短语')),
      body: ListView.builder(
        itemCount: phrases.length,
        itemBuilder: (context, index) {
          final p = phrases[index];
          return ListTile(
            leading: const Icon(Icons.flash_on),
            title: Text(p.content),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          showDialog(
            context: context,
            builder: (ctx) {
              final ctrl = TextEditingController();
              return AlertDialog(
                title: const Text('新建快捷短语'),
                content: TextField(controller: ctrl),
                actions: [
                  TextButton(
                      onPressed: () => Navigator.pop(ctx),
                      child: const Text('取消')),
                  TextButton(
                    onPressed: () {
                      final text = ctrl.text.trim();
                      if (text.isEmpty) return;
                      provider.updateConversation(
                        provider.settings.conversationSettings.copyWith(
                          quickPhrases: [
                            ...phrases,
                            QuickPhrase(
                              id: DateTime.now().millisecondsSinceEpoch
                                  .toString(),
                              content: text,
                            ),
                          ],
                        ),
                      );
                      Navigator.pop(ctx);
                    },
                    child: const Text('保存'),
                  ),
                ],
              );
            },
          );
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}