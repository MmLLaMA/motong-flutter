/// 模块 5 — 数据存储页（含子页：聊天记录、WebDAV、记忆）
import 'package:flutter/material.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';
import 'chat_records_page.dart';
import 'webdav_page.dart';
import '../../../memory/ui/memory_page.dart';

class DataStoragePage extends StatelessWidget {
  const DataStoragePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('数据存储')),
      body: ListView(
        children: [
          ListTile(
            leading: const Icon(LucideIcons.messageSquare, size: 22),
            title: const Text('聊天记录'),
            trailing: const Icon(LucideIcons.chevronRight, size: 18),
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => ChatRecordsPage()),
            ),
          ),
          ListTile(
            leading: const Icon(LucideIcons.cloudUpload, size: 22),
            title: const Text('WebDAV 备份'),
            trailing: const Icon(LucideIcons.chevronRight, size: 18),
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => WebDavPage()),
            ),
          ),
          ListTile(
            leading: const Icon(LucideIcons.brain, size: 22),
            title: const Text('记忆管理'),
            trailing: const Icon(LucideIcons.chevronRight, size: 18),
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => MemoryPage()),
            ),
          ),
        ],
      ),
    );
  }
}