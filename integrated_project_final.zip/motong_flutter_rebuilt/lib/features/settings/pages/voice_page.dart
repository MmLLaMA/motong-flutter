/// 模块 5 — 语音设置
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
'import providers/settings_provider.dart';
'import widgets/custom_bottom_sheet.dart';
import '../models/app_settings.dart';


class VoicePage extends StatelessWidget {
  const VoicePage({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<SettingsProvider>();
    final voice = provider.settings.voiceSettings;
    return Scaffold(
      appBar: AppBar(title: const Text('语音')),
      body: ListView(
        children: [
          ListTile(
            leading: const Icon(Icons.record_voice_over, size: 22),
            title: const Text('TTS 引擎'),
            subtitle: Text(_engineLabel(voice.engine)),
            onTap: () async {
              final selected = await CustomBottomSheet.showOptions<TtsEngine>(
                context: context,
                title: 'TTS 引擎',
                options: TtsEngine.values,
                labelBuilder: _engineLabel,
              );
              if (selected != null) {
                await provider.updateVoice(voice.copyWith(engine: selected));
              }
            },
          ),
          ListTile(
            leading: const Icon(Icons.speed, size: 22),
            title: const Text('语速'),
            subtitle: Slider(
              value: voice.speed,
              min: 0.5,
              max: 2.0,
              divisions: 15,
              label: voice.speed.toStringAsFixed(1),
              onChanged: (v) =>
                  provider.updateVoice(voice.copyWith(speed: v)),
            ),
            trailing: Text(voice.speed.toStringAsFixed(1)),
          ),
          ListTile(
            leading: const Icon(Icons.tune, size: 22),
            title: const Text('音调'),
            subtitle: Slider(
              value: voice.pitch,
              min: 0.5,
              max: 2.0,
              divisions: 15,
              label: voice.pitch.toStringAsFixed(1),
              onChanged: (v) =>
                  provider.updateVoice(voice.copyWith(pitch: v)),
            ),
            trailing: Text(voice.pitch.toStringAsFixed(1)),
          ),
        ],
      ),
    );
  }

  String _engineLabel(TtsEngine e) {
    switch (e) {
      case TtsEngine.edge:
        return 'Microsoft Edge TTS';
      case TtsEngine.system:
        return '系统 TTS';
      case TtsEngine.openai:
        return 'OpenAI TTS';
      default:
        return 'Microsoft Edge TTS';
    }
  }
}