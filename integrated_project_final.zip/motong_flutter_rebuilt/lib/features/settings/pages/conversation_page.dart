/// 模块 5 — 对话设置
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
'import providers/settings_provider.dart';
import 'quick_phrases_page.dart';
import 'default_model_page.dart';

class ConversationPage extends StatelessWidget {
  const ConversationPage({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<SettingsProvider>();
    final cs = provider.settings.conversationSettings;
    return Scaffold(
      appBar: AppBar(title: const Text('对话')),
      body: ListView(
        children: [
          SwitchListTile(
            secondary: const Icon(Icons.psychology, size: 22),
            title: const Text('自动提取记忆'),
            subtitle: const Text('长期记忆提取开关', style: TextStyle(fontSize: 12)),
            value: cs.autoExtractMemories,
            onChanged: (v) => provider.updateConversation(
              cs.copyWith(autoExtractMemories: v),
            ),
          ),
          ListTile(
            leading: const Icon(Icons.flash_on, size: 22),
            title: const Text('快捷短语'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => QuickPhrasesPage()),
            ),
          ),
          ListTile(
            leading: const Icon(Icons.smart_toy, size: 22),
            title: const Text('默认模型'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => DefaultModelPage()),
            ),
          ),
        ],
      ),
    );
  }
}