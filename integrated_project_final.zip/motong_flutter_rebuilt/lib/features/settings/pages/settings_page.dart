/// 模块 5 — 设置主页

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';
import '../../../core/providers/settings_provider.dart';
import 'appearance_page.dart';
import 'voice_page.dart';
import 'conversation_page.dart';
import 'proxy_page.dart';
import '../../phone_control/ui/phone_control_page.dart';
import 'about_page.dart';
import 'data_storage_page.dart';
import 'advanced_settings_page.dart';
import '../../agents/pages/providers_page.dart';
import '../../agents/pages/assistants_page.dart';

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('设置')),
      body: ListView(
        children: [
          _buildSection('外观与显示', [
            _Item('外观', LucideIcons.brush, AppearancePage(), context),
            _Item('语音', LucideIcons.volume2, VoicePage(), context),
          ]),
          _buildSection('对话与模型', [
            _Item('对话', LucideIcons.messageCircle, ConversationPage(), context),
            _Item('服务商管理', LucideIcons.server, ProvidersPage(), context),
            _Item('助手管理', LucideIcons.bot, AssistantsPage(), context),
          ]),
          _buildSection('网络与隐私', [
            _Item('代理', LucideIcons.network, ProxyPage(), context),
          ]),
          _buildSection('设备与控制', [
            _Item('手机控制', LucideIcons.smartphone, PhoneControlPage(), context),
          ]),
          _buildSection('数据', [
            _Item('数据存储', LucideIcons.database, DataStoragePage(), context),
          ]),
          _buildSection('其他', [
            _Item('高级设置', LucideIcons.settings2, AdvancedSettingsPage(), context),
            _Item('关于', LucideIcons.info, AboutPage(), context),
          ]),
        ],
      ),
    );
  }

  Widget _buildSection(String title, List<_Item> entries) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 4),
          child: Text(
            title,
            style: TextStyle(
              fontSize: 13,
              color: Colors.grey[600],
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
        ...entries,
      ],
    );
  }
}

class _Item extends StatelessWidget {
  final String title;
  final IconData icon;
  final Widget page;
  final BuildContext ctx;
  const _Item(this.title, this.icon, this.page, this.ctx);

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Icon(icon, size: 22),
      title: Text(title),
      trailing: const Icon(LucideIcons.chevronRight, size: 18),
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => page),
        );
      },
    );
  }
}