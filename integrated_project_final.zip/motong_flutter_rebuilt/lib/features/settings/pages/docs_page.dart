/// 模块 5 — 使用文档（占位）
import 'package:flutter/material.dart';

class DocsPage extends StatelessWidget {
  const DocsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('使用文档')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: const [
          Text('快速上手', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
          SizedBox(height: 12),
          Text('1. 在设置 > 服务商管理中配置大模型供应商（DeepSeek / 智谱 / OpenAI 等）'),
          SizedBox(height: 8),
          Text('2. 在助手管理中创建或编辑助手（绑定模型与系统提示词）'),
          SizedBox(height: 8),
          Text('3. 返回聊天界面，长按助手头像可快速切换'),
          SizedBox(height: 8),
          Text('4. 记忆系统会自动从对话中提取关键事实'),
          SizedBox(height: 24),
          Text('常见问题', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
          SizedBox(height: 12),
          Text('Q: 如何重置密码？'),
          Text('A: 密码通过设备 keystore 加密存储，无法导出或重置；卸载重装后需重新配置。'),
          SizedBox(height: 12),
          Text('Q: 记忆数据存储在哪？'),
          Text('A: 本地 Drift 数据库，路径由 drift_flutter 自动管理。'),
        ],
      ),
    );
  }
}