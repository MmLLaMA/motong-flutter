import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

/// P1-3 修复：WebDAV 备份设置入口 —— 导航壳。
///
/// 此页作为模块 5 设置页到模块 6 的路由壳，
/// 实际功能全部委托给 webdav_backup/ui/ 下的页面。
class WebDavPage extends StatelessWidget {
  const WebDavPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('数据备份')),
      body: ListView(
        children: [
          ListTile(
            leading: const Icon(Icons.cloud_upload),
            title: const Text('备份与恢复'),
            subtitle: const Text('管理备份设置、手动备份、从备份恢复'),
            trailing: const Icon(Icons.chevron_right),
            // P1-9: 使用 GoRouter context.push 替代 Navigator.pushNamed
            onTap: () => context.push('/backup'),
          ),
          ListTile(
            leading: const Icon(Icons.dns_outlined),
            title: const Text('WebDAV 配置'),
            subtitle: const Text('管理服务器连接与多配置'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => context.push('/backup/webdav-config'),
          ),
        ],
      ),
    );
  }
}