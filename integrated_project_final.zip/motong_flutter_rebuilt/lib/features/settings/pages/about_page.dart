/// 模块 5 — 关于页（含子页：文档、日志）
import 'package:flutter/material.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';
import 'docs_page.dart';
import 'logs_page.dart';

class AboutPage extends StatelessWidget {
  const AboutPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('关于')),
      body: ListView(
        children: [
          const SizedBox(height: 24),
          Center(
            child: Column(
              children: [
                Icon(LucideIcons.eye, size: 64, color: Colors.blue[400]),
                const SizedBox(height: 12),
                const Text('墨瞳', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w600)),
                const SizedBox(height: 4),
                Text('v3.0.0+1', style: TextStyle(color: Colors.grey[600])),
                const SizedBox(height: 16),
                Text('陪伴型 AI 助手', style: TextStyle(color: Colors.grey[700])),
              ],
            ),
          ),
          const Divider(height: 48),
          ListTile(
            leading: const Icon(LucideIcons.bookOpen, size: 22),
            title: const Text('使用文档'),
            trailing: const Icon(LucideIcons.chevronRight, size: 18),
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => DocsPage()),
            ),
          ),
          ListTile(
            leading: const Icon(LucideIcons.scrollText, size: 22),
            title: const Text('运行日志'),
            trailing: const Icon(LucideIcons.chevronRight, size: 18),
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => LogsPage()),
            ),
          ),
        ],
      ),
    );
  }
}