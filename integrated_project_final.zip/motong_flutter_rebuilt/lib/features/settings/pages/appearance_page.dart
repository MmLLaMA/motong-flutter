/// 模块 5 — 外观设置
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
'import providers/settings_provider.dart';
'import widgets/custom_bottom_sheet.dart';
import '../models/app_settings.dart';


class AppearancePage extends StatelessWidget {
  const AppearancePage({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<SettingsProvider>();
    final appearance = provider.settings.appearanceSettings;
    return Scaffold(
      appBar: AppBar(title: const Text('外观')),
      body: ListView(
        children: [
          ListTile(
            leading: const Icon(Icons.dark_mode, size: 22),
            title: const Text('颜色模式'),
            subtitle: Text(_modeLabel(appearance.colorMode)),
            trailing: const Icon(Icons.chevron_right),
            onTap: () async {
              final selected = await CustomBottomSheet.showOptions<AppColorMode>(
                context: context,
                title: '颜色模式',
                options: AppColorMode.values,
                labelBuilder: _modeLabel,
              );
              if (selected != null) {
                await provider.updateAppearance(
                  appearance.copyWith(colorMode: selected),
                );
              }
            },
          ),
          ListTile(
            leading: const Icon(Icons.text_fields, size: 22),
            title: const Text('字体大小'),
            subtitle: Slider(
              value: appearance.fontSize,
              min: 12,
              max: 24,
              divisions: 12,
              label: appearance.fontSize.toStringAsFixed(0),
              onChanged: (v) {
                provider.updateAppearance(appearance.copyWith(fontSize: v));
              },
            ),
            trailing: Text(appearance.fontSize.toStringAsFixed(0)),
          ),
        ],
      ),
    );
  }

  String _modeLabel(AppColorMode m) {
    switch (m) {
      case AppColorMode.system:
        return '跟随系统';
      case AppColorMode.light:
        return '浅色';
      case AppColorMode.dark:
        return '深色';
      default:
        return '跟随系统';
    }
  }
}