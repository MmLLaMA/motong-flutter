/// 模块 5 — 聊天记录管理（占位骨架）
import 'package:flutter/material.dart';

class ChatRecordsPage extends StatelessWidget {
  const ChatRecordsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('聊天记录')),
      body: const Center(
        child: Padding(
          padding: EdgeInsets.all(32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.inbox_outlined, size: 64, color: Colors.grey),
              SizedBox(height: 16),
              Text('聊天记录管理', style: TextStyle(fontSize: 18)),
              SizedBox(height: 8),
              Text('即将推出：导出 / 导入 / 批量删除',
                  style: TextStyle(color: Colors.grey)),
            ],
          ),
        ),
      ),
    );
  }
}