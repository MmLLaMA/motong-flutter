/// 模块 5 — 高级设置
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
'import providers/settings_provider.dart';

class AdvancedSettingsPage extends StatelessWidget {
  const AdvancedSettingsPage({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<SettingsProvider>();
    final adv = provider.settings.advancedSettings;
    return Scaffold(
      appBar: AppBar(title: const Text('高级设置')),
      body: ListView(
        children: [
          SwitchListTile(
            secondary: const Icon(Icons.bug_report, size: 22),
            title: const Text('调试模式'),
            subtitle: const Text('显示详细日志', style: TextStyle(fontSize: 12)),
            value: adv.debugMode,
            onChanged: (v) =>
                provider.updateAdvanced(adv.copyWith(debugMode: v)),
          ),
          SwitchListTile(
            secondary: const Icon(Icons.analytics, size: 22),
            title: const Text('启用遥测'),
            subtitle: const Text('匿名使用统计', style: TextStyle(fontSize: 12)),
            value: adv.enableTelemetry,
            onChanged: (v) =>
                provider.updateAdvanced(adv.copyWith(enableTelemetry: v)),
          ),
          SwitchListTile(
            secondary: const Icon(Icons.science, size: 22),
            title: const Text('实验性功能'),
            subtitle: const Text('可能不稳定的特性', style: TextStyle(fontSize: 12)),
            value: adv.enableExperimentalFeatures,
            onChanged: (v) => provider.updateAdvanced(
              adv.copyWith(enableExperimentalFeatures: v),
            ),
          ),
        ],
      ),
    );
  }
}