/// 模块 5 — 应用设置聚合根 + 7 子模型
/// P0-1 修复：ProxySettings / WebDAVSettings 密码改为 nullable
/// 实际密码通过 flutter_secure_storage 存储，本模型只保留占位字段
/// P0-2 修复：fromLegacyJson 工厂兼容旧 SP 格式（含 flat 字段映射）

import 'dart:convert';
import 'package:uuid/uuid.dart';

class AppSettings {
  final AppearanceSettings appearanceSettings;
  final VoiceSettings voiceSettings;
  final ConversationSettings conversationSettings;
  final ProxySettings proxySettings;
  final DataStorageSettings dataStorageSettings;
  final PhoneControlSettings phoneControlSettings;
  final AdvancedSettings advancedSettings;

  AppSettings({
    this.appearanceSettings = const AppearanceSettings(),
    this.voiceSettings = const VoiceSettings(),
    this.conversationSettings = const ConversationSettings(),
    this.proxySettings = const ProxySettings(),
    this.dataStorageSettings = const DataStorageSettings(),
    this.phoneControlSettings = const PhoneControlSettings(),
    this.advancedSettings = const AdvancedSettings(),
  });

  factory AppSettings.fromJson(Map<String, dynamic> json) {
    return AppSettings(
      appearanceSettings: json['appearance_settings'] != null
          ? AppearanceSettings.fromJson(json['appearance_settings'] as Map<String, dynamic>)
          : const AppearanceSettings(),
      voiceSettings: json['voice_settings'] != null
          ? VoiceSettings.fromJson(json['voice_settings'] as Map<String, dynamic>)
          : const VoiceSettings(),
      conversationSettings: json['conversation_settings'] != null
          ? ConversationSettings.fromJson(json['conversation_settings'] as Map<String, dynamic>)
          : const ConversationSettings(),
      proxySettings: json['proxy_settings'] != null
          ? ProxySettings.fromJson(json['proxy_settings'] as Map<String, dynamic>)
          : const ProxySettings(),
      dataStorageSettings: json['data_storage_settings'] != null
          ? DataStorageSettings.fromJson(json['data_storage_settings'] as Map<String, dynamic>)
          : const DataStorageSettings(),
      phoneControlSettings: json['phone_control_settings'] != null
          ? PhoneControlSettings.fromJson(json['phone_control_settings'] as Map<String, dynamic>)
          : const PhoneControlSettings(),
      advancedSettings: json['advanced_settings'] != null
          ? AdvancedSettings.fromJson(json['advanced_settings'] as Map<String, dynamic>)
          : const AdvancedSettings(),
    );
  }

  Map<String, dynamic> toJson() => {
        'appearance_settings': appearanceSettings.toJson(),
        'voice_settings': voiceSettings.toJson(),
        'conversation_settings': conversationSettings.toJson(),
        'proxy_settings': proxySettings.toJson(),
        'data_storage_settings': dataStorageSettings.toJson(),
        'phone_control_settings': phoneControlSettings.toJson(),
        'advanced_settings': advancedSettings.toJson(),
      };

  /// P0-2: 兼容旧 SP 格式（flat + 嵌套混合字段）
  /// 旧 SP 中字段可能平铺在顶层（如 proxyPassword / webdavPassword）
  /// 也可能嵌套在子对象中。本工厂做兼容映射，缺失字段用默认值。
  factory AppSettings.fromLegacyJson(Map<String, dynamic> json) {
    return AppSettings(
      appearanceSettings: _extractAppearance(json),
      voiceSettings: _extractVoice(json),
      conversationSettings: _extractConversation(json),
      proxySettings: _extractProxy(json),
      dataStorageSettings: _extractDataStorage(json),
      phoneControlSettings: _extractPhoneControl(json),
      advancedSettings: _extractAdvanced(json),
    );
  }

  static AppearanceSettings _extractAppearance(Map<String, dynamic> json) {
    final src = (json['appearance_settings'] ?? json) as Map<String, dynamic>;
    return AppearanceSettings(
      colorMode: _parseEnum(AppColorMode.values,
          src['color_mode'] as String? ?? src['colorMode'] as String?,
          AppColorMode.system),
      fontSize: (src['font_size'] as num? ?? src['fontSize'] as num?)
              ?.toDouble() ??
          14.0,
      themeColor: (src['theme_color'] as String? ??
              src['themeColor'] as String?) ??
          '#6B8E9F',
    );
  }

  static VoiceSettings _extractVoice(Map<String, dynamic> json) {
    final src = (json['voice_settings'] ?? json) as Map<String, dynamic>;
    return VoiceSettings(
      engine: _parseEnum(TtsEngine.values,
          src['engine'] as String?, TtsEngine.edge),
      speed: (src['speed'] as num?)?.toDouble() ?? 1.0,
      pitch: (src['pitch'] as num?)?.toDouble() ?? 1.0,
      voiceId: (src['voice_id'] as String? ?? src['voiceId'] as String? ?? 'zh-CN-YunxiNeural') as String,
    );
  }

  static ConversationSettings _extractConversation(Map<String, dynamic> json) {
    final src = (json['conversation_settings'] ?? json) as Map<String, dynamic>;
    return ConversationSettings(
      defaultAssistantId: src['default_assistant_id'] as String? ??
          src['defaultAssistantId'] as String?,
      defaultModelId: src['default_model_id'] as String? ??
          src['defaultModelId'] as String?,
      quickPhrases:
          ((src['quick_phrases'] as List<dynamic>? ?? src['quickPhrases'] as List<dynamic>?) ?? [])
              .map((e) => QuickPhrase.fromJson(e as Map<String, dynamic>))
              .toList(),
      autoExtractMemories: (src['auto_extract_memories'] as bool? ??
              src['autoExtractMemories'] as bool?) ??
          true,
    );
  }

  static ProxySettings _extractProxy(Map<String, dynamic> json) {
    final src = (json['proxy_settings'] ?? json) as Map<String, dynamic>;
    return ProxySettings(
      enabled: (src['enabled'] as bool?) ?? false,
      host: (src['host'] as String?) ?? '',
      port: (src['port'] as num?)?.toInt() ?? 8080,
      username: src['username'] as String?,
      // P0-1: 旧 SP 中的明文密码由 Provider 迁移到 secure storage，模型内永远不持留
      password: null,
    );
  }

  static DataStorageSettings _extractDataStorage(Map<String, dynamic> json) {
    final src = (json['data_storage_settings'] ?? json) as Map<String, dynamic>;
    final webDavSrc = (src['webdav'] ?? src) as Map<String, dynamic>;
    return DataStorageSettings(
      webDav: WebDavSettings(
        enabled: (webDavSrc['enabled'] as bool?) ?? false,
        url: (webDavSrc['url'] as String?) ?? '',
        username: (webDavSrc['username'] as String?) ?? '',
        // P0-1: 密码由 Provider 迁移，模型不持留
        password: null,
        autoBackup: (webDavSrc['auto_backup'] as bool? ??
                webDavSrc['autoBackup'] as bool?) ??
            false,
      ),
    );
  }

  static PhoneControlSettings _extractPhoneControl(Map<String, dynamic> json) {
    final src = (json['phone_control_settings'] ?? json) as Map<String, dynamic>;
    return PhoneControlSettings(
      interceptBackKey: (src['intercept_back_key'] as bool? ??
              src['interceptBackKey'] as bool?) ??
          true,
      interceptHomeKey: (src['intercept_home_key'] as bool? ??
              src['interceptHomeKey'] as bool?) ??
          true,
      interceptTaskKey: (src['intercept_task_key'] as bool? ??
              src['interceptTaskKey'] as bool?) ??
          true,
      enableCamera: (src['enable_camera'] as bool? ??
              src['enableCamera'] as bool?) ??
          true,
      enableMicrophone: (src['enable_microphone'] as bool? ??
              src['enableMicrophone'] as bool?) ??
          true,
    );
  }

  static AdvancedSettings _extractAdvanced(Map<String, dynamic> json) {
    final src = (json['advanced_settings'] ?? json) as Map<String, dynamic>;
    return AdvancedSettings(
      debugMode: (src['debug_mode'] as bool? ?? src['debugMode'] as bool?) ?? false,
      enableTelemetry: (src['enable_telemetry'] as bool? ??
              src['enableTelemetry'] as bool?) ??
          false,
      enableExperimentalFeatures:
          (src['enable_experimental_features'] as bool? ??
                  src['enableExperimentalFeatures'] as bool?) ??
              false,
    );
  }

  static T _parseEnum<T>(List<T> values, String? name, T defaultVal) {
    if (name == null) return defaultVal;
    return values.cast<dynamic>().firstWhere(
          (e) => (e as dynamic).name == name,
          orElse: () => defaultVal,
        ) as T;
  }

  AppSettings copyWith({
    AppearanceSettings? appearanceSettings,
    VoiceSettings? voiceSettings,
    ConversationSettings? conversationSettings,
    ProxySettings? proxySettings,
    DataStorageSettings? dataStorageSettings,
    PhoneControlSettings? phoneControlSettings,
    AdvancedSettings? advancedSettings,
  }) =>
      AppSettings(
        appearanceSettings: appearanceSettings ?? this.appearanceSettings,
        voiceSettings: voiceSettings ?? this.voiceSettings,
        conversationSettings: conversationSettings ?? this.conversationSettings,
        proxySettings: proxySettings ?? this.proxySettings,
        dataStorageSettings: dataStorageSettings ?? this.dataStorageSettings,
        phoneControlSettings: phoneControlSettings ?? this.phoneControlSettings,
        advancedSettings: advancedSettings ?? this.advancedSettings,
      );
}

// ==================== 外观 ====================

enum AppColorMode { system, light, dark }

class AppearanceSettings {
  final AppColorMode colorMode;
  final double fontSize;
  final String themeColor;

  const AppearanceSettings({
    this.colorMode = AppColorMode.system,
    this.fontSize = 14.0,
    this.themeColor = '#6B8E9F',
  });

  factory AppearanceSettings.fromJson(Map<String, dynamic> json) {
    return AppearanceSettings(
      colorMode: AppColorMode.values.firstWhere(
        (e) => e.name == json['color_mode'],
        orElse: () => AppColorMode.system,
      ),
      fontSize: (json['font_size'] as num?)?.toDouble() ?? 14.0,
      themeColor: json['theme_color'] as String? ?? '#6B8E9F',
    );
  }

  Map<String, dynamic> toJson() => {
        'color_mode': colorMode.name,
        'font_size': fontSize,
        'theme_color': themeColor,
      };

  AppearanceSettings copyWith({
    AppColorMode? colorMode,
    double? fontSize,
    String? themeColor,
  }) =>
      AppearanceSettings(
        colorMode: colorMode ?? this.colorMode,
        fontSize: fontSize ?? this.fontSize,
        themeColor: themeColor ?? this.themeColor,
      );
}

// ==================== 语音 ====================

enum TtsEngine { edge, system, openai }

class VoiceSettings {
  final TtsEngine engine;
  final double speed;
  final double pitch;
  final String voiceId;

  const VoiceSettings({
    this.engine = TtsEngine.edge,
    this.speed = 1.0,
    this.pitch = 1.0,
    this.voiceId = 'zh-CN-YunxiNeural',
  });

  factory VoiceSettings.fromJson(Map<String, dynamic> json) {
    return VoiceSettings(
      engine: TtsEngine.values.firstWhere(
        (e) => e.name == json['engine'],
        orElse: () => TtsEngine.edge,
      ),
      speed: (json['speed'] as num?)?.toDouble() ?? 1.0,
      pitch: (json['pitch'] as num?)?.toDouble() ?? 1.0,
      voiceId: json['voice_id'] as String? ?? 'zh-CN-YunxiNeural',
    );
  }

  Map<String, dynamic> toJson() => {
        'engine': engine.name,
        'speed': speed,
        'pitch': pitch,
        'voice_id': voiceId,
      };

  VoiceSettings copyWith({
    TtsEngine? engine,
    double? speed,
    double? pitch,
    String? voiceId,
  }) =>
      VoiceSettings(
        engine: engine ?? this.engine,
        speed: speed ?? this.speed,
        pitch: pitch ?? this.pitch,
        voiceId: voiceId ?? this.voiceId,
      );
}

// ==================== 对话 ====================

class QuickPhrase {
  final String id;
  final String content;
  const QuickPhrase({required this.id, required this.content});

  factory QuickPhrase.fromJson(Map<String, dynamic> json) =>
      QuickPhrase(id: json['id'] as String, content: json['content'] as String);
  Map<String, dynamic> toJson() => {'id': id, 'content': content};
}

class ConversationSettings {
  final String? defaultAssistantId;
  final String? defaultModelId;
  final List<QuickPhrase> quickPhrases;
  final bool autoExtractMemories;

  const ConversationSettings({
    this.defaultAssistantId,
    this.defaultModelId,
    this.quickPhrases = const [],
    this.autoExtractMemories = true,
  });

  factory ConversationSettings.fromJson(Map<String, dynamic> json) {
    return ConversationSettings(
      defaultAssistantId: json['default_assistant_id'] as String?,
      defaultModelId: json['default_model_id'] as String?,
      quickPhrases: ((json['quick_phrases'] as List<dynamic>?) ?? [])
          .map((e) => QuickPhrase.fromJson(e as Map<String, dynamic>))
          .toList(),
      autoExtractMemories: json['auto_extract_memories'] as bool? ?? true,
    );
  }

  Map<String, dynamic> toJson() => {
        'default_assistant_id': defaultAssistantId,
        'default_model_id': defaultModelId,
        'quick_phrases': quickPhrases.map((e) => e.toJson()).toList(),
        'auto_extract_memories': autoExtractMemories,
      };

  ConversationSettings copyWith({
    String? defaultAssistantId,
    String? defaultModelId,
    List<QuickPhrase>? quickPhrases,
    bool? autoExtractMemories,
  }) =>
      ConversationSettings(
        defaultAssistantId: defaultAssistantId ?? this.defaultAssistantId,
        defaultModelId: defaultModelId ?? this.defaultModelId,
        quickPhrases: quickPhrases ?? this.quickPhrases,
        autoExtractMemories: autoExtractMemories ?? this.autoExtractMemories,
      );
}

// ==================== 代理 ====================
/// P0-1 修复：password 字段为 nullable
/// 实际密码通过 flutter_secure_storage 单独存储

class ProxySettings {
  final bool enabled;
  final String host;
  final int port;
  final String? username;
  final String? password; // nullable，密码单独存于 flutter_secure_storage

  const ProxySettings({
    this.enabled = false,
    this.host = '',
    this.port = 8080,
    this.username,
    this.password,
  });

  factory ProxySettings.fromJson(Map<String, dynamic> json) {
    return ProxySettings(
      enabled: json['enabled'] as bool? ?? false,
      host: json['host'] as String? ?? '',
      port: (json['port'] as num?)?.toInt() ?? 8080,
      username: json['username'] as String?,
      password: null, // 永远不解析明文密码
    );
  }

  Map<String, dynamic> toJson() => {
        'enabled': enabled,
        'host': host,
        'port': port,
        'username': username,
        // 永远不写入明文密码
      };

  ProxySettings copyWith({
    bool? enabled,
    String? host,
    int? port,
    String? username,
    String? password,
    bool clearPassword = false,
  }) =>
      ProxySettings(
        enabled: enabled ?? this.enabled,
        host: host ?? this.host,
        port: port ?? this.port,
        username: username ?? this.username,
        password: clearPassword ? null : (password ?? this.password),
      );
}

// ==================== 数据存储 ====================

class WebDavSettings {
  final bool enabled;
  final String url;
  final String username;
  final String? password; // P0-1: nullable，独立加密存储
  final bool autoBackup;

  const WebDavSettings({
    this.enabled = false,
    this.url = '',
    this.username = '',
    this.password,
    this.autoBackup = false,
  });

  factory WebDavSettings.fromJson(Map<String, dynamic> json) {
    return WebDavSettings(
      enabled: json['enabled'] as bool? ?? false,
      url: json['url'] as String? ?? '',
      username: json['username'] as String? ?? '',
      password: null, // 永远不解析明文密码
      autoBackup: json['auto_backup'] as bool? ?? false,
    );
  }

  Map<String, dynamic> toJson() => {
        'enabled': enabled,
        'url': url,
        'username': username,
        'auto_backup': autoBackup,
        // 永远不写入明文密码
      };

  WebDavSettings copyWith({
    bool? enabled,
    String? url,
    String? username,
    String? password,
    bool? autoBackup,
    bool clearPassword = false,
  }) =>
      WebDavSettings(
        enabled: enabled ?? this.enabled,
        url: url ?? this.url,
        username: username ?? this.username,
        password: clearPassword ? null : (password ?? this.password),
        autoBackup: autoBackup ?? this.autoBackup,
      );
}

class DataStorageSettings {
  final WebDavSettings webDav;

  const DataStorageSettings({this.webDav = const WebDavSettings()});

  factory DataStorageSettings.fromJson(Map<String, dynamic> json) {
    return DataStorageSettings(
      webDav: json['webdav'] != null
          ? WebDavSettings.fromJson(json['webdav'] as Map<String, dynamic>)
          : const WebDavSettings(),
    );
  }

  Map<String, dynamic> toJson() => {'webdav': webDav.toJson()};

  DataStorageSettings copyWith({WebDavSettings? webDav}) =>
      DataStorageSettings(webDav: webDav ?? this.webDav);
}

// ==================== 手机控制 ====================

class PhoneControlSettings {
  final bool interceptBackKey;
  final bool interceptHomeKey;
  final bool interceptTaskKey;
  final bool enableCamera;
  final bool enableMicrophone;

  const PhoneControlSettings({
    this.interceptBackKey = true,
    this.interceptHomeKey = true,
    this.interceptTaskKey = true,
    this.enableCamera = true,
    this.enableMicrophone = true,
  });

  factory PhoneControlSettings.fromJson(Map<String, dynamic> json) {
    return PhoneControlSettings(
      interceptBackKey: json['intercept_back_key'] as bool? ?? true,
      interceptHomeKey: json['intercept_home_key'] as bool? ?? true,
      interceptTaskKey: json['intercept_task_key'] as bool? ?? true,
      enableCamera: json['enable_camera'] as bool? ?? true,
      enableMicrophone: json['enable_microphone'] as bool? ?? true,
    );
  }

  Map<String, dynamic> toJson() => {
        'intercept_back_key': interceptBackKey,
        'intercept_home_key': interceptHomeKey,
        'intercept_task_key': interceptTaskKey,
        'enable_camera': enableCamera,
        'enable_microphone': enableMicrophone,
      };

  PhoneControlSettings copyWith({
    bool? interceptBackKey,
    bool? interceptHomeKey,
    bool? interceptTaskKey,
    bool? enableCamera,
    bool? enableMicrophone,
  }) =>
      PhoneControlSettings(
        interceptBackKey: interceptBackKey ?? this.interceptBackKey,
        interceptHomeKey: interceptHomeKey ?? this.interceptHomeKey,
        interceptTaskKey: interceptTaskKey ?? this.interceptTaskKey,
        enableCamera: enableCamera ?? this.enableCamera,
        enableMicrophone: enableMicrophone ?? this.enableMicrophone,
      );
}

// ==================== 高级 ====================

class AdvancedSettings {
  final bool debugMode;
  final bool enableTelemetry;
  final bool enableExperimentalFeatures;

  const AdvancedSettings({
    this.debugMode = false,
    this.enableTelemetry = false,
    this.enableExperimentalFeatures = false,
  });

  factory AdvancedSettings.fromJson(Map<String, dynamic> json) {
    return AdvancedSettings(
      debugMode: json['debug_mode'] as bool? ?? false,
      enableTelemetry: json['enable_telemetry'] as bool? ?? false,
      enableExperimentalFeatures:
          json['enable_experimental_features'] as bool? ?? false,
    );
  }

  Map<String, dynamic> toJson() => {
        'debug_mode': debugMode,
        'enable_telemetry': enableTelemetry,
        'enable_experimental_features': enableExperimentalFeatures,
      };

  AdvancedSettings copyWith({
    bool? debugMode,
    bool? enableTelemetry,
    bool? enableExperimentalFeatures,
  }) =>
      AdvancedSettings(
        debugMode: debugMode ?? this.debugMode,
        enableTelemetry: enableTelemetry ?? this.enableTelemetry,
        enableExperimentalFeatures:
            enableExperimentalFeatures ?? this.enableExperimentalFeatures,
      );
}