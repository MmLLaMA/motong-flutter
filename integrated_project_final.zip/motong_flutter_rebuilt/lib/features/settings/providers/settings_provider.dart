/// 模块 5 — 设置 Provider
/// P0-2 修复：用 Drift 单行表存储 AppSettings JSON（替代 SharedPreferences）
/// P0-1 修复：密码字段单独存于 flutter_secure_storage

import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:drift/drift.dart';
import 'package:drift_flutter/drift_flutter.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import '../models/app_settings.dart';

/// 单行 settings 表
class AppSettingsDatabase extends GeneratedDatabase {
  AppSettingsDatabase() : super(_open());

  static QueryExecutor _open() {
    return driftDatabase(name: 'motong_settings');
  }

  @override
  int get schemaVersion => 1;

  @override
  MigrationStrategy get migration => MigrationStrategy(
        onCreate: (m) async {
          await customStatement('''
            CREATE TABLE IF NOT EXISTS app_settings (
              id INTEGER PRIMARY KEY CHECK (id = 1),
              data_json TEXT NOT NULL,
              updated_at INTEGER NOT NULL
            )
          ''');
        },
      );
}

class SettingsProvider extends ChangeNotifier {
  final AppSettingsDatabase _db;
  final FlutterSecureStorage _secureStorage =
      const FlutterSecureStorage();

  AppSettings _settings = AppSettings();
  AppSettings get settings => _settings;

  Future<void>? _lastSave;

  // 安全存储 key
  static const _kProxyPassword = 'motong.proxy.password';
  static const _kWebDavPassword = 'motong.webdav.password';

  SettingsProvider({AppSettingsDatabase? database})
      : _db = database ?? AppSettingsDatabase() {
    _loadFromDb();
  }

  // ========== 加载 / 持久化 ==========

  Future<void> _loadFromDb() async {
    try {
      final rows = await _db
          .customSelect('SELECT data_json FROM app_settings WHERE id = 1')
          .getSingleOrNull();
      if (rows != null) {
        final data = jsonDecode(rows.data['data_json'] as String)
            as Map<String, dynamic>;
        _settings = AppSettings.fromJson(data);
      }
      // 加载安全字段
      await _loadSecureFields();
      notifyListeners();
    } catch (e) {
      debugPrint('SettingsProvider load failed: $e');
    }
  }

  Future<void> _loadSecureFields() async {
    try {
      final proxyPwd = await _secureStorage.read(key: _kProxyPassword);
      final webDavPwd = await _secureStorage.read(key: _kWebDavPassword);
      if (proxyPwd != null) {
        _settings = _settings.copyWith(
          proxySettings: _settings.proxySettings.copyWith(password: proxyPwd),
        );
      }
      if (webDavPwd != null) {
        _settings = _settings.copyWith(
          dataStorageSettings: _settings.dataStorageSettings.copyWith(
            webDav: _settings.dataStorageSettings.webDav
                .copyWith(password: webDavPwd),
          ),
        );
      }
    } catch (e) {
      debugPrint('SecureStorage load failed: $e');
    }
  }

  /// 写入 Drift（不含密码）
  Future<void> _persistToDrift() async {
    final now = DateTime.now().millisecondsSinceEpoch;
    final json = jsonEncode(_settings.toJson());
    await _db.customStatement(
      'INSERT OR REPLACE INTO app_settings (id, data_json, updated_at) VALUES (1, ?, ?)',
      [json, now],
    );
    notifyListeners();
  }

  /// 序列化持久化调用，保证 FIFO + 前序异常不阻塞后续任务
  Future<void> _runSerialized(Future<void> Function() task) async {
    _lastSave = (_lastSave ?? Future.value())
        .catchError((_) {/* swallow prev error, queue continues */})
        .then((_) => task());
    return _lastSave!;
  }

  // ========== 更新入口 ==========

  Future<void> updateAppearance(AppearanceSettings appearance) async {
    _settings = _settings.copyWith(appearanceSettings: appearance);
    await _runSerialized(() => _persistToDrift());
  }

  Future<void> updateVoice(VoiceSettings voice) async {
    _settings = _settings.copyWith(voiceSettings: voice);
    await _runSerialized(() => _persistToDrift());
  }

  Future<void> updateConversation(ConversationSettings conversation) async {
    _settings = _settings.copyWith(conversationSettings: conversation);
    await _runSerialized(() => _persistToDrift());
  }

  /// 代理：含密码，密码走 secure storage
  Future<void> updateProxy({
    bool? enabled,
    String? host,
    int? port,
    String? username,
    String? password,
    bool clearPassword = false,
  }) async {
    var updated = _settings.proxySettings.copyWith(
      enabled: enabled,
      host: host,
      port: port,
      username: username,
    );
    if (clearPassword) {
      await _secureStorage.delete(key: _kProxyPassword);
      updated = updated.copyWith(clearPassword: true);
    } else if (password != null && password.isNotEmpty) {
      await _secureStorage.write(key: _kProxyPassword, value: password);
      updated = updated.copyWith(password: password);
    }
    _settings = _settings.copyWith(proxySettings: updated);
    await _runSerialized(() => _persistToDrift());
  }

  /// WebDAV：含密码
  Future<void> updateWebDav({
    bool? enabled,
    String? url,
    String? username,
    String? password,
    bool? autoBackup,
    bool clearPassword = false,
  }) async {
    var webDav = _settings.dataStorageSettings.webDav.copyWith(
      enabled: enabled,
      url: url,
      username: username,
      autoBackup: autoBackup,
    );
    if (clearPassword) {
      await _secureStorage.delete(key: _kWebDavPassword);
      webDav = webDav.copyWith(clearPassword: true);
    } else if (password != null && password.isNotEmpty) {
      await _secureStorage.write(key: _kWebDavPassword, value: password);
      webDav = webDav.copyWith(password: password);
    }
    _settings = _settings.copyWith(
      dataStorageSettings:
          _settings.dataStorageSettings.copyWith(webDav: webDav),
    );
    await _runSerialized(() => _persistToDrift());
  }

  Future<void> updatePhoneControl(PhoneControlSettings phoneControl) async {
    _settings = _settings.copyWith(phoneControlSettings: phoneControl);
    await _runSerialized(() => _persistToDrift());
  }

  Future<void> updateAdvanced(AdvancedSettings advanced) async {
    _settings = _settings.copyWith(advancedSettings: advanced);
    await _runSerialized(() => _persistToDrift());
  }

  /// 一次性批量替换整个 AppSettings
  Future<void> replace(AppSettings newSettings) async {
    _settings = newSettings;
    await _runSerialized(() => _persistToDrift());
  }

  /// 主题模式便捷访问
  AppColorMode get colorMode => _settings.appearanceSettings.colorMode;

  /// 是否深色主题
  bool get isDark => colorMode == AppColorMode.dark;

  @override
  void dispose() {
    _db.close();
    super.dispose();
  }
}