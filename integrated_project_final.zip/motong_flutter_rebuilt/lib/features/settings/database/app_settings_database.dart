// ═══════════════════════════════════════════════════
// P1-3 修复：数据库 migration onUpgrade
//
// 旧注释使用了 m.customStatement('ALTER TABLE ... ADD COLUMN ...')
// 这不是 Drift Migrator 的有效 API。
//
// Drift 的正确写法是 m.addColumn(table, table.column)。
// ═══════════════════════════════════════════════════

import 'package:drift/drift.dart';
import 'package:drift/native.dart';

/// app_settings 表的 Drift 定义
class AppSettingsTable extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get data => text()();

  // 示例：未来新增列
  // TextColumn get configHash => text().nullable()();
  // BoolColumn get newFeatureFlag => boolean().withDefault(const Constant(false))();

  @override
  Set<Column<Object>>? get primaryKey => {id};
}

/// 数据库实例（仅展示 migration 部分）
///
/// P1-3 修复：onUpgrade 中使用正确的 Drift API
///
/// 旧写法（错误）：
///   await m.customStatement('ALTER TABLE app_settings ADD COLUMN config_hash TEXT');
///
/// 新写法（正确）：
///   await m.addColumn(appSettings, appSettings.configHash);
///
/// Drift 的 Migrator (m) 暴露的方法包括：
///   - m.addColumn(table, column)        — 添加列
///   - m.alterTable(/* ... */)           — 修改表
///   - m.createTable(table)              — 创建表
///   - m.deleteTable(tableName)          — 删除表
///   - m.renameTable(from, to)           — 重命名表
///
/// m.customStatement() 不存在，不应出现在迁移代码中。
@UseDao()
class AppSettingsDao extends DatabaseAccessor<AppSettingsDatabaseImpl>
    with _$AppSettingsDaoMixin {
  AppSettingsDao(AppSettingsDatabaseImpl db) : super(db);
}

@DriftDatabase(tables: [AppSettingsTable])
class AppSettingsDatabaseImpl extends _$AppSettingsDatabaseImpl {
  AppSettingsDatabaseImpl()
      : super(_openConnection());

  @override
  int get schemaVersion => 1;

  @override
  MigrationStrategy get migration {
    return MigrationStrategy(
      onCreate: (Migrator m) async {
        await m.createAll();
      },
      // P1-3 修复：正确的 Drift API 注释
      onUpgrade: (m, from, to) async {
        // 示例 — from 1 to 2：添加 config_hash 列
        // if (from < 2) {
        //   await m.addColumn(appSettings, appSettings.configHash);
        // }
        //
        // 示例 — from 2 to 3：添加新的功能开关
        // if (from < 3) {
        //   await m.addColumn(appSettings, appSettings.newFeatureFlag);
        // }
      },
      beforeOpen: (details) async {
        await customStatement('PRAGMA foreign_keys = ON');
      },
    );
  }

  static QueryExecutor _openConnection() {
    return NativeDatabase.memory();
  }
}