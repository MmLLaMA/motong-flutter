/// 模块 3 — 记忆详情 / 编辑页

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';
import 'package:uuid/uuid.dart';
import '../models/models.dart';
import '../providers/memory_provider.dart';

class MemoryDetailPage extends StatefulWidget {
  final MemoryEntry? existing;
  const MemoryDetailPage({super.key, this.existing});

  @override
  State<MemoryDetailPage> createState() => _MemoryDetailPageState();
}

class _MemoryDetailPageState extends State<MemoryDetailPage> {
  late TextEditingController _contentCtrl;
  late TextEditingController _keywordsCtrl;
  late MemoryCategory _category;
  late int _importance;
  late MemorySource _source;
  final _uuid = const Uuid();

  @override
  void initState() {
    super.initState();
    _contentCtrl =
        TextEditingController(text: widget.existing?.content ?? '');
    _keywordsCtrl =
        TextEditingController(text: widget.existing?.keywords ?? '');
    _category = widget.existing?.category ?? MemoryCategory.fact;
    _importance = widget.existing?.importance ?? 5;
    _source = widget.existing?.source ?? MemorySource.manual;
  }

  @override
  void dispose() {
    _contentCtrl.dispose();
    _keywordsCtrl.dispose();
    super.dispose();
  }

  void _save() {
    final content = _contentCtrl.text.trim();
    if (content.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('内容不能为空')),
      );
      return;
    }
    final now = DateTime.now().millisecondsSinceEpoch;
    final entry = MemoryEntry(
      id: widget.existing?.id ?? _uuid.v4(),
      content: content,
      category: _category,
      importance: _source == MemorySource.manual ? 10 : _importance,
      source: _source,
      assistantId: widget.existing?.assistantId,
      conversationId: widget.existing?.conversationId,
      sourceMessageIds: widget.existing?.sourceMessageIds ?? [],
      keywords: _keywordsCtrl.text.trim(),
      accessCount: widget.existing?.accessCount ?? 0,
      lastAccessed: widget.existing?.lastAccessed,
      isArchived: widget.existing?.isArchived ?? false,
      createdAt: widget.existing?.createdAt ?? now,
      updatedAt: now,
    );
    if (widget.existing == null) {
      context.read<MemoryProvider>().createEntry(entry);
    } else {
      context.read<MemoryProvider>().updateEntry(entry);
    }
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final isEdit = widget.existing != null;
    return Scaffold(
      appBar: AppBar(
        title: Text(isEdit ? '编辑记忆' : '新建记忆'),
        actions: [
          IconButton(
            icon: const Icon(LucideIcons.check),
            onPressed: _save,
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(
            controller: _contentCtrl,
            maxLines: 5,
            decoration: const InputDecoration(
              labelText: '记忆内容',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 16),
          DropdownButtonFormField<MemoryCategory>(
            initialValue: _category,
            decoration: const InputDecoration(
              labelText: '分类',
              border: OutlineInputBorder(),
            ),
            items: MemoryCategory.values
                .map((c) => DropdownMenuItem(value: c, child: Text(c.name)))
                .toList(),
            onChanged: (v) => setState(() => _category = v ?? _category),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              const Text('重要性'),
              Expanded(
                child: Slider(
                  value: _importance.toDouble(),
                  min: 1,
                  max: 10,
                  divisions: 9,
                  label: '$_importance',
                  onChanged: _source == MemorySource.manual
                      ? null
                      : (v) => setState(() => _importance = v.toInt()),
                ),
              ),
              Text('$_importance / 10'),
            ],
          ),
          if (_source == MemorySource.manual)
            const Padding(
              padding: EdgeInsets.only(bottom: 8),
              child: Text(
                '手动创建固定为重要性 10',
                style: TextStyle(fontSize: 11, color: Colors.grey),
              ),
            ),
          const SizedBox(height: 16),
          TextField(
            controller: _keywordsCtrl,
            decoration: const InputDecoration(
              labelText: '关键词（空格分隔）',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 24),
          if (isEdit)
            ListTile(
              leading: const Icon(LucideIcons.trash, color: Colors.red),
              title: const Text('删除此记忆', style: TextStyle(color: Colors.red)),
              onTap: () {
                context.read<MemoryProvider>().deleteEntry(entry.id);
                Navigator.pop(context);
              },
            ),
        ],
      ),
    );
  }

  MemoryEntry get entry => widget.existing!;
}