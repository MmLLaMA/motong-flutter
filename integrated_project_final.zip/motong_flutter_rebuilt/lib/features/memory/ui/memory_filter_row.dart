/// 模块 3 — 记忆筛选组件（助手 + 类别）

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/models.dart';
import '../providers/memory_provider.dart';

class MemoryFilterRow extends StatelessWidget {
  const MemoryFilterRow({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<MemoryProvider>();
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: Row(
        children: [
          Expanded(
            child: DropdownButtonFormField<MemoryCategory?>(
              initialValue: provider.filterCategory,
              isExpanded: true,
              decoration: const InputDecoration(
                isDense: true,
                contentPadding:
                    EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              ),
              hint: const Text('所有类别'),
              items: [
                const DropdownMenuItem<MemoryCategory?>(
                  value: null,
                  child: Text('所有类别'),
                ),
                ...MemoryCategory.values.map(
                  (c) => DropdownMenuItem<MemoryCategory?>(
                    value: c,
                    child: Text(c.name),
                  ),
                ),
              ],
              onChanged: (v) async {
                await provider.setFilter(category: v);
              },
            ),
          ),
        ],
      ),
    );
  }
}