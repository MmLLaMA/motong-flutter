/// 模块 3 — 记忆列表页

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';
import '../providers/memory_provider.dart';
import 'memory_card.dart';
import 'memory_filter_row.dart';
import 'memory_detail_page.dart';

class MemoryPage extends StatefulWidget {
  const MemoryPage({super.key});

  @override
  State<MemoryPage> createState() => _MemoryPageState();
}

class _MemoryPageState extends State<MemoryPage> {
  final TextEditingController _searchController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  Timer? _searchDebounce;

  @override
  void initState() {
    super.initState();
    _scrollController.addListener(_onScroll);
  }

  void _onScroll() {
    if (!_scrollController.hasClients) return;
    final max = _scrollController.position.maxScrollExtent;
    if (_scrollController.position.pixels >= max - 200) {
      context.read<MemoryProvider>().loadMore();
    }
  }

  @override
  void dispose() {
    _searchDebounce?.cancel();
    _searchController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  void _onSearchChanged(String query) {
    _searchDebounce?.cancel();
    _searchDebounce = Timer(const Duration(milliseconds: 300), () {
      context.read<MemoryProvider>().search(query);
    });
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<MemoryProvider>();
    return Scaffold(
      appBar: AppBar(title: const Text('记忆管理')),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _openDetail(context),
        child: const Icon(LucideIcons.plus),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: '搜索记忆...',
                prefixIcon: const Icon(LucideIcons.search, size: 18),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                isDense: true,
              ),
              onChanged: _onSearchChanged,
            ),
          ),
          const MemoryFilterRow(),
          if (provider.isLoading)
            const LinearProgressIndicator(),
          Expanded(
            child: provider.memories.isEmpty
                ? const Center(
                    child: Text('暂无记忆', style: TextStyle(color: Colors.grey)))
                : ListView.builder(
                    controller: _scrollController,
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    itemCount: provider.memories.length,
                    itemBuilder: (context, index) {
                      final m = provider.memories[index];
                      return MemoryCard(
                        entry: m,
                        onTap: () => _openDetail(context, existing: m),
                      );
                    },
                  ),
          ),
          Padding(
            padding: const EdgeInsets.all(8),
            child: Text(
              '长按记忆可删除',
              style: TextStyle(fontSize: 11, color: Colors.grey[500]),
            ),
          ),
        ],
      ),
    );
  }

  void _openDetail(BuildContext context, {dynamic existing}) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => MemoryDetailPage(existing: existing),
      ),
    );
  }
}