/// 模块 3 — 设置页记忆区域

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/models.dart';
import '../providers/memory_provider.dart';

class MemorySettingsSection extends StatelessWidget {
  const MemorySettingsSection({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<MemoryProvider>();
    final settings = provider.settings;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 4),
          child: Text(
            '记忆',
            style: TextStyle(
              fontSize: 13,
              color: Colors.grey[600],
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
        SwitchListTile(
          secondary: const Icon(Icons.psychology, size: 20),
          title: const Text('启用长期记忆'),
          subtitle: const Text('从对话中自动提取事实并存储', style: TextStyle(fontSize: 12)),
          value: settings.longTermMemoryEnabled,
          onChanged: (v) {
            provider.updateSettings(
              settings.copyWith(longTermMemoryEnabled: v),
            );
          },
        ),
        ListTile(
          title: const Text('注入上下文数'),
          subtitle: Slider(
            value: settings.maxContextMessages.toDouble(),
            min: 3,
            max: 20,
            divisions: 17,
            label: '${settings.maxContextMessages}',
            onChanged: (v) {
              provider.updateSettings(
                settings.copyWith(maxContextMessages: v.toInt()),
              );
            },
          ),
          trailing: Text('${settings.maxContextMessages}'),
        ),
        ListTile(
          title: const Text('提取阈值'),
          subtitle: Slider(
            value: settings.extractionThreshold.toDouble(),
            min: 5,
            max: 100,
            divisions: 19,
            label: '${settings.extractionThreshold}',
            onChanged: (v) {
              provider.updateSettings(
                settings.copyWith(extractionThreshold: v.toInt()),
              );
            },
          ),
          trailing: Text('${settings.extractionThreshold} 条'),
        ),
      ],
    );
  }
}