/// 模块 3 — 记忆卡片

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/models.dart';
import '../providers/memory_provider.dart';

class MemoryCard extends StatelessWidget {
  final MemoryEntry entry;
  final VoidCallback? onTap;

  const MemoryCard({
    super.key,
    required this.entry,
    this.onTap,
  });

  Color _categoryColor(MemoryCategory c) {
    switch (c) {
      case MemoryCategory.fact:
        return Colors.blue;
      case MemoryCategory.preference:
        return Colors.purple;
      case MemoryCategory.goal:
        return Colors.orange;
      case MemoryCategory.event:
        return Colors.teal;
      case MemoryCategory.emotion:
        return Colors.pink;
      case MemoryCategory.relationship:
        return Colors.green;
    }
  }

  String _categoryLabel(MemoryCategory c) {
    switch (c) {
      case MemoryCategory.fact:
        return '事实';
      case MemoryCategory.preference:
        return '偏好';
      case MemoryCategory.goal:
        return '目标';
      case MemoryCategory.event:
        return '事件';
      case MemoryCategory.emotion:
        return '情感';
      case MemoryCategory.relationship:
        return '关系';
    }
  }

  String _timeAgo(int ms) {
    final delta = DateTime.now().millisecondsSinceEpoch - ms;
    if (delta < 60000) return '刚刚';
    if (delta < 3600000) return '${(delta / 60000).floor()} 分钟前';
    if (delta < 86400000) return '${(delta / 3600000).floor()} 小时前';
    if (delta < 7 * 86400000) return '${(delta / 86400000).floor()} 天前';
    return DateTime.fromMillisecondsSinceEpoch(ms).toIso8601String().split('T')[0];
  }

  @override
  Widget build(BuildContext context) {
    final color = _categoryColor(entry.category);
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      child: Dismissible(
        key: ValueKey(entry.id),
        direction: DismissDirection.endToStart,
        confirmDismiss: (_) async {
          return await showDialog<bool>(
                context: context,
                builder: (ctx) => AlertDialog(
                  title: const Text('删除记忆'),
                  content: const Text('确定要从记忆中移除吗？'),
                  actions: [
                    TextButton(
                        onPressed: () => Navigator.pop(ctx, false),
                        child: const Text('取消')),
                    TextButton(
                      onPressed: () => Navigator.pop(ctx, true),
                      style: TextButton.styleFrom(foregroundColor: Colors.red),
                      child: const Text('删除'),
                    ),
                  ],
                ),
              ) ??
              false;
        },
        onDismissed: (_) {
          context.read<MemoryProvider>().deleteEntry(entry.id);
        },
        background: Container(
          alignment: Alignment.centerRight,
          padding: const EdgeInsets.only(right: 20),
          color: Colors.red[400],
          child: const Icon(Icons.delete, color: Colors.white),
        ),
        child: InkWell(
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding:
                          const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color: color.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Text(
                        _categoryLabel(entry.category),
                        style: TextStyle(
                          fontSize: 11,
                          color: color,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text('重要性',
                        style:
                            TextStyle(fontSize: 11, color: Colors.grey[600])),
                    const SizedBox(width: 4),
                    Text('${'★' * entry.importance}${'☆' * (10 - entry.importance)}',
                        style: const TextStyle(fontSize: 10, color: Colors.amber)),
                    const Spacer(),
                    Text(_timeAgo(entry.createdAt),
                        style:
                            TextStyle(fontSize: 11, color: Colors.grey[500])),
                  ],
                ),
                const SizedBox(height: 6),
                Text(
                  entry.content,
                  maxLines: 3,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 14),
                ),
                if (entry.keywords.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 4),
                    child: Text(
                      '#${entry.keywords.replaceAll(' ', ' #')}',
                      style:
                          TextStyle(fontSize: 11, color: Colors.grey[500]),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}