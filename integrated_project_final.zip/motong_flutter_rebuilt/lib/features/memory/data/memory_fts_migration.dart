/// 模块 3 — FTS5 迁移 SQL
/// memory_fts 虚拟表 + 3 个触发器自动同步

/// 主表 DDL
const String memoryEntriesDdl = '''
CREATE TABLE memory_entries (
  id TEXT PRIMARY KEY NOT NULL,
  content TEXT NOT NULL,
  category TEXT NOT NULL,
  importance INTEGER NOT NULL,
  source TEXT NOT NULL,
  assistant_id TEXT,
  conversation_id TEXT,
  source_message_ids TEXT NOT NULL DEFAULT '[]',
  keywords TEXT NOT NULL DEFAULT '',
  access_count INTEGER NOT NULL DEFAULT 0,
  last_accessed INTEGER,
  is_archived INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);
''';

const String extractionTasksDdl = '''
CREATE TABLE extraction_tasks (
  id TEXT PRIMARY KEY NOT NULL,
  conversation_id TEXT NOT NULL,
  status TEXT NOT NULL,
  triggered_by TEXT NOT NULL,
  message_range TEXT NOT NULL,
  result_count INTEGER,
  error_message TEXT,
  created_at INTEGER NOT NULL,
  completed_at INTEGER
);
''';

/// FTS5 虚拟表（simple tokenizer）
const String memoryFtsDdl = '''
CREATE VIRTUAL TABLE memory_fts USING fts5(
  id UNINDEXED,
  content,
  keywords,
  tokenize = 'simple'
);
''';

/// AFTER INSERT 触发器：自动写入 FTS5
const String memoryFtsInsertTriggerDdl = '''
CREATE TRIGGER memory_fts_insert AFTER INSERT ON memory_entries
BEGIN
  INSERT INTO memory_fts (id, content, keywords)
  VALUES (NEW.id, NEW.content, NEW.keywords);
END;
''';

/// AFTER DELETE 触发器：自动删除 FTS5 记录
const String memoryFtsDeleteTriggerDdl = '''
CREATE TRIGGER memory_fts_delete AFTER DELETE ON memory_entries
BEGIN
  DELETE FROM memory_fts WHERE id = OLD.id;
END;
''';

/// AFTER UPDATE 触发器：自动同步 FTS5
const String memoryFtsUpdateTriggerDdl = '''
CREATE TRIGGER memory_fts_update AFTER UPDATE ON memory_entries
BEGIN
  UPDATE memory_fts SET
    content = NEW.content,
    keywords = NEW.keywords
  WHERE id = OLD.id;
END;
''';