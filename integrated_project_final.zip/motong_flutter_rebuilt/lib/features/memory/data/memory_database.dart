/// 模块 3 — 记忆系统数据库（Drift + FTS5）
/// 使用纯 SQL 自管理，不依赖代码生成

import 'package:drift/drift.dart';
import 'package:drift_flutter/drift_flutter.dart';
import '../models/memory_entry.dart';
import '../models/memory_extraction_task.dart';
import 'memory_fts_migration.dart';

class AppDatabase extends GeneratedDatabase {
  AppDatabase() : super(_openConnection());

  static QueryExecutor _openConnection() {
    return driftDatabase(name: 'motong_memory');
  }

  @override
  int get schemaVersion => 1;

  @override
  Iterable<Table> get allTables => const [];

  @override
  MigrationStrategy get migration => MigrationStrategy(
        onCreate: (m) async {
          await customStatement(memoryEntriesDdl);
          await customStatement(extractionTasksDdl);
          await customStatement(memoryFtsDdl);
          await customStatement(memoryFtsInsertTriggerDdl);
          await customStatement(memoryFtsDeleteTriggerDdl);
          await customStatement(memoryFtsUpdateTriggerDdl);
        },
        onUpgrade: (m, from, to) async {},
      );
}

/// 别名，供外部使用
typedef MemoryDatabase = AppDatabase;

// ==================== Data ↔ Domain 转换器 ====================

/// Drift row → MemoryEntry 转换
MemoryEntry entryFromRow(Map<String, dynamic> row) {
  return MemoryEntry(
    id: row['id'] as String,
    content: row['content'] as String? ?? '',
    category: MemoryCategory.values.firstWhere(
      (e) => e.name == (row['category'] as String? ?? 'fact'),
      orElse: () => MemoryCategory.fact,
    ),
    importance: (row['importance'] as num?)?.toInt() ?? 5,
    source: MemorySource.values.firstWhere(
      (e) => e.name == (row['source'] as String? ?? 'auto'),
      orElse: () => MemorySource.auto,
    ),
    assistantId: row['assistant_id'] as String?,
    conversationId: row['conversation_id'] as String?,
    sourceMessageIds: _parseStringList(row['source_message_ids']),
    keywords: row['keywords'] as String? ?? '',
    accessCount: (row['access_count'] as num?)?.toInt() ?? 0,
    lastAccessed: (row['last_accessed'] as num?)?.toInt(),
    isArchived: (row['is_archived'] as int? ?? 0) == 1,
    createdAt: (row['created_at'] as num?)?.toInt() ?? 0,
    updatedAt: (row['updated_at'] as num?)?.toInt() ?? 0,
  );
}

/// MemoryEntry → Drift row params
Map<String, Object?> entryToRow(MemoryEntry e) {
  return {
    'id': e.id,
    'content': e.content,
    'category': e.category.name,
    'importance': e.importance,
    'source': e.source.name,
    'assistant_id': e.assistantId,
    'conversation_id': e.conversationId,
    'source_message_ids': _encodeStringList(e.sourceMessageIds),
    'keywords': e.keywords,
    'access_count': e.accessCount,
    'last_accessed': e.lastAccessed,
    'is_archived': e.isArchived ? 1 : 0,
    'created_at': e.createdAt,
    'updated_at': e.updatedAt,
  };
}

List<String> _parseStringList(dynamic raw) {
  if (raw == null) return [];
  if (raw is List) return raw.map((e) => e.toString()).toList();
  if (raw is String) {
    if (raw.isEmpty) return [];
    final trimmed = raw.trim();
    if (trimmed.startsWith('[')) {
      // JSON 格式
      final cleaned = trimmed
          .replaceAll('[', '')
          .replaceAll(']', '')
          .replaceAll('"', '');
      return cleaned
          .split(',')
          .where((s) => s.trim().isNotEmpty)
          .toList();
    }
    return [raw];
  }
  return [];
}

String _encodeStringList(List<String> list) {
  if (list.isEmpty) return '[]';
  return '["${list.join('","')}"]';
}

MemoryExtractionTask taskFromRow(Map<String, dynamic> row) {
  return MemoryExtractionTask(
    id: row['id'] as String,
    conversationId: row['conversation_id'] as String,
    status: ExtractionStatus.values.firstWhere(
      (e) => e.name == (row['status'] as String? ?? 'pending'),
      orElse: () => ExtractionStatus.pending,
    ),
    triggeredBy: ExtractionTrigger.values.firstWhere(
      (e) => e.name == (row['triggered_by'] as String? ?? 'threshold'),
      orElse: () => ExtractionTrigger.threshold,
    ),
    messageRange: row['message_range'] as String? ?? '{}',
    resultCount: (row['result_count'] as num?)?.toInt(),
    errorMessage: row['error_message'] as String?,
    createdAt: (row['created_at'] as num?)?.toInt() ?? 0,
    completedAt: (row['completed_at'] as num?)?.toInt(),
  );
}