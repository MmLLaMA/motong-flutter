/// 模块 3 — 记忆仓库
/// 包装 DAO，对外暴露领域模型 + 分页对象

import 'memory_dao.dart';
import '../models/memory_entry.dart';
import '../models/memory_extraction_task.dart';

class PaginatedMemories {
  final List<MemoryEntry> items;
  final int totalCount;
  final bool hasMore;

  PaginatedMemories({
    required this.items,
    required this.totalCount,
    required this.hasMore,
  });
}

class MemoryRepository {
  final MemoryDao _dao;
  MemoryRepository(this._dao);

  Future<void> create(MemoryEntry entry) => _dao.insertEntry(entry);

  Future<void> update(MemoryEntry entry) => _dao.updateEntry(entry);

  Future<void> delete(String id) => _dao.deleteEntry(id);

  Future<void> archive(String id) => _dao.archiveEntry(id);

  Future<void> purgeArchived() => _dao.purgeArchived();

  Future<MemoryEntry?> get(String id) => _dao.getById(id);

  Future<List<MemoryEntry>> search({
    required String query,
    String? assistantId,
    MemoryCategory? category,
    int limit = 20,
  }) =>
      _dao.search(
        query: query,
        assistantId: assistantId,
        category: category,
        limit: limit,
      );

  Future<PaginatedMemories> list({
    String? assistantId,
    MemoryCategory? category,
    int offset = 0,
    int limit = 20,
  }) async {
    final items = await _dao.paginate(
      assistantId: assistantId,
      category: category,
      offset: offset,
      limit: limit,
    );
    final total = await _dao.countAll(assistantId: assistantId);
    return PaginatedMemories(
      items: items,
      totalCount: total,
      hasMore: offset + items.length < total,
    );
  }

  Future<int> countByCategory(MemoryCategory category) =>
      _dao.countByCategory(category);

  // ============ 任务 ============

  Future<void> createTask(MemoryExtractionTask task) =>
      _dao.insertTask(task);

  Future<void> updateTask(
    String id,
    ExtractionStatus status, {
    int? resultCount,
    String? errorMessage,
  }) =>
      _dao.updateTaskStatus(
        id,
        status,
        resultCount: resultCount,
        errorMessage: errorMessage,
        completedAt: DateTime.now().millisecondsSinceEpoch,
      );

  Future<bool> hasPendingTask(String conversationId) =>
      _dao.hasPendingTask(conversationId);
}