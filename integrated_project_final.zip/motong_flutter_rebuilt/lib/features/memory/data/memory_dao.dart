/// 模块 3 — 记忆 DAO（直接基于 Drift Database API + 纯 SQL）

import 'package:drift/drift.dart';
import 'memory_database.dart';
import '../models/memory_entry.dart';
import '../models/memory_extraction_task.dart';

class MemoryDao {
  final AppDatabase db;
  MemoryDao(this.db);

  // ============ 记忆条目 ============

  Future<void> insertEntry(MemoryEntry entry) async {
    await db.customInsert(
      'INSERT INTO memory_entries (id, content, category, importance, source, '
      'assistant_id, conversation_id, source_message_ids, keywords, '
      'access_count, last_accessed, is_archived, created_at, updated_at) '
      'VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
      variables: [
          Variable<String>(entry.id),
          Variable<String>(entry.content),
          Variable<String>(entry.category.name),
          Variable<int>(entry.importance),
          Variable<String>(entry.source.name),
          Variable<String>(entry.assistantId),
          Variable<String>(entry.conversationId),
          Variable<String>(_encodeStringList(entry.sourceMessageIds)),
          Variable<String>(entry.keywords),
          Variable<int>(entry.accessCount),
          entry.lastAccessed == null ? const Variable<int>.withNull() : Variable<int>(entry.lastAccessed!),
          Variable<int>(entry.isArchived ? 1 : 0),
          Variable<int>(entry.createdAt),
          Variable<int>(entry.updatedAt),
        ],
    );
  }

  Future<void> updateEntry(MemoryEntry entry) async {
    await db.customUpdate(
      'UPDATE memory_entries SET content = ?, category = ?, importance = ?, '
      'source = ?, keywords = ?, updated_at = ?, is_archived = ? WHERE id = ?',
      variables: [
          Variable<String>(entry.content),
          Variable<String>(entry.category.name),
          Variable<int>(entry.importance),
          Variable<String>(entry.source.name),
          Variable<String>(entry.keywords),
          Variable<int>(DateTime.now().millisecondsSinceEpoch),
          Variable<int>(entry.isArchived ? 1 : 0),
          Variable<String>(entry.id),
        ],
      updates: [UpdateKind.update],
    );
  }

  Future<void> deleteEntry(String id) async {
    await db.customUpdate(
      'DELETE FROM memory_entries WHERE id = ?',
      variables: [Variable<String>(id)],
      updates: [UpdateKind.delete],
    );
  }

  Future<void> archiveEntry(String id) async {
    await db.customUpdate(
      'UPDATE memory_entries SET is_archived = 1, updated_at = ? WHERE id = ?',
      variables: [
        Variable<int>(DateTime.now().millisecondsSinceEpoch),
        Variable<String>(id),
      ],
      updates: [UpdateKind.update],
    );
  }

  Future<void> purgeArchived() async {
    await db.customUpdate(
      'DELETE FROM memory_entries WHERE is_archived = 1',
      updates: [UpdateKind.delete],
    );
  }

  /// FTS5 全文检索（keywords 3x 加权）
  Future<List<MemoryEntry>> search({
    required String query,
    String? assistantId,
    MemoryCategory? category,
    int limit = 20,
  }) async {
    if (query.trim().isEmpty) return [];

    // 构造 FTS5 MATCH 表达式，对 keywords 字段加权
    final terms = query
        .trim()
        .split(RegExp(r'\s+'))
        .where((t) => t.isNotEmpty)
        .map((t) => '"$t"')
        .join(' ');

    if (terms.isEmpty) return [];

    // FTS5 列权重：keywords 3x
    final matchExpr = '''content:$terms OR keywords:${terms.replaceAll('"', '*')}*''';

    final sql = '''
      SELECT m.* FROM memory_entries m
      INNER JOIN memory_fts f ON m.id = f.id
      WHERE memory_fts MATCH ?
        AND m.is_archived = 0
        AND (m.assistant_id = ? OR m.assistant_id IS NULL)
        ${category != null ? 'AND m.category = ?' : ''}
      ORDER BY m.importance DESC, bm25(memory_fts)
      LIMIT ?
    ''';

    final params = <Variable>[
      Variable<String>(matchExpr),
      assistantId == null ? const Variable<String>.withNull() : Variable<String>(assistantId),
    ];
    if (category != null) {
      params.add(Variable<String>(category.name));
    }
    params.add(Variable<int>(limit));

    final rows = await db.customSelect(sql, variables: params).get();
    return rows.map((r) => entryFromRow(r.data)).toList();
  }

  /// 分页查询
  Future<List<MemoryEntry>> paginate({
    String? assistantId,
    MemoryCategory? category,
    int offset = 0,
    int limit = 20,
  }) async {
    final whereClauses = <String>['is_archived = 0'];
    final params = <Variable>[];

    if (assistantId != null) {
      whereClauses.add('(assistant_id = ? OR assistant_id IS NULL)');
      params.add(Variable<String>(assistantId));
    }
    if (category != null) {
      whereClauses.add('category = ?');
      params.add(Variable<String>(category.name));
    }

    final where = whereClauses.join(' AND ');
    final sql = '''
      SELECT * FROM memory_entries
      WHERE $where
      ORDER BY created_at DESC
      LIMIT ? OFFSET ?
    ''';
    params.add(Variable<int>(limit));
    params.add(Variable<int>(offset));

    final rows = await db.customSelect(sql, variables: params).get();
    return rows.map((r) => entryFromRow(r.data)).toList();
  }

  /// 统计
  Future<int> countByCategory(MemoryCategory category) async {
    final row = await db.customSelect(
      'SELECT COUNT(*) AS cnt FROM memory_entries WHERE category = ? AND is_archived = 0',
      variables: [Variable<String>(category.name)],
    ).getSingle();
    return (row.data['cnt'] as num).toInt();
  }

  Future<int> countAll({String? assistantId}) async {
    final sql = assistantId != null
        ? 'SELECT COUNT(*) AS cnt FROM memory_entries WHERE is_archived = 0 AND (assistant_id = ? OR assistant_id IS NULL)'
        : 'SELECT COUNT(*) AS cnt FROM memory_entries WHERE is_archived = 0';
    final row = await db
        .customSelect(sql,
            variables: assistantId != null
                ? [Variable<String>(assistantId)]
                : [])
        .getSingle();
    return (row.data['cnt'] as num).toInt();
  }

  /// 获取某条
  Future<MemoryEntry?> getById(String id) async {
    final row = await db.customSelect(
      'SELECT * FROM memory_entries WHERE id = ?',
      variables: [Variable<String>(id)],
    ).getSingleOrNull();
    if (row == null) return null;
    return entryFromRow(row.data);
  }

  /// 获取 conversationId 自 lastExtractedMessageId 之后的全部消息
  /// 注意：消息表不在本数据库，本函数只返回 id 范围，需外部传入完整消息
  Future<MemoryEntry> getLastExtractedMarker(String conversationId) async {
    // 这里简单返回最新一条记忆
    final row = await db.customSelect(
      'SELECT * FROM memory_entries WHERE conversation_id = ? ORDER BY created_at DESC LIMIT 1',
      variables: [Variable<String>(conversationId)],
    ).getSingleOrNull();
    return row == null
        ? MemoryEntry(
            id: '',
            content: '',
            category: MemoryCategory.fact,
            importance: 1,
            source: MemorySource.auto,
            createdAt: 0,
            updatedAt: 0,
          )
        : entryFromRow(row.data);
  }

  // ============ 提取任务 ============

  Future<void> insertTask(MemoryExtractionTask task) async {
    await db.customInsert(
      'INSERT INTO extraction_tasks (id, conversation_id, status, triggered_by, '
      'message_range, result_count, error_message, created_at, completed_at) '
      'VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
      variables: [
        Variable<String>(task.id),
        Variable<String>(task.conversationId),
        Variable<String>(task.status.name),
        Variable<String>(task.triggeredBy.name),
        Variable<String>(task.messageRange),
        task.resultCount == null ? const Variable<int>.withNull() : Variable<int>(task.resultCount!),
        task.errorMessage == null ? const Variable<String>.withNull() : Variable<String>(task.errorMessage!),
        Variable<int>(task.createdAt),
        task.completedAt == null ? const Variable<int>.withNull() : Variable<int>(task.completedAt!),
      ],
    );
  }

  Future<void> updateTaskStatus(
    String id,
    ExtractionStatus status, {
    int? resultCount,
    String? errorMessage,
    int? completedAt,
  }) async {
    await db.customUpdate(
      'UPDATE extraction_tasks SET status = ?, result_count = ?, '
      'error_message = ?, completed_at = ? WHERE id = ?',
      variables: [
        Variable<String>(status.name),
        resultCount == null ? const Variable<int>.withNull() : Variable<int>(resultCount!),
        errorMessage == null ? const Variable<String>.withNull() : Variable<String>(errorMessage!),
        completedAt == null ? const Variable<int>.withNull() : Variable<int>(completedAt!),
        Variable<String>(id),
      ],
      updates: [UpdateKind.update],
    );
  }

  Future<bool> hasPendingTask(String conversationId) async {
    final row = await db.customSelect(
      "SELECT COUNT(*) AS cnt FROM extraction_tasks "
      "WHERE conversation_id = ? AND status IN ('pending', 'processing')",
      variables: [Variable<String>(conversationId)],
    ).getSingle();
    return (row.data['cnt'] as num).toInt() > 0;
  }

  String _encodeStringList(List<String> list) {
    if (list.isEmpty) return '[]';
    return '["${list.join('","')}"]';
  }
}