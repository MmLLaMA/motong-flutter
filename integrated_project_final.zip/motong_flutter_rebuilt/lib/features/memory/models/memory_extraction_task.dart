/// 模块 3 — 记忆提取任务数据模型

enum ExtractionStatus { pending, processing, completed, failed }

enum ExtractionTrigger { threshold, conversationEnd, manual }

class MemoryExtractionTask {
  final String id;
  final String conversationId;
  final ExtractionStatus status;
  final ExtractionTrigger triggeredBy;
  final String messageRange; // JSON: {"from":"msg_id","to":"msg_id"}
  final int? resultCount;
  final String? errorMessage;
  final int createdAt;
  final int? completedAt;

  MemoryExtractionTask({
    required this.id,
    required this.conversationId,
    required this.status,
    required this.triggeredBy,
    required this.messageRange,
    this.resultCount,
    this.errorMessage,
    required this.createdAt,
    this.completedAt,
  });

  factory MemoryExtractionTask.fromJson(Map<String, dynamic> json) {
    return MemoryExtractionTask(
      id: json['id'] as String,
      conversationId: json['conversation_id'] as String,
      status: ExtractionStatus.values.firstWhere(
        (e) => e.name == json['status'],
        orElse: () => ExtractionStatus.pending,
      ),
      triggeredBy: ExtractionTrigger.values.firstWhere(
        (e) => e.name == json['triggered_by'],
        orElse: () => ExtractionTrigger.threshold,
      ),
      messageRange: json['message_range'] as String? ?? '{}',
      resultCount: (json['result_count'] as num?)?.toInt(),
      errorMessage: json['error_message'] as String?,
      createdAt: (json['created_at'] as num?)?.toInt() ?? 0,
      completedAt: (json['completed_at'] as num?)?.toInt(),
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'conversation_id': conversationId,
        'status': status.name,
        'triggered_by': triggeredBy.name,
        'message_range': messageRange,
        'result_count': resultCount,
        'error_message': errorMessage,
        'created_at': createdAt,
        'completed_at': completedAt,
      };
}