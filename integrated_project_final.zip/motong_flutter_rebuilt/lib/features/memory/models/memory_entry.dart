/// 模块 3 — 记忆条目数据模型

enum MemoryCategory { fact, preference, goal, event, emotion, relationship }

enum MemorySource { auto, manual }

class MemoryEntry {
  final String id;
  final String content;
  final MemoryCategory category;
  final int importance; // 1–10，manual 固定为 10
  final MemorySource source;
  final String? assistantId; // null = 全局记忆
  final String? conversationId;
  final List<String> sourceMessageIds;
  final String keywords; // 空格分隔
  final List<double>? embedding; // P1 预留
  final int accessCount;
  final int? lastAccessed; // Unix ms
  final bool isArchived;
  final int createdAt; // Unix ms
  final int updatedAt;

  MemoryEntry({
    required this.id,
    required this.content,
    required this.category,
    required this.importance,
    required this.source,
    this.assistantId,
    this.conversationId,
    this.sourceMessageIds = const [],
    this.keywords = '',
    this.embedding,
    this.accessCount = 0,
    this.lastAccessed,
    this.isArchived = false,
    required this.createdAt,
    required this.updatedAt,
  });

  factory MemoryEntry.fromJson(Map<String, dynamic> json) {
    return MemoryEntry(
      id: json['id'] as String,
      content: json['content'] as String? ?? '',
      category: MemoryCategory.values.firstWhere(
        (e) => e.name == json['category'],
        orElse: () => MemoryCategory.fact,
      ),
      importance: (json['importance'] as num?)?.toInt() ?? 5,
      source: MemorySource.values.firstWhere(
        (e) => e.name == json['source'],
        orElse: () => MemorySource.auto,
      ),
      assistantId: json['assistant_id'] as String?,
      conversationId: json['conversation_id'] as String?,
      sourceMessageIds: ((json['source_message_ids'] as List<dynamic>?) ?? [])
          .map((e) => e as String)
          .toList(),
      keywords: json['keywords'] as String? ?? '',
      embedding: (json['embedding'] as List<dynamic>?)
          ?.map((e) => (e as num).toDouble())
          .toList(),
      accessCount: (json['access_count'] as num?)?.toInt() ?? 0,
      lastAccessed: (json['last_accessed'] as num?)?.toInt(),
      isArchived: json['is_archived'] as bool? ?? false,
      createdAt: (json['created_at'] as num?)?.toInt() ?? 0,
      updatedAt: (json['updated_at'] as num?)?.toInt() ?? 0,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'content': content,
        'category': category.name,
        'importance': importance,
        'source': source.name,
        'assistant_id': assistantId,
        'conversation_id': conversationId,
        'source_message_ids': sourceMessageIds,
        'keywords': keywords,
        'embedding': embedding,
        'access_count': accessCount,
        'last_accessed': lastAccessed,
        'is_archived': isArchived,
        'created_at': createdAt,
        'updated_at': updatedAt,
      };

  MemoryEntry copyWith({
    String? id,
    String? content,
    MemoryCategory? category,
    int? importance,
    MemorySource? source,
    String? assistantId,
    String? conversationId,
    List<String>? sourceMessageIds,
    String? keywords,
    List<double>? embedding,
    int? accessCount,
    int? lastAccessed,
    bool? isArchived,
    int? createdAt,
    int? updatedAt,
  }) =>
      MemoryEntry(
        id: id ?? this.id,
        content: content ?? this.content,
        category: category ?? this.category,
        importance: importance ?? this.importance,
        source: source ?? this.source,
        assistantId: assistantId ?? this.assistantId,
        conversationId: conversationId ?? this.conversationId,
        sourceMessageIds: sourceMessageIds ?? this.sourceMessageIds,
        keywords: keywords ?? this.keywords,
        embedding: embedding ?? this.embedding,
        accessCount: accessCount ?? this.accessCount,
        lastAccessed: lastAccessed ?? this.lastAccessed,
        isArchived: isArchived ?? this.isArchived,
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
      );
}