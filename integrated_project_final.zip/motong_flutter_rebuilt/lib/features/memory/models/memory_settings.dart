/// 模块 3 — 记忆系统设置

class MemorySettings {
  final bool longTermMemoryEnabled; // 默认 true
  final int maxContextMessages; // 默认 10
  final double retrievalThreshold; // P1 预留，默认 0.7
  final int extractionThreshold; // 默认 20

  MemorySettings({
    this.longTermMemoryEnabled = true,
    this.maxContextMessages = 10,
    this.retrievalThreshold = 0.7,
    this.extractionThreshold = 20,
  });

  factory MemorySettings.fromJson(Map<String, dynamic> json) {
    return MemorySettings(
      longTermMemoryEnabled: json['long_term_memory_enabled'] as bool? ?? true,
      maxContextMessages: (json['max_context_messages'] as num?)?.toInt() ?? 10,
      retrievalThreshold:
          (json['retrieval_threshold'] as num?)?.toDouble() ?? 0.7,
      extractionThreshold:
          (json['extraction_threshold'] as num?)?.toInt() ?? 20,
    );
  }

  Map<String, dynamic> toJson() => {
        'long_term_memory_enabled': longTermMemoryEnabled,
        'max_context_messages': maxContextMessages,
        'retrieval_threshold': retrievalThreshold,
        'extraction_threshold': extractionThreshold,
      };

  MemorySettings copyWith({
    bool? longTermMemoryEnabled,
    int? maxContextMessages,
    double? retrievalThreshold,
    int? extractionThreshold,
  }) =>
      MemorySettings(
        longTermMemoryEnabled:
            longTermMemoryEnabled ?? this.longTermMemoryEnabled,
        maxContextMessages: maxContextMessages ?? this.maxContextMessages,
        retrievalThreshold: retrievalThreshold ?? this.retrievalThreshold,
        extractionThreshold: extractionThreshold ?? this.extractionThreshold,
      );
}