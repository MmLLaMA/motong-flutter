/// 模块 3 — 记忆 Provider（ChangeNotifier）
/// 暴露 UI 状态：memories 列表、isLoading、searchQuery、筛选状态

import 'package:flutter/foundation.dart';
import '../models/models.dart';
import '../data/memory_repository.dart';
import '../services/memory_manager.dart';
import '../services/memory_injector.dart';

class MemoryProvider extends ChangeNotifier {
  final MemoryManager _manager = MemoryManager.instance;
  MemoryRepository? _repositoryRef;

  List<MemoryEntry> _memories = [];
  bool _isLoading = false;
  String _searchQuery = '';
  String? _filterAssistantId;
  MemoryCategory? _filterCategory;
  MemorySettings _settings = MemorySettings();
  bool _hasMore = false;

  // getters
  List<MemoryEntry> get memories => List.unmodifiable(_memories);
  bool get isLoading => _isLoading;
  String get searchQuery => _searchQuery;
  String? get filterAssistantId => _filterAssistantId;
  MemoryCategory? get filterCategory => _filterCategory;
  MemorySettings get settings => _settings;
  bool get hasMore => _hasMore;

  MemoryInjector get memoryInjector => _manager.memoryInjector;

  /// 初始化（由 app.dart 调用）
  Future<void> init({required MemoryRepository repository}) async {
    _repositoryRef = repository;
    _settings = _manager.settings;
    await loadMemories();
  }

  /// 加载记忆（分页首页）
  Future<void> loadMemories({int offset = 0, int limit = 20}) async {
    if (_repositoryRef == null) return;
    _isLoading = true;
    notifyListeners();
    try {
      final result = await _repositoryRef!.list(
        assistantId: _filterAssistantId,
        category: _filterCategory,
        offset: offset,
        limit: limit,
      );
      _memories = result.items;
      _hasMore = result.hasMore;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  /// 加载更多
  Future<void> loadMore() async {
    if (_isLoading || !_hasMore) return;
    if (_repositoryRef == null) return;
    _isLoading = true;
    notifyListeners();
    try {
      final result = await _repositoryRef!.list(
        assistantId: _filterAssistantId,
        category: _filterCategory,
        offset: _memories.length,
        limit: 20,
      );
      _memories = [..._memories, ...result.items];
      _hasMore = result.hasMore;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  /// 搜索（FTS5）
  Future<void> search(String query) async {
    _searchQuery = query;
    if (_repositoryRef == null) return;
    if (query.trim().isEmpty) {
      await loadMemories();
      return;
    }
    _isLoading = true;
    notifyListeners();
    try {
      _memories = await _repositoryRef!.search(
        query: query,
        assistantId: _filterAssistantId,
        category: _filterCategory,
        limit: 20,
      );
      _hasMore = false;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  /// 创建记忆
  Future<void> createEntry(MemoryEntry entry) async {
    await _manager.createMemory(entry);
    await loadMemories();
  }

  /// 更新记忆
  Future<void> updateEntry(MemoryEntry entry) async {
    await _manager.updateMemory(entry.id, entry);
    await loadMemories();
  }

  /// 删除
  Future<void> deleteEntry(String id) async {
    await _manager.archiveMemory(id);
    await loadMemories();
  }

  /// 永久删除
  Future<void> permanentlyDelete(String id) async {
    if (_repositoryRef == null) return;
    await _repositoryRef!.delete(id);
    await loadMemories();
  }

  /// 清除已归档
  Future<void> purgeArchived() async {
    await _manager.purgeArchivedMemories();
    await loadMemories();
  }

  /// 设置筛选
  Future<void> setFilter({
    String? assistantId,
    MemoryCategory? category,
  }) async {
    _filterAssistantId = assistantId;
    _filterCategory = category;
    if (_searchQuery.isNotEmpty) {
      await search(_searchQuery);
    } else {
      await loadMemories();
    }
  }

  /// 清除搜索
  Future<void> clearSearch() async {
    _searchQuery = '';
    await loadMemories();
  }

  /// 更新设置
  Future<void> updateSettings(MemorySettings newSettings) async {
    _settings = newSettings;
    _manager.updateSettings(newSettings);
    notifyListeners();
  }

  /// 注入器辅助
  Future<String> getContextPrefix(
    String? assistantId,
    String userQuery,
  ) =>
      _manager.getContextPrefix(assistantId, userQuery);

  /// 消息累积回调
  Future<void> onMessagesAdded(String conversationId, int count) =>
      _manager.onMessagesAdded(conversationId, count);

  /// 对话切换回调
  Future<void> onConversationChanged(
    String? oldId,
    String newId,
  ) =>
      _manager.onConversationChanged(oldId, newId);
}