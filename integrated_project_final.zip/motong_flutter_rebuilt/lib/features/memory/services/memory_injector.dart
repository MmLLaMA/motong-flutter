/// 模块 3 — 记忆注入器
/// 把检索到的记忆构造成 system prompt 前缀

import '../models/memory_entry.dart';

class MemoryInjector {
  /// 按 category 分组、importance 降序，构建前缀
  String buildPrefix(List<MemoryEntry> memories) {
    if (memories.isEmpty) return '';

    // 按类别优先级分组
    final priorityOrder = [
      MemoryCategory.preference,
      MemoryCategory.goal,
      MemoryCategory.fact,
      MemoryCategory.event,
      MemoryCategory.emotion,
      MemoryCategory.relationship,
    ];

    final grouped = <MemoryCategory, List<MemoryEntry>>{};
    for (final m in memories) {
      grouped.putIfAbsent(m.category, () => []).add(m);
    }

    // 每组内按 importance 降序
    grouped.forEach((key, list) {
      list.sort((a, b) => b.importance.compareTo(a.importance));
    });

    final buffer = StringBuffer();
    buffer.writeln('【记忆背景】');

    var totalLength = buffer.length;
    const maxLength = 500;

    for (final category in priorityOrder) {
      final list = grouped[category];
      if (list == null || list.isEmpty) continue;

      buffer.writeln(_categoryLabel(category));
      for (final m in list) {
        final line = '- ${m.content}';
        // 偏好类加行为引导
        final withGuidance = category == MemoryCategory.preference
            ? '$line → 请优先用…'
            : line;

        if (totalLength + withGuidance.length + 1 > maxLength) {
          return buffer.toString().trim();
        }
        buffer.writeln(withGuidance);
        totalLength += withGuidance.length + 1;
      }
    }

    return buffer.toString().trim();
  }

  String _categoryLabel(MemoryCategory cat) {
    switch (cat) {
      case MemoryCategory.preference:
        return '【用户偏好】';
      case MemoryCategory.goal:
        return '【用户目标】';
      case MemoryCategory.fact:
        return '【已知事实】';
      case MemoryCategory.event:
        return '【近期事件】';
      case MemoryCategory.emotion:
        return '【情感记录】';
      case MemoryCategory.relationship:
        return '【关系信息】';
    }
  }
}