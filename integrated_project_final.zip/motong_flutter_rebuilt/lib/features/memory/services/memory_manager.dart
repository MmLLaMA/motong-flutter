/// 模块 3 — 记忆管理器（单例，统一对外入口）

import '../data/memory_database.dart';
import '../data/memory_dao.dart';
import '../data/memory_repository.dart';
import '../models/memory_entry.dart';
import '../models/memory_extraction_task.dart';
import '../models/memory_settings.dart';
import 'memory_extractor.dart';
import 'memory_retriever.dart';
import 'memory_injector.dart';

class MemoryManager {
  static final MemoryManager instance = MemoryManager._();
  MemoryManager._();

  AppDatabase? _database;
  MemoryDao? _dao;
  MemoryRepository? _repository;
  MemoryRetriever? _retriever;
  MemoryInjector? _injector;
  MemoryExtractor? _extractor;
  MemorySettings _settings = MemorySettings();

  bool _initialized = false;
  bool get isInitialized => _initialized;

  /// 初始化记忆系统
  Future<void> init({
    required AppDatabase database,
    MemorySettings? settings,
  }) async {
    if (_initialized) return;
    _database = database;
    _dao = MemoryDao(database);
    _repository = MemoryRepository(_dao!);
    _retriever = MemoryRetriever(_repository!);
    _injector = MemoryInjector();
    _settings = settings ?? MemorySettings();
    _initialized = true;
  }

  /// 注入/替换组件（由 app.dart 调用，覆盖 init() 创建的默认组件）
  ///
  /// 主要场景：
  /// - 真实 LLM 调用函数（不是占位）
  /// - 真实 fetchMessages（来自 ChatProvider）
  /// - 用业务定制的 Retriever/Injector/Extractor 覆盖默认实现
  void attachComponents({
    MemoryRetriever? retriever,
    MemoryInjector? injector,
    MemoryExtractor? extractor,
  }) {
    if (retriever != null) _retriever = retriever;
    if (injector != null) _injector = injector;
    if (extractor != null) _extractor = extractor;
  }

  void updateSettings(MemorySettings settings) {
    _settings = settings;
  }

  MemorySettings get settings => _settings;

  // ============ 消息事件 ============

  /// 消息累积达到阈值时调用
  Future<void> onMessagesAdded(String conversationId, int count) async {
    if (!_settings.longTermMemoryEnabled) return;
    if (!_initialized) return;
    if (count >= _settings.extractionThreshold) {
      await _extractor!.triggerExtraction(
        conversationId,
        ExtractionTrigger.threshold,
      );
    }
  }

  /// 切换到新对话时触发旧对话提取
  Future<void> onConversationChanged(
    String? oldConversationId,
    String newConversationId,
  ) async {
    if (!_settings.longTermMemoryEnabled) return;
    if (!_initialized) return;
    if (oldConversationId != null && oldConversationId != newConversationId) {
      await _extractor!.triggerExtraction(
        oldConversationId,
        ExtractionTrigger.conversationEnd,
      );
    }
  }

  // ============ 上下文注入 ============

  /// 检索相关记忆并构建 system prompt 前缀
  Future<String> getContextPrefix(
    String? assistantId,
    String userQuery,
  ) async {
    if (!_settings.longTermMemoryEnabled) return '';
    if (!_initialized) return '';
    if (userQuery.trim().isEmpty) return '';

    final results = await _retriever!.search(
      query: userQuery,
      assistantId: assistantId,
      limit: _settings.maxContextMessages,
    );
    return _injector!.buildPrefix(results);
  }

  // ============ CRUD 代理 ============

  Future<void> createMemory(MemoryEntry entry) =>
      _repository!.create(entry);

  Future<void> updateMemory(String id, MemoryEntry patch) async {
    final existing = await _repository!.get(id);
    if (existing == null) return;
    await _repository!.update(patch.copyWith(updatedAt: DateTime.now().millisecondsSinceEpoch));
  }

  Future<void> archiveMemory(String id) => _repository!.archive(id);

  Future<void> purgeArchivedMemories() => _repository!.purgeArchived();

  Future<List<MemoryEntry>> searchMemories({
    required String query,
    String? assistantId,
    MemoryCategory? category,
    int limit = 20,
  }) =>
      _repository!.search(
        query: query,
        assistantId: assistantId,
        category: category,
        limit: limit,
      );

  Future<PaginatedMemories> getMemories({
    String? assistantId,
    MemoryCategory? category,
    int offset = 0,
    int limit = 20,
  }) =>
      _repository!.list(
        assistantId: assistantId,
        category: category,
        offset: offset,
        limit: limit,
      );

  /// 注入器访问（用于 UI 设置页面）
  MemoryInjector get memoryInjector => _injector!;
}