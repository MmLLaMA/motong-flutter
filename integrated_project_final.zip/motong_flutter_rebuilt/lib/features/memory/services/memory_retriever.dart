/// 模块 3 — 记忆检索器
/// FTS5 全文检索 + P1 embedding 占位

import '../data/memory_repository.dart';
import '../models/memory_entry.dart';

class MemoryRetriever {
  final MemoryRepository _repository;
  MemoryRetriever(this._repository);

  /// FTS5 全文检索
  Future<List<MemoryEntry>> search({
    required String query,
    String? assistantId,
    MemoryCategory? category,
    int limit = 20,
  }) async {
    if (query.trim().isEmpty) return [];
    return _repository.search(
      query: query,
      assistantId: assistantId,
      category: category,
      limit: limit,
    );
  }

  /// 基于 embedding 的语义检索（P1 预留，返回空列表）
  /// sqlite-vec 集成待后续模块补全
  Future<List<MemoryEntry>> searchByEmbedding({
    required List<double> embedding,
    String? assistantId,
    int limit = 20,
  }) async {
    // TODO: 集成 sqlite-vec 实现向量检索
    // 当前阶段未提供 embedding 模型，返回空列表
    return [];
  }
}