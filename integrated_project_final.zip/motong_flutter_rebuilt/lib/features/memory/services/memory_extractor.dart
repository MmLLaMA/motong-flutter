/// 模块 3 — 记忆提取器
/// 完整流程：幂等 → pending task → 增量消息 → LLM 调用 → 解析 → 去重合并 → complete/failed

import 'dart:convert';
import 'package:uuid/uuid.dart';
import '../data/memory_repository.dart';
import '../models/memory_entry.dart';
import '../models/memory_extraction_task.dart';

class LlmChatFn = Future<String> Function({
  required List<Map<String, String>> messages,
  double temperature,
});

class FetchMessagesFn = Future<List<Map<String, dynamic>>> Function(
    String conversationId);

class MemoryExtractor {
  final MemoryRepository _repository;
  final LlmChatFn _llmChat;
  final FetchMessagesFn _fetchMessages;
  final Uuid _uuid = const Uuid();

  MemoryExtractor({
    required MemoryRepository repository,
    required LlmChatFn llmChat,
    required FetchMessagesFn fetchUnprocessedMessages,
  })  : _repository = repository,
        _llmChat = llmChat,
        _fetchMessages = fetchUnprocessedMessages;

  /// 触发记忆提取
  Future<void> triggerExtraction(
    String conversationId,
    ExtractionTrigger trigger,
  ) async {
    // 幂等检查
    if (await _repository.hasPendingTask(conversationId)) {
      return;
    }

    // 1. 创建 pending task
    final task = MemoryExtractionTask(
      id: _uuid.v4(),
      conversationId: conversationId,
      status: ExtractionStatus.pending,
      triggeredBy: trigger,
      messageRange: '{}',
      createdAt: DateTime.now().millisecondsSinceEpoch,
    );
    await _repository.createTask(task);

    try {
      // 2. 更新为 processing
      await _repository.updateTask(
        task.id,
        ExtractionStatus.processing,
      );

      // 3. 获取待提取消息
      final messages = await _fetchMessages(conversationId);
      if (messages.isEmpty) {
        await _repository.updateTask(
          task.id,
          ExtractionStatus.completed,
          resultCount: 0,
        );
        return;
      }

      // 4. 构建 LLM 提取 prompt
      final prompt = _buildExtractionPrompt(messages);

      // 5. 调用 LLM
      final response = await _llmChat(
        messages: [
          {'role': 'system', 'content': _extractionSystemPrompt},
          {'role': 'user', 'content': prompt},
        ],
        temperature: 0.3,
      );

      // 6. 解析 LLM 返回
      final extracted = _parseExtractionResponse(response);

      // 7. 去重合并（基于关键词 Jaccard 相似度 > 0.5）
      var insertedCount = 0;
      for (final entry in extracted) {
        final isDuplicate = await _isDuplicate(entry);
        if (!isDuplicate) {
          await _repository.create(entry);
          insertedCount++;
        }
      }

      // 8. 更新 task 为 completed
      await _repository.updateTask(
        task.id,
        ExtractionStatus.completed,
        resultCount: insertedCount,
      );
    } catch (e) {
      await _repository.updateTask(
        task.id,
        ExtractionStatus.failed,
        errorMessage: e.toString(),
      );
    }
  }

  /// 检查与现有记忆的关键词 Jaccard 相似度
  Future<bool> _isDuplicate(MemoryEntry entry) async {
    final existing = await _repository.search(
      query: entry.content,
      limit: 5,
    );
    for (final e in existing) {
      final sim = _jaccardSimilarity(
        entry.keywords.toLowerCase(),
        e.keywords.toLowerCase(),
      );
      if (sim > 0.5) return true;
    }
    return false;
  }

  double _jaccardSimilarity(String a, String b) {
    final setA = a.split(RegExp(r'\s+')).where((s) => s.isNotEmpty).toSet();
    final setB = b.split(RegExp(r'\s+')).where((s) => s.isNotEmpty).toSet();
    if (setA.isEmpty && setB.isEmpty) return 0;
    final intersection = setA.intersection(setB).length;
    final union = setA.union(setB).length;
    return union == 0 ? 0 : intersection / union;
  }

  String _buildExtractionPrompt(List<Map<String, dynamic>> messages) {
    final buffer = StringBuffer();
    for (final m in messages) {
      buffer.writeln('${m['role']}: ${m['content']}');
      buffer.writeln();
    }
    return '请从以下对话中提取值得长期记忆的事实：\n\n${buffer.toString()}';
  }

  String get _extractionSystemPrompt => '''
你是一位专业的记忆提取专家。请从对话内容中提取值得长期记忆的信息。

输出要求：
1. 仅输出 JSON 数组，不要任何额外解释
2. 每条记忆包含字段：content (string), category (fact|preference|goal|event|emotion|relationship), importance (1-10), assistant_id (nullable), keywords (string)
3. importance: 用户明确标注的重要事项=10，事实=5，临时提及=3
4. keywords: 提取 3-5 个核心关键词，空格分隔
5. 忽略寒暄、问候、问候语

输出格式示例：
[{"content":"...","category":"preference","importance":7,"assistant_id":null,"keywords":"..."}]
''';

  List<MemoryEntry> _parseExtractionResponse(String response) {
    try {
      // 提取 JSON 数组（可能包裹在 markdown fence 中）
      final cleaned = response
          .replaceAll('```json', '')
          .replaceAll('```', '')
          .trim();
      final startIdx = cleaned.indexOf('[');
      final endIdx = cleaned.lastIndexOf(']');
      if (startIdx == -1 || endIdx == -1) return [];
      final jsonStr = cleaned.substring(startIdx, endIdx + 1);

      final List<dynamic> array = jsonDecode(jsonStr) as List<dynamic>;
      final now = DateTime.now().millisecondsSinceEpoch;
      return array.map((raw) {
        final m = raw as Map<String, dynamic>;
        return MemoryEntry(
          id: _uuid.v4(),
          content: m['content'] as String? ?? '',
          category: MemoryCategory.values.firstWhere(
            (e) => e.name == (m['category'] as String? ?? 'fact'),
            orElse: () => MemoryCategory.fact,
          ),
          importance: (m['importance'] as num?)?.toInt() ?? 5,
          source: MemorySource.auto,
          assistantId: m['assistant_id'] as String?,
          conversationId: '',
          keywords: m['keywords'] as String? ?? '',
          createdAt: now,
          updatedAt: now,
        );
      }).toList();
    } catch (_) {
      return [];
    }
  }
}