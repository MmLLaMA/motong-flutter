import 'dart:async';
import 'package:flutter/foundation.dart';
import '../models/models.dart';
import '../services/phone_control_service.dart';

/// 手机控制状态管理 — ChangeNotifier，与架构文档 4.2 一致
///
/// 管理权限状态、设备状态、应用锁定配置，
/// 并与现有 ProviderManager/ChatProvider 风格保持一致。
class PhoneControlProvider extends ChangeNotifier {
  final PhoneControlService _service;

  PhoneControlProvider({PhoneControlService? service})
      : _service = service ?? PhoneControlService();

  // ──────────────────────────────────────────────
  // 状态
  // ──────────────────────────────────────────────

  PermissionStatus? _permissions;
  DeviceState? _deviceState;
  AppLockConfig? _appLockConfig;
  bool _isLoading = false;
  String? _errorMessage;
  String? _currentForegroundPackage;
  StreamSubscription? _foregroundAppSubscription;

  // ──────────────────────────────────────────────
  // Getters
  // ──────────────────────────────────────────────

  PermissionStatus? get permissions => _permissions;
  DeviceState? get deviceState => _deviceState;
  AppLockConfig? get appLockConfig => _appLockConfig;
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;
  String? get currentForegroundPackage => _currentForegroundPackage;

  bool get allPermissionsGranted => _permissions?.allGranted ?? false;

  List<PermissionType> get missingPermissions =>
      _permissions?.missing ?? PermissionType.values;

  // ──────────────────────────────────────────────
  // 初始化
  // ──────────────────────────────────────────────

  /// 启动时调用：加载权限 + 设备状态 + 锁定配置
  Future<void> initialize() async {
    await Future.wait([
      loadPermissions(),
      refreshDeviceState(),
      loadAppLockConfig(),
    ]);
  }

  // ──────────────────────────────────────────────
  // 权限
  // ──────────────────────────────────────────────

  /// 加载当前权限状态
  Future<void> loadPermissions() async {
    _setLoading(true);
    _permissions = await _service.getPermissionsStatus();
    _setLoading(false);
  }

  /// 请求某项权限 — 带降级策略
  Future<bool> requestPermission(PermissionType type) async {
    _setLoading(true);
    _clearError();
    bool granted;
    switch (type) {
      case PermissionType.accessibility:
        granted = await _service.requestAccessibilityPermission();
      case PermissionType.deviceAdmin:
        granted = await _service.requestDeviceAdminPermission();
      case PermissionType.overlay:
        granted = await _service.requestOverlayPermission();
      case PermissionType.usageStats:
        granted = await _service.requestUsageStatsPermission();
    }
    // 请求后立即刷新权限状态
    await loadPermissions();
    return granted;
  }

  // ──────────────────────────────────────────────
  // 设备控制
  // ──────────────────────────────────────────────

  /// 刷新设备状态
  Future<void> refreshDeviceState() async {
    try {
      final results = await Future.wait([
        _service.isScreenLocked(),
        _service.getScreenBrightness(),
        _service.getScreenTimeout(),
        _service.getCurrentForegroundApp(),
      ]);
      _deviceState = DeviceState(
        isScreenLocked: results[0] as bool,
        screenBrightness: results[1] as int,
        screenTimeout: Duration(milliseconds: results[2] as int),
        currentForegroundPackage: results[3] as String?,
      );
      _currentForegroundPackage = results[3] as String?;
      notifyListeners();
    } catch (e) {
      _setError('刷新设备状态失败: $e');
    }
  }

  /// 倒计时后锁屏
  Future<void> lockScreenWithCountdown(int seconds) async {
    _setLoading(true);
    final ok = await _service.lockScreenWithCountdown(seconds);
    if (ok) {
      await refreshDeviceState();
    } else {
      _setError('锁屏失败，请检查设备管理员权限');
    }
    _setLoading(false);
  }

  /// 立即锁屏
  Future<void> lockScreen() async {
    _setLoading(true);
    final ok = await _service.lockScreen();
    if (ok) {
      await refreshDeviceState();
    } else {
      _setError('锁屏失败，请检查设备管理员权限');
    }
    _setLoading(false);
  }

  /// 设置屏幕超时
  Future<void> setScreenTimeout(Duration timeout) async {
    _setLoading(true);
    final ok = await _service.setScreenTimeout(timeout.inMilliseconds);
    if (ok) {
      await refreshDeviceState();
    } else {
      _setError('设置屏幕超时失败');
    }
    _setLoading(false);
  }

  /// 设置屏幕亮度
  Future<void> setScreenBrightness(int brightness) async {
    _setLoading(true);
    final ok = await _service.setScreenBrightness(brightness);
    if (ok) {
      await refreshDeviceState();
    } else {
      _setError('设置屏幕亮度失败');
    }
    _setLoading(false);
  }

  // ──────────────────────────────────────────────
  // 应用锁定
  // ──────────────────────────────────────────────

  /// 加载应用锁定配置
  Future<void> loadAppLockConfig() async {
    try {
      final isEnabled = await _service.isAppLockEnabled();
      final whitelist = await _service.getAppLockWhitelist();
      _appLockConfig = AppLockConfig(
        isEnabled: isEnabled,
        mode: isEnabled ? AppLockMode.whitelist : AppLockMode.disabled,
        whitelistPackages: whitelist,
      );
      notifyListeners();
    } catch (e) {
      _setError('加载应用锁定配置失败: $e');
    }
  }

  /// 更新白名单
  Future<void> updateWhitelist(
      List<String> add, List<String> remove) async {
    final current = List<String>.from(_appLockConfig?.whitelistPackages ?? []);
    for (final pkg in add) {
      if (!current.contains(pkg)) current.add(pkg);
    }
    current.removeWhere((pkg) => remove.contains(pkg));
    final ok = await _service.setAppLockWhitelist(current);
    if (ok) {
      await loadAppLockConfig();
    } else {
      _setError('更新白名单失败');
    }
  }

  /// 切换应用锁定开关
  Future<void> toggleAppLock(bool enabled) async {
    _setLoading(true);
    final ok = await _service.setAppLockEnabled(enabled);
    if (ok) {
      await loadAppLockConfig();
    } else {
      _setError('切换应用锁定失败');
    }
    _setLoading(false);
  }

  // ──────────────────────────────────────────────
  // 前台监听
  // ──────────────────────────────────────────────

  /// 开始监听前台应用切换
  Future<void> startMonitoring() async {
    final ok = await _service.startForegroundAppMonitoring();
    if (ok) {
      _foregroundAppSubscription?.cancel();
      _foregroundAppSubscription =
          _service.foregroundAppStream.listen((event) {
        _currentForegroundPackage = event['packageName'] as String?;
        notifyListeners();
      });
    }
  }

  /// 停止监听
  Future<void> stopMonitoring() async {
    _foregroundAppSubscription?.cancel();
    _foregroundAppSubscription = null;
    await _service.stopForegroundAppMonitoring();
  }

  /// 清除错误信息
  void clearError() {
    _clearError();
  }

  // ──────────────────────────────────────────────
  // 私有辅助
  // ──────────────────────────────────────────────

  void _setLoading(bool value) {
    _isLoading = value;
    notifyListeners();
  }

  void _setError(String message) {
    _errorMessage = message;
    notifyListeners();
  }

  void _clearError() {
    if (_errorMessage != null) {
      _errorMessage = null;
      notifyListeners();
    }
  }

  @override
  void dispose() {
    _foregroundAppSubscription?.cancel();
    super.dispose();
  }
}