/// 应用锁定模式 — 与架构文档 8.3 一致
enum AppLockMode {
  /// 白名单模式：仅白名单内应用可打开
  whitelist,

  /// 停用
  disabled,
}

/// 应用锁定配置数据类 — 与架构文档 8.3 一致
class AppLockConfig {
  /// 应用锁定是否启用
  final bool isEnabled;

  /// 锁定模式
  final AppLockMode mode;

  /// 白名单包名列表
  final List<String> whitelistPackages;

  const AppLockConfig({
    required this.isEnabled,
    required this.mode,
    required this.whitelistPackages,
  });

  /// 判断指定包名是否被允许打开
  bool isAllowed(String packageName) {
    if (!isEnabled) return true;
    return whitelistPackages.contains(packageName);
  }

  factory AppLockConfig.fromMap(Map<String, dynamic> map) {
    return AppLockConfig(
      isEnabled: map['isEnabled'] == true,
      mode: _parseMode(map['mode'] as String?),
      whitelistPackages:
          List<String>.from((map['whitelistPackages'] as List?) ?? []),
    );
  }

  static AppLockMode _parseMode(String? modeStr) {
    switch (modeStr) {
      case 'whitelist':
        return AppLockMode.whitelist;
      default:
        return AppLockMode.disabled;
    }
  }

  Map<String, dynamic> toMap() {
    return {
      'isEnabled': isEnabled,
      'mode': mode == AppLockMode.whitelist ? 'whitelist' : 'disabled',
      'whitelistPackages': whitelistPackages,
    };
  }

  AppLockConfig copyWith({
    bool? isEnabled,
    AppLockMode? mode,
    List<String>? whitelistPackages,
  }) {
    return AppLockConfig(
      isEnabled: isEnabled ?? this.isEnabled,
      mode: mode ?? this.mode,
      whitelistPackages: whitelistPackages ?? this.whitelistPackages,
    );
  }
}