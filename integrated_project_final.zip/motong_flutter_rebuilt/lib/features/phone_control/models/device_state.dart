/// 设备状态数据类 — 与架构文档 8.2 一致
///
/// 包含电池、屏幕、网络相关设备状态信息。
class DeviceState {
  /// 屏幕是否锁定
  final bool isScreenLocked;

  /// 屏幕亮度 (0-255)
  final int screenBrightness;

  /// 屏幕超时时间
  final Duration screenTimeout;

  /// 当前前台应用包名（可为空）
  final String? currentForegroundPackage;

  const DeviceState({
    required this.isScreenLocked,
    required this.screenBrightness,
    required this.screenTimeout,
    this.currentForegroundPackage,
  });

  factory DeviceState.fromMap(Map<String, dynamic> map) {
    return DeviceState(
      isScreenLocked: map['isScreenLocked'] == true,
      screenBrightness: (map['screenBrightness'] as num?)?.toInt() ?? 128,
      screenTimeout: Duration(
        milliseconds: (map['screenTimeout'] as num?)?.toInt() ?? 30000,
      ),
      currentForegroundPackage: map['currentForegroundPackage'] as String?,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'isScreenLocked': isScreenLocked,
      'screenBrightness': screenBrightness,
      'screenTimeout': screenTimeout.inMilliseconds,
      'currentForegroundPackage': currentForegroundPackage,
    };
  }

  DeviceState copyWith({
    bool? isScreenLocked,
    int? screenBrightness,
    Duration? screenTimeout,
    String? currentForegroundPackage,
  }) {
    return DeviceState(
      isScreenLocked: isScreenLocked ?? this.isScreenLocked,
      screenBrightness: screenBrightness ?? this.screenBrightness,
      screenTimeout: screenTimeout ?? this.screenTimeout,
      currentForegroundPackage:
          currentForegroundPackage ?? this.currentForegroundPackage,
    );
  }
}