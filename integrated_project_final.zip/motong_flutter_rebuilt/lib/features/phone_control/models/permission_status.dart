/// 权限类型枚举 — 与架构文档 8.1 一致
enum PermissionType {
  /// 辅助功能
  accessibility,

  /// 设备管理器
  deviceAdmin,

  /// 悬浮窗
  overlay,

  /// 使用情况访问
  usageStats,
}

/// 权限状态数据类 — 与架构文档 8.1 一致
class PermissionStatus {
  final bool accessibility;
  final bool deviceAdmin;
  final bool overlay;
  final bool usageStats;

  const PermissionStatus({
    required this.accessibility,
    required this.deviceAdmin,
    required this.overlay,
    required this.usageStats,
  });

  /// 全部权限均已授予
  bool get allGranted =>
      accessibility && deviceAdmin && overlay && usageStats;

  /// 未授予的权限列表
  List<PermissionType> get missing {
    final list = <PermissionType>[];
    if (!accessibility) list.add(PermissionType.accessibility);
    if (!deviceAdmin) list.add(PermissionType.deviceAdmin);
    if (!overlay) list.add(PermissionType.overlay);
    if (!usageStats) list.add(PermissionType.usageStats);
    return list;
  }

  factory PermissionStatus.fromMap(Map<String, dynamic> map) {
    return PermissionStatus(
      accessibility: map['accessibility'] == true,
      deviceAdmin: map['deviceAdmin'] == true,
      overlay: map['overlay'] == true,
      usageStats: map['usageStats'] == true,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'accessibility': accessibility,
      'deviceAdmin': deviceAdmin,
      'overlay': overlay,
      'usageStats': usageStats,
    };
  }
}