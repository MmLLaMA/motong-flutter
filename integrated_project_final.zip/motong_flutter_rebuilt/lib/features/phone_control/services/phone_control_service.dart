import 'package:flutter/services.dart';
import '../models/models.dart';

/// MethodChannel 桥接服务 — channel name 与架构文档 3.1 一致
///
/// 所有 native 调用均以 try/catch 包裹，
/// 平台不支持或调用失败时返回安全默认值。
class PhoneControlService {
  static const String channelName = 'com.motong/phone_control';
  static const String foregroundAppChannelName =
      'com.motong/phone_control/foreground_app';

  static const MethodChannel _channel = MethodChannel(channelName);
  static const EventChannel _foregroundAppChannel =
      EventChannel(foregroundAppChannelName);

  // ──────────────────────────────────────────────
  // 权限类 (9 methods) — 架构文档 3.2.1
  // ──────────────────────────────────────────────

  /// 获取全部权限授权状态
  Future<PermissionStatus> getPermissionsStatus() async {
    try {
      final result = await _channel.invokeMethod('getPermissionsStatus');
      if (result is Map) {
        return PermissionStatus.fromMap(Map<String, dynamic>.from(result));
      }
      return _defaultPermissionStatus();
    } catch (e) {
      return _defaultPermissionStatus();
    }
  }

  /// 跳转系统辅助功能设置页
  Future<bool> requestAccessibilityPermission() async {
    try {
      final result =
          await _channel.invokeMethod('requestAccessibilityPermission');
      return result == true;
    } catch (e) {
      return false;
    }
  }

  /// 跳转设备管理器激活页
  Future<bool> requestDeviceAdminPermission() async {
    try {
      final result =
          await _channel.invokeMethod('requestDeviceAdminPermission');
      return result == true;
    } catch (e) {
      return false;
    }
  }

  /// 请求悬浮窗权限 (Android 6.0+)
  Future<bool> requestOverlayPermission() async {
    try {
      final result = await _channel.invokeMethod('requestOverlayPermission');
      return result == true;
    } catch (e) {
      return false;
    }
  }

  /// 跳转使用情况访问权限页
  Future<bool> requestUsageStatsPermission() async {
    try {
      final result =
          await _channel.invokeMethod('requestUsageStatsPermission');
      return result == true;
    } catch (e) {
      return false;
    }
  }

  /// 检查辅助功能是否已开启
  Future<bool> isAccessibilityServiceEnabled() async {
    try {
      final result =
          await _channel.invokeMethod('isAccessibilityServiceEnabled');
      return result == true;
    } catch (e) {
      return false;
    }
  }

  /// 检查设备管理器是否已激活
  Future<bool> isDeviceAdminActive() async {
    try {
      final result = await _channel.invokeMethod('isDeviceAdminActive');
      return result == true;
    } catch (e) {
      return false;
    }
  }

  /// 检查悬浮窗权限是否已授予
  Future<bool> isOverlayPermissionGranted() async {
    try {
      final result =
          await _channel.invokeMethod('isOverlayPermissionGranted');
      return result == true;
    } catch (e) {
      return false;
    }
  }

  /// 检查使用情况访问权限是否已授予
  Future<bool> isUsageStatsPermissionGranted() async {
    try {
      final result =
          await _channel.invokeMethod('isUsageStatsPermissionGranted');
      return result == true;
    } catch (e) {
      return false;
    }
  }

  // ──────────────────────────────────────────────
  // 设备控制类 (7 methods) — 架构文档 3.2.2
  // ──────────────────────────────────────────────

  /// 立即锁屏
  Future<bool> lockScreen() async {
    try {
      final result = await _channel.invokeMethod('lockScreen');
      return result == true;
    } catch (e) {
      return false;
    }
  }

  /// 倒计时后锁屏（Flutter 侧倒计时 UI + 到时调用）
  Future<bool> lockScreenWithCountdown(int seconds) async {
    try {
      final result = await _channel.invokeMethod(
        'lockScreenWithCountdown',
        {'seconds': seconds},
      );
      return result == true;
    } catch (e) {
      return false;
    }
  }

  /// 设置屏幕超时时间（毫秒），-1 表示系统默认
  Future<bool> setScreenTimeout(int millis) async {
    try {
      final result = await _channel.invokeMethod(
        'setScreenTimeout',
        {'millis': millis},
      );
      return result == true;
    } catch (e) {
      return false;
    }
  }

  /// 获取当前屏幕超时时间（毫秒）
  Future<int> getScreenTimeout() async {
    try {
      final result = await _channel.invokeMethod('getScreenTimeout');
      if (result is int) return result;
      if (result is num) return result.toInt();
      return 30000; // 默认 30 秒
    } catch (e) {
      return 30000;
    }
  }

  /// 设置屏幕亮度 (0-255)
  Future<bool> setScreenBrightness(int brightness) async {
    try {
      final result = await _channel.invokeMethod(
        'setScreenBrightness',
        {'brightness': brightness},
      );
      return result == true;
    } catch (e) {
      return false;
    }
  }

  /// 获取当前屏幕亮度 (0-255)
  Future<int> getScreenBrightness() async {
    try {
      final result = await _channel.invokeMethod('getScreenBrightness');
      if (result is int) return result;
      if (result is num) return result.toInt();
      return 128;
    } catch (e) {
      return 128;
    }
  }

  /// 查询屏幕是否锁定
  Future<bool> isScreenLocked() async {
    try {
      final result = await _channel.invokeMethod('isScreenLocked');
      return result == true;
    } catch (e) {
      return false;
    }
  }

  // ──────────────────────────────────────────────
  // 应用锁定类 (5 methods) — 架构文档 3.2.3
  // ──────────────────────────────────────────────

  /// 获取已安装应用列表（包名 + 应用名）
  Future<List<Map<String, dynamic>>> getInstalledApps() async {
    try {
      final result = await _channel.invokeMethod('getInstalledApps');
      if (result is List) {
        return result
            .map((e) => Map<String, dynamic>.from(e as Map))
            .toList();
      }
      return [];
    } catch (e) {
      return [];
    }
  }

  /// 设置应用白名单
  Future<bool> setAppLockWhitelist(List<String> packageNames) async {
    try {
      final result = await _channel.invokeMethod(
        'setAppLockWhitelist',
        {'packageNames': packageNames},
      );
      return result == true;
    } catch (e) {
      return false;
    }
  }

  /// 获取当前白名单
  Future<List<String>> getAppLockWhitelist() async {
    try {
      final result = await _channel.invokeMethod('getAppLockWhitelist');
      if (result is List) {
        return result.map((e) => e.toString()).toList();
      }
      return [];
    } catch (e) {
      return [];
    }
  }

  /// 启用/停用应用锁定
  Future<bool> setAppLockEnabled(bool enabled) async {
    try {
      final result = await _channel.invokeMethod(
        'setAppLockEnabled',
        {'enabled': enabled},
      );
      return result == true;
    } catch (e) {
      return false;
    }
  }

  /// 查询应用锁定是否启用
  Future<bool> isAppLockEnabled() async {
    try {
      final result = await _channel.invokeMethod('isAppLockEnabled');
      return result == true;
    } catch (e) {
      return false;
    }
  }

  // ──────────────────────────────────────────────
  // 前台应用监听类 (3 methods + EventChannel) — 架构文档 3.2.4, 3.2.5
  // ──────────────────────────────────────────────

  /// 开始监听前台应用切换
  Future<bool> startForegroundAppMonitoring() async {
    try {
      final result =
          await _channel.invokeMethod('startForegroundAppMonitoring');
      return result == true;
    } catch (e) {
      return false;
    }
  }

  /// 停止监听前台应用切换
  Future<bool> stopForegroundAppMonitoring() async {
    try {
      final result =
          await _channel.invokeMethod('stopForegroundAppMonitoring');
      return result == true;
    } catch (e) {
      return false;
    }
  }

  /// 获取当前前台应用包名
  Future<String?> getCurrentForegroundApp() async {
    try {
      final result =
          await _channel.invokeMethod('getCurrentForegroundApp');
      if (result is String && result.isNotEmpty) return result;
      return null;
    } catch (e) {
      return null;
    }
  }

  /// 前台应用切换事件流
  Stream<Map<String, dynamic>> get foregroundAppStream {
    return _foregroundAppChannel
        .receiveBroadcastStream()
        .map((event) => Map<String, dynamic>.from(event as Map));
  }

  // ──────────────────────────────────────────────
  // 私有辅助
  // ──────────────────────────────────────────────

  PermissionStatus _defaultPermissionStatus() {
    return const PermissionStatus(
      accessibility: false,
      deviceAdmin: false,
      overlay: false,
      usageStats: false,
    );
  }
}