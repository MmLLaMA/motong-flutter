import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/models.dart';
import '../providers/phone_control_provider.dart';

/// 手机控制设置主页 — 路由 /settings/phone-control
///
/// 包含：权限检测卡片 / 设备控制区 / 应用锁定配置 / 辅助功能状态
///
/// 与 PRD 六·设置页 UI 结构一致。
class PhoneControlPage extends StatefulWidget {
  const PhoneControlPage({super.key});

  @override
  State<PhoneControlPage> createState() => _PhoneControlPageState();
}

class _PhoneControlPageState extends State<PhoneControlPage> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<PhoneControlProvider>().initialize();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('手机控制')),
      body: Consumer<PhoneControlProvider>(
        builder: (context, provider, _) {
          if (provider.isLoading && provider.permissions == null) {
            return const Center(child: CircularProgressIndicator());
          }

          // 错误 Banner
          final errorBanner = provider.errorMessage != null
              ? MaterialBanner(
                  content: Text(provider.errorMessage!),
                  actions: [
                    TextButton(
                      onPressed: () => provider.clearError(),
                      child: const Text('关闭'),
                    ),
                  ],
                )
              : null;

          return ListView(
            children: [
              if (errorBanner != null) errorBanner,
              _buildPermissionSection(provider),
              _buildDeviceControlSection(provider),
              _buildAppLockSection(provider),
              _buildServiceStatusSection(provider),
              const SizedBox(height: 32),
            ],
          );
        },
      ),
    );
  }

  // ═══════════════════════════════════════════
  // 权限检测卡片 — 架构文档 4.2 / PRD 6.2 组4
  // ═══════════════════════════════════════════

  Widget _buildPermissionSection(PhoneControlProvider provider) {
    final perms = provider.permissions;
    final hasProvider = perms != null;
    final allGranted = hasProvider && perms.allGranted;

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  allGranted ? Icons.check_circle : Icons.warning_amber_rounded,
                  color: allGranted ? Colors.green : Colors.orange,
                ),
                const SizedBox(width: 8),
                Text(
                  '权限状态',
                  style: Theme.of(context).textTheme.titleMedium,
                ),
                const Spacer(),
                if (allGranted)
                  const Chip(
                    label: Text('全部已授权'),
                    backgroundColor: Colors.green,
                    labelStyle: TextStyle(color: Colors.white, fontSize: 12),
                  ),
              ],
            ),
            const SizedBox(height: 12),
            _permissionRow(
              '辅助功能',
              hasProvider && perms.accessibility,
              () => provider.requestPermission(PermissionType.accessibility),
              provider.isLoading,
            ),
            _permissionRow(
              '设备管理器',
              hasProvider && perms.deviceAdmin,
              () => provider.requestPermission(PermissionType.deviceAdmin),
              provider.isLoading,
            ),
            _permissionRow(
              '悬浮窗',
              hasProvider && perms.overlay,
              () => provider.requestPermission(PermissionType.overlay),
              provider.isLoading,
            ),
            _permissionRow(
              '使用情况访问',
              hasProvider && perms.usageStats,
              () => provider.requestPermission(PermissionType.usageStats),
              provider.isLoading,
            ),
          ],
        ),
      ),
    );
  }

  Widget _permissionRow(
    String label,
    bool granted,
    VoidCallback onTap,
    bool loading,
  ) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Icon(
            granted ? Icons.check_circle_outline : Icons.cancel_outlined,
            size: 16,
            color: granted ? Colors.green : Colors.red,
          ),
          const SizedBox(width: 8),
          Expanded(child: Text(label)),
          if (!granted)
            TextButton(
              onPressed: loading ? null : onTap,
              child: const Text('去授权'),
            )
          else
            const Chip(
              label: Text('已授权', style: TextStyle(fontSize: 12)),
              backgroundColor: Colors.green,
              labelStyle: TextStyle(color: Colors.white),
            ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════
  // 设备控制区 — PRD 6.2 组1·组3·组5
  // ═══════════════════════════════════════════

  Widget _buildDeviceControlSection(PhoneControlProvider provider) {
    final ds = provider.deviceState;

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('设备控制', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 12),
            // 锁定设备按钮 (P0)
            ListTile(
              leading: const Icon(Icons.lock),
              title: const Text('锁定设备'),
              subtitle: Text(ds != null
                  ? (ds.isScreenLocked ? '已锁定' : '已解锁')
                  : '加载中...'),
              trailing: OutlinedButton(
                onPressed:
                    provider.isLoading ? null : () => provider.lockScreen(),
                child: const Text('立即锁屏'),
              ),
            ),
            // 设备状态信息
            if (ds != null) ...[
              _infoRow('屏幕亮度', '${ds.screenBrightness}/255'),
              _infoRow('屏幕超时', '${ds.screenTimeout.inSeconds}秒'),
              if (ds.currentForegroundPackage != null)
                _infoRow('前台应用', ds.currentForegroundPackage!),
            ],
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════
  // 应用锁定配置 — PRD 6.2 组2
  // ═══════════════════════════════════════════

  Widget _buildAppLockSection(PhoneControlProvider provider) {
    final config = provider.appLockConfig;

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('应用锁定', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 12),
            // 总开关 (P0)
            SwitchListTile(
              title: const Text('锁定模式'),
              subtitle: const Text('开启后仅白名单应用可打开'),
              value: config?.isEnabled ?? false,
              onChanged: (val) => provider.toggleAppLock(val),
            ),
            // 白名单信息 (P0)
            if (config != null && config.isEnabled) ...[
              const Divider(),
              Text(
                '白名单 (${config.whitelistPackages.length})',
                style: Theme.of(context).textTheme.bodySmall,
              ),
              const SizedBox(height: 4),
              if (config.whitelistPackages.isEmpty)
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 8),
                  child: Text('暂无白名单应用', style: TextStyle(color: Colors.grey)),
                )
              else
                ...config.whitelistPackages.map(
                  (pkg) => ListTile(
                    dense: true,
                    title: Text(pkg, style: const TextStyle(fontSize: 13)),
                  ),
                ),
            ],
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════
  // 辅助功能状态 — PRD 6.2 组4
  // ═══════════════════════════════════════════

  Widget _buildServiceStatusSection(PhoneControlProvider provider) {
    final perms = provider.permissions;
    final hasPerms = perms != null;

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('服务状态', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 12),
            _statusRow(
              '无障碍服务',
              hasPerms && perms.accessibility,
              hasPerms && !perms.accessibility
                  ? () => provider.requestPermission(PermissionType.accessibility)
                  : null,
            ),
            _statusRow(
              '悬浮窗权限',
              hasPerms && perms.overlay,
              hasPerms && !perms.overlay
                  ? () => provider.requestPermission(PermissionType.overlay)
                  : null,
            ),
            _statusRow(
              '使用情况访问',
              hasPerms && perms.usageStats,
              hasPerms && !perms.usageStats
                  ? () => provider.requestPermission(PermissionType.usageStats)
                  : null,
            ),
            _statusRow(
              '设备管理器',
              hasPerms && perms.deviceAdmin,
              hasPerms && !perms.deviceAdmin
                  ? () => provider.requestPermission(PermissionType.deviceAdmin)
                  : null,
            ),
          ],
        ),
      ),
    );
  }

  Widget _statusRow(String label, bool ok, VoidCallback? onFix) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: ok ? Colors.green : Colors.red,
            ),
          ),
          const SizedBox(width: 8),
          Text(label),
          const Spacer(),
          Text(ok ? '正常' : '异常'),
          if (!ok && onFix != null) ...[
            const SizedBox(width: 8),
            TextButton(onPressed: onFix, child: const Text('修复')),
          ],
        ],
      ),
    );
  }

  Widget _infoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Text('$label: ', style: const TextStyle(color: Colors.grey)),
          Text(value),
        ],
      ),
    );
  }
}