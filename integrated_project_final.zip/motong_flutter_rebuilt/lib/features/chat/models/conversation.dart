/// 对话会话模型（带 lastExtractedMessageId 用于记忆系统）
/// 与 agents/models 中的 Conversation 同名，但实际是同一个模型的 re-export

export '../../../agents/models/provider.dart' show Conversation;