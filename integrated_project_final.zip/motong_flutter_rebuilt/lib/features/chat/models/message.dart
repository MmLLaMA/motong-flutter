/// 消息数据模型
/// 定义聊天中每条消息的结构，支持用户/AI/系统三种角色
enum MessageRole { user, assistant, system }

/// 消息发送状态
enum MessageStatus { sending, streaming, done, error }

class Message {
  /// 唯一标识
  final String id;

  /// 所属对话 ID
  final String conversationId;

  /// 消息角色：用户、AI 助手或系统
  final MessageRole role;

  /// 消息正文内容
  String content;

  /// 翻译前的原始内容，用于撤销翻译
  String? originalContent;

  /// 引用的父消息 ID（用户消息），用于重新生成时定位
  final String? parentMessageId;

  /// Token 数量估算
  final int? tokenCount;

  /// 消息创建时间
  final DateTime createdAt;

  /// 当前发送状态
  MessageStatus status;

  /// 扩展元数据（如 TTS 音频缓存路径等）
  Map<String, dynamic>? metadata;

  Message({
    required this.id,
    required this.conversationId,
    required this.role,
    required this.content,
    this.originalContent,
    this.parentMessageId,
    this.tokenCount,
    DateTime? createdAt,
    this.status = MessageStatus.done,
    this.metadata,
  }) : createdAt = createdAt ?? DateTime.now();

  /// 从 JSON 反序列化
  factory Message.fromJson(Map<String, dynamic> json) {
    return Message(
      id: json['id'] as String,
      conversationId: json['conversation_id'] as String,
      role: MessageRole.values.firstWhere(
        (e) => e.name == json['role'],
        orElse: () => MessageRole.user,
      ),
      content: json['content'] as String,
      originalContent: json['original_content'] as String?,
      parentMessageId: json['parent_message_id'] as String?,
      tokenCount: json['token_count'] as int?,
      createdAt: json['created_at'] != null
          ? DateTime.parse(json['created_at'] as String)
          : DateTime.now(),
      status: MessageStatus.values.firstWhere(
        (e) => e.name == json['status'],
        orElse: () => MessageStatus.done,
      ),
      metadata: json['metadata'] != null
          ? Map<String, dynamic>.from(json['metadata'] as Map)
          : null,
    );
  }

  /// 序列化为 JSON
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'conversation_id': conversationId,
      'role': role.name,
      'content': content,
      'original_content': originalContent,
      'parent_message_id': parentMessageId,
      'token_count': tokenCount,
      'created_at': createdAt.toIso8601String(),
      'status': status.name,
      'metadata': metadata,
    };
  }

  /// 创建一份副本（用于不可变更新）
  Message copyWith({
    String? id,
    String? conversationId,
    MessageRole? role,
    String? content,
    String? originalContent,
    String? parentMessageId,
    int? tokenCount,
    DateTime? createdAt,
    MessageStatus? status,
    Map<String, dynamic>? metadata,
    bool clearOriginalContent = false,
  }) {
    return Message(
      id: id ?? this.id,
      conversationId: conversationId ?? this.conversationId,
      role: role ?? this.role,
      content: content ?? this.content,
      originalContent:
          clearOriginalContent ? null : (originalContent ?? this.originalContent),
      parentMessageId: parentMessageId ?? this.parentMessageId,
      tokenCount: tokenCount ?? this.tokenCount,
      createdAt: createdAt ?? this.createdAt,
      status: status ?? this.status,
      metadata: metadata ?? this.metadata,
    );
  }
}