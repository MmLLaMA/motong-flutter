import 'package:flutter/material.dart';
import '../models/message.dart';

/// 消息气泡组件
///
/// 用户消息：右对齐，蓝色背景
/// AI 消息：左对齐，灰色背景，带操作栏
class MessageBubble extends StatelessWidget {
  /// 消息数据
  final Message message;

  /// 消息下方操作栏（仅 AI 消息显示）
  final Widget? actionBar;

  /// 翻译撤销按钮（仅已翻译的 AI 消息显示）
  final Widget? undoButton;

  const MessageBubble({
    super.key,
    required this.message,
    this.actionBar,
    this.undoButton,
  });

  @override
  Widget build(BuildContext context) {
    final isUser = message.role == MessageRole.user;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      child: Column(
        crossAxisAlignment:
            isUser ? CrossAxisAlignment.end : CrossAxisAlignment.start,
        children: [
          // 气泡主体
          Container(
            constraints: BoxConstraints(
              maxWidth: MediaQuery.of(context).size.width * 0.75,
            ),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(
              color: isUser ? Colors.blue[600] : Colors.grey[100],
              borderRadius: BorderRadius.only(
                topLeft: const Radius.circular(16),
                topRight: const Radius.circular(16),
                bottomLeft: Radius.circular(isUser ? 16 : 4),
                bottomRight: Radius.circular(isUser ? 4 : 16),
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // 消息内容
                SelectableText(
                  message.content,
                  style: TextStyle(
                    fontSize: 15,
                    color: isUser ? Colors.white : Colors.black87,
                    height: 1.5,
                  ),
                ),
                // 错误状态提示
                if (message.status == MessageStatus.error)
                  Padding(
                    padding: const EdgeInsets.only(top: 4),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.error_outline,
                            size: 14, color: Colors.red[400]),
                        const SizedBox(width: 4),
                        Text(
                          '发送失败',
                          style: TextStyle(
                            fontSize: 12,
                            color: Colors.red[400],
                          ),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
          ),

          // 撤销翻译按钮（右上角小字）
          if (undoButton != null) ...[
            const SizedBox(height: 2),
            undoButton!,
          ],

          // 操作栏
          if (actionBar != null) ...[
            const SizedBox(height: 4),
            actionBar!,
          ],
        ],
      ),
    );
  }
}