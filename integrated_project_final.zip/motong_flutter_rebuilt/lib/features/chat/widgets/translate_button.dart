import 'package:flutter/material.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';
'import widgets/custom_bottom_sheet.dart';

/// 翻译目标语言选项
const _languageOptions = ['中文', 'English', '日本語', '한국어'];

/// 翻译按钮组件
///
/// 点击弹出语言选择面板 → 选择目标语言 → 回调触发翻译
/// 翻译结果原地替换消息内容
class TranslateButton extends StatelessWidget {
  /// 翻译回调：传入目标语言名称
  final void Function(String targetLanguage) onTranslate;

  /// 消息是否已翻译（控制撤销按钮显示）
  final bool isTranslated;

  /// 撤销翻译回调
  final VoidCallback? onUndo;

  /// 图标大小
  final double iconSize;

  const TranslateButton({
    super.key,
    required this.onTranslate,
    this.isTranslated = false,
    this.onUndo,
    this.iconSize = 18,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        // 翻译按钮
        GestureDetector(
          onTap: () => _showLanguagePicker(context),
          child: Icon(
            LucideIcons.languages,
            size: iconSize,
            color: Colors.grey[600],
          ),
        ),
        // 撤销翻译按钮（仅翻译后显示）
        if (isTranslated && onUndo != null) ...[
          const SizedBox(width: 8),
          GestureDetector(
            onTap: onUndo,
            child: Text(
              '撤销翻译',
              style: TextStyle(
                fontSize: 12,
                color: Colors.blue[600],
                decoration: TextDecoration.underline,
              ),
            ),
          ),
        ],
      ],
    );
  }

  /// 显示语言选择底部面板
  void _showLanguagePicker(BuildContext context) {
    CustomBottomSheet.show(
      context: context,
      title: '选择目标语言',
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: _languageOptions.map((lang) {
          return ListTile(
            leading: Icon(
              _getLanguageIcon(lang),
              size: 22,
            ),
            title: Text(lang),
            trailing: const Icon(Icons.chevron_right, size: 20),
            onTap: () {
              Navigator.of(context).pop();
              onTranslate(lang);
            },
          );
        }).toList(),
      ),
    );
  }

  /// 语言对应图标
  IconData _getLanguageIcon(String lang) {
    switch (lang) {
      case '中文':
        return Icons.language;
      case 'English':
        return Icons.translate;
      case '日本語':
        return Icons.translate;
      case '한국어':
        return Icons.translate;
      default:
        return Icons.language;
    }
  }
}