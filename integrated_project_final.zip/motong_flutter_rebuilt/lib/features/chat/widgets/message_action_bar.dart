import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';
import 'package:share_plus/share_plus.dart';
import '../models/message.dart';

/// 消息操作栏
///
/// 每条 AI 消息下方显示一行图标按钮，包含 7 个操作：
/// 复制、重新生成、删除、分享、编辑、语音、翻译
class MessageActionBar extends StatefulWidget {
  /// 当前消息
  final Message message;

  /// 重新生成回调
  final VoidCallback? onRegenerate;

  /// 删除回调
  final VoidCallback? onDelete;

  /// 编辑回调
  final void Function(String newContent)? onEdit;

  /// 翻译按钮组件（外部传入，保持状态集中管理）
  final Widget translateWidget;

  /// 语音播放按钮组件（外部传入）
  final Widget ttsWidget;

  const MessageActionBar({
    super.key,
    required this.message,
    this.onRegenerate,
    this.onDelete,
    this.onEdit,
    required this.translateWidget,
    required this.ttsWidget,
  });

  @override
  State<MessageActionBar> createState() => _MessageActionBarState();
}

class _MessageActionBarState extends State<MessageActionBar> {
  bool _isEditing = false;
  late TextEditingController _editController;

  @override
  void initState() {
    super.initState();
    _editController = TextEditingController(text: widget.message.content);
  }

  @override
  void didUpdateWidget(MessageActionBar oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.message.content != widget.message.content) {
      _editController.text = widget.message.content;
    }
  }

  @override
  void dispose() {
    _editController.dispose();
    super.dispose();
  }

  // ========== 按钮交互 ==========

  /// 复制消息内容到剪贴板
  void _copyMessage() {
    Clipboard.setData(ClipboardData(text: widget.message.content));
    Fluttertoast.showToast(
      msg: '已复制',
      toastLength: Toast.LENGTH_SHORT,
    );
  }

  /// 删除确认对话框
  void _confirmDelete() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('删除消息'),
        content: const Text('确定要删除这条消息吗？'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('取消'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(ctx);
              widget.onDelete?.call();
            },
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('删除'),
          ),
        ],
      ),
    );
  }

  /// 系统分享
  void _shareMessage() {
    Share.share(widget.message.content, subject: '墨瞳 AI 回复');
  }

  /// 切换编辑模式
  void _toggleEdit() {
    setState(() {
      _isEditing = !_isEditing;
      if (_isEditing) {
        _editController.text = widget.message.content;
      }
    });
  }

  /// 提交编辑
  void _submitEdit() {
    final newContent = _editController.text.trim();
    if (newContent.isNotEmpty && newContent != widget.message.content) {
      widget.onEdit?.call(newContent);
    }
    setState(() => _isEditing = false);
  }

  // ========== 构建 ==========

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // 编辑模式：显示输入框 + 确认/取消按钮
        if (_isEditing) _buildEditMode(),

        // 正常模式：图标按钮行
        if (!_isEditing) _buildActionRow(),
      ],
    );
  }

  /// 正常模式下的按钮行
  Widget _buildActionRow() {
    return Padding(
      padding: const EdgeInsets.only(left: 4),
      child: Wrap(
        spacing: 4,
        crossAxisAlignment: WrapCrossAlignment.center,
        children: [
          _ActionIcon(
            icon: LucideIcons.copy,
            tooltip: '复制',
            onTap: _copyMessage,
          ),
          _ActionIcon(
            icon: LucideIcons.refreshCw,
            tooltip: '重新生成',
            onTap: widget.onRegenerate ?? () {},
          ),
          _ActionIcon(
            icon: LucideIcons.trash2,
            tooltip: '删除',
            onTap: _confirmDelete,
            color: Colors.red[400],
          ),
          _ActionIcon(
            icon: LucideIcons.share2,
            tooltip: '分享',
            onTap: _shareMessage,
          ),
          _ActionIcon(
            icon: LucideIcons.pencil,
            tooltip: '编辑',
            onTap: _toggleEdit,
          ),
          // 语音播放按钮
          widget.ttsWidget,
          const SizedBox(width: 4),
          // 翻译按钮
          widget.translateWidget,
        ],
      ),
    );
  }

  /// 编辑模式：文本输入框 + 操作按钮
  Widget _buildEditMode() {
    return Container(
      margin: const EdgeInsets.only(left: 4, top: 4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          TextField(
            controller: _editController,
            maxLines: 5,
            minLines: 1,
            autofocus: true,
            style: const TextStyle(fontSize: 14),
            decoration: InputDecoration(
              contentPadding:
                  const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
              ),
              hintText: '编辑消息...',
            ),
          ),
          const SizedBox(height: 6),
          Row(
            children: [
              TextButton(
                onPressed: _submitEdit,
                child: const Text('确认'),
              ),
              const SizedBox(width: 8),
              TextButton(
                onPressed: () => setState(() => _isEditing = false),
                style: TextButton.styleFrom(foregroundColor: Colors.grey),
                child: const Text('取消'),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

/// 单个操作图标按钮
class _ActionIcon extends StatelessWidget {
  final IconData icon;
  final String tooltip;
  final VoidCallback onTap;
  final Color? color;

  const _ActionIcon({
    required this.icon,
    required this.tooltip,
    required this.onTap,
    this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: tooltip,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(6),
            child: Icon(
              icon,
              size: 18,
              color: color ?? Colors.grey[600],
            ),
          ),
        ),
      ),
    );
  }
}