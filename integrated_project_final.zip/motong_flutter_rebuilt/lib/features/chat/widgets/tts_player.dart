import 'dart:io';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';
import 'package:path_provider/path_provider.dart';
'import network/api_client.dart';

/// TTS 语音播放组件
///
/// 点击触发 Cloudflare TTS 请求 → 缓存音频到临时文件 → 播放
/// 播放状态：loading → playing → done
class TtsPlayer {
  final ApiClient _apiClient;
  final AudioPlayer _audioPlayer = AudioPlayer();
  PlayerState _state = PlayerState.stopped;

  TtsPlayer({required ApiClient apiClient}) : _apiClient = apiClient;

  /// 当前是否正在播放
  bool get isPlaying => _state == PlayerState.playing;
  bool get isLoading => _state == PlayerState.disposed; // 用 disposed 暂代 loading

  /// 播放指定文本的语音
  /// [text] 要朗读的文本内容
  Future<void> speak(String text) async {
    if (text.isEmpty) return;

    try {
      // 请求 TTS 音频
      final audioBytes = await _apiClient.textToSpeech(text);

      // 写入临时文件
      final tempDir = await getTemporaryDirectory();
      final file = File('${tempDir.path}/tts_${DateTime.now().millisecondsSinceEpoch}.mp3');
      await file.writeAsBytes(audioBytes);

      // 播放音频
      await _audioPlayer.play(DeviceFileSource(file.path));
    } catch (e) {
      Fluttertoast.showToast(
        msg: '语音播放失败: $e',
        toastLength: Toast.LENGTH_SHORT,
      );
    }
  }

  /// 停止播放
  Future<void> stop() async {
    await _audioPlayer.stop();
  }

  /// 释放资源
  void dispose() {
    _audioPlayer.dispose();
  }
}

/// TTS 播放按钮 Widget
class TtsButton extends StatefulWidget {
  /// 要朗读的文本
  final String text;

  /// API 客户端实例（可选；模块 2 起从 ChatProvider 派生）
  final ApiClient? apiClient;

  /// 图标大小
  final double iconSize;

  const TtsButton({
    super.key,
    required this.text,
    this.apiClient,
    this.iconSize = 18,
  });

  @override
  State<TtsButton> createState() => _TtsButtonState();
}

class _TtsButtonState extends State<TtsButton> {
  final AudioPlayer _audioPlayer = AudioPlayer();
  bool _isLoading = false;
  bool _isPlaying = false;

  @override
  void initState() {
    super.initState();
    // 监听播放完成事件
    _audioPlayer.onPlayerComplete.listen((_) {
      if (mounted) {
        setState(() => _isPlaying = false);
      }
    });
  }

  Future<void> _speak() async {
    if (_isLoading || _isPlaying) {
      await _audioPlayer.stop();
      if (mounted) setState(() => _isPlaying = false);
      return;
    }
    if (widget.apiClient == null) {
      Fluttertoast.showToast(msg: '语音功能未配置 API');
      return;
    }
    setState(() => _isLoading = true);

    try {
      final audioBytes =
          await widget.apiClient!.textToSpeech(widget.text);
      final tempDir = await getTemporaryDirectory();
      final file = File(
          '${tempDir.path}/tts_${DateTime.now().millisecondsSinceEpoch}.mp3');
      await file.writeAsBytes(audioBytes);

      await _audioPlayer.play(DeviceFileSource(file.path));
      if (mounted) {
        setState(() {
          _isLoading = false;
          _isPlaying = true;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() => _isLoading = false);
        Fluttertoast.showToast(
          msg: '语音播放失败',
          toastLength: Toast.LENGTH_SHORT,
        );
      }
    }
  }

  @override
  void dispose() {
    _audioPlayer.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: _speak,
      child: _isLoading
          ? SizedBox(
              width: widget.iconSize,
              height: widget.iconSize,
              child: const CircularProgressIndicator(strokeWidth: 2),
            )
          : Icon(
              _isPlaying ? LucideIcons.square : LucideIcons.volume2,
              size: widget.iconSize,
              color: Colors.grey[600],
            ),
    );
  }
}