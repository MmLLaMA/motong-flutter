/// 聊天主界面（模块 2 集成版）
/// AppBar 显示助手头像 + 名称 + 模型名，点击可切换

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/providers/chat_provider.dart';
import '../../../core/providers/assistant_manager.dart';
import '../../../core/providers/provider_manager.dart';
import '../models/message.dart';
import '../widgets/message_action_bar.dart';
import '../widgets/message_bubble.dart';
import '../widgets/tts_player.dart';
import '../widgets/translate_button.dart';
import '../../../agents/pages/providers_page.dart';
import '../../../agents/pages/assistants_page.dart';
import '../../../settings/pages/settings_page.dart';
import '../../../core/widgets/custom_bottom_sheet.dart';

class ChatPage extends StatefulWidget {
  const ChatPage({super.key});

  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  final ScrollController _scrollController = ScrollController();
  final TextEditingController _inputController = TextEditingController();

  void _scrollToBottom({bool animated = true}) {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!_scrollController.hasClients) return;
      final max = _scrollController.position.maxScrollExtent;
      if (animated) {
        _scrollController.animateTo(
          max,
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOut,
        );
      } else {
        _scrollController.jumpTo(max);
      }
    });
  }

  @override
  void dispose() {
    _scrollController.dispose();
    _inputController.dispose();
    super.dispose();
  }

  Future<void> _sendMessage() async {
    final text = _inputController.text.trim();
    if (text.isEmpty) return;
    _inputController.clear();
    await context.read<ChatProvider>().sendMessage(text);
    _scrollToBottom();
  }

  @override
  Widget build(BuildContext context) {
    final assistantManager = context.watch<AssistantManager>();
    final current = assistantManager.currentAssistant;

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: GestureDetector(
          onTap: () => _showAssistantSwitcher(context),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(current?.emoji ?? '🤖', style: const TextStyle(fontSize: 22)),
              const SizedBox(width: 6),
              Text(current?.name ?? '墨瞳',
                  style: const TextStyle(fontSize: 16)),
              const SizedBox(width: 4),
              const Icon(Icons.keyboard_arrow_down, size: 16),
            ],
          ),
        ),
        elevation: 0,
        backgroundColor: Colors.white,
        foregroundColor: Colors.black87,
        actions: [
          PopupMenuButton<String>(
            onSelected: (v) {
              switch (v) {
                case 'providers':
                  Navigator.push(context,
                      MaterialPageRoute(builder: (_) => ProvidersPage()));
                  break;
                case 'assistants':
                  Navigator.push(context,
                      MaterialPageRoute(builder: (_) => AssistantsPage()));
                  break;
                case 'settings':
                  Navigator.push(context,
                      MaterialPageRoute(builder: (_) => SettingsPage()));
                  break;
                case 'clear':
                  _confirmClear(context);
                  break;
              }
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'assistants', child: Text('助手管理')),
              PopupMenuItem(value: 'providers', child: Text('服务商管理')),
              PopupMenuItem(value: 'settings', child: Text('设置')),
              PopupMenuDivider(),
              PopupMenuItem(value: 'clear', child: Text('清空对话')),
            ],
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: Consumer<ChatProvider>(
              builder: (context, chat, _) {
                if (chat.messages.isNotEmpty) _scrollToBottom();
                if (chat.messages.isEmpty) return const _EmptyChatPlaceholder();
                return ListView.builder(
                  controller: _scrollController,
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  itemCount: chat.messages.length,
                  itemBuilder: (context, index) {
                    final msg = chat.messages[index];
                    final actionBar = msg.role == MessageRole.assistant
                        ? _buildActionBar(context, msg, chat)
                        : null;
                    return MessageBubble(message: msg, actionBar: actionBar);
                  },
                );
              },
            ),
          ),
          const _LoadingIndicator(),
          _buildInputArea(),
        ],
      ),
    );
  }

  /// 显示助手切换面板
  void _showAssistantSwitcher(BuildContext context) {
    final am = context.read<AssistantManager>();
    CustomBottomSheet.show(
      context: context,
      title: '切换助手',
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: am.assistants
            .map(
              (a) => ListTile(
                leading: Text(a.emoji, style: const TextStyle(fontSize: 24)),
                title: Text(a.name),
                subtitle: Text(a.modelId, style: const TextStyle(fontSize: 12)),
                trailing: a.id == am.currentAssistantId
                    ? const Icon(Icons.check, color: Colors.blue)
                    : null,
                onTap: () {
                  context.read<ChatProvider>().switchAssistant(a.id);
                  Navigator.pop(context);
                },
              ),
            )
            .toList(),
      ),
    );
  }

  Widget _buildActionBar(BuildContext context, Message msg, ChatProvider provider) {
    final isTranslated = msg.originalContent != null;
    return MessageActionBar(
      message: msg,
      onRegenerate: () => provider.regenerateMessage(msg.id),
      onDelete: () => provider.deleteMessage(msg.id),
      onEdit: (newContent) => provider.editMessage(msg.id, newContent),
      ttsWidget: TtsButton(text: msg.content, iconSize: 18),
      translateWidget: TranslateButton(
        onTranslate: (targetLang) =>
            provider.translateMessage(msg.id, targetLang),
        isTranslated: isTranslated,
        onUndo: () => provider.undoTranslation(msg.id),
      ),
    );
  }

  Widget _buildInputArea() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.grey[50],
        border: Border(top: BorderSide(color: Colors.grey[200]!)),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      child: SafeArea(
        top: false,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Expanded(
              child: Container(
                constraints: const BoxConstraints(maxHeight: 120),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.grey[300]!),
                ),
                padding:
                    const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                child: TextField(
                  controller: _inputController,
                  maxLines: null,
                  textInputAction: TextInputAction.send,
                  onSubmitted: (_) => _sendMessage(),
                  decoration: const InputDecoration(
                    hintText: '说点什么吧...',
                    border: InputBorder.none,
                    isDense: true,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 8),
            GestureDetector(
              onTap: _sendMessage,
              child: Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: Colors.blue[600],
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.send, color: Colors.white, size: 20),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _confirmClear(BuildContext context) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('清空对话'),
        content: const Text('确定要清空当前对话的所有消息吗？'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx), child: const Text('取消')),
          TextButton(
            onPressed: () {
              Navigator.pop(ctx);
              context.read<ChatProvider>().clearMessages();
            },
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('清空'),
          ),
        ],
      ),
    );
  }
}

class _EmptyChatPlaceholder extends StatelessWidget {
  const _EmptyChatPlaceholder();
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.chat_bubble_outline, size: 64, color: Colors.grey[300]),
            const SizedBox(height: 16),
            Text('你好，我是墨瞳',
                style: TextStyle(
                    fontSize: 18,
                    color: Colors.grey[700],
                    fontWeight: FontWeight.w500)),
            const SizedBox(height: 8),
            Text('有什么想聊的？', style: TextStyle(fontSize: 14, color: Colors.grey[500])),
          ],
        ),
      ),
    );
  }
}

class _LoadingIndicator extends StatelessWidget {
  const _LoadingIndicator();
  @override
  Widget build(BuildContext context) {
    final isLoading = context.watch<ChatProvider>().isLoading;
    if (!isLoading) return const SizedBox.shrink();
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 4),
      alignment: Alignment.centerLeft,
      child: Padding(
        padding: const EdgeInsets.only(left: 20),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
              width: 14,
              height: 14,
              child: CircularProgressIndicator(
                strokeWidth: 2,
                color: Colors.blue[400],
              ),
            ),
            const SizedBox(width: 8),
            Text('墨瞳正在思考...',
                style: TextStyle(fontSize: 12, color: Colors.grey[500])),
          ],
        ),
      ),
    );
  }
}