/// 模块 2：多模型与助手系统 — 数据模型
/// LlmProvider / ModelInfo / Assistant / Conversation 四层模型

import 'package:uuid/uuid.dart';

// ==================== 大模型供应商 ====================

class LlmProvider {
  final String id;
  final String name;
  final String baseUrl;
  final String apiKey;
  final bool isBuiltin;
  final List<ModelInfo> models;
  final DateTime createdAt;

  LlmProvider({
    String? id,
    required this.name,
    required this.baseUrl,
    required this.apiKey,
    this.isBuiltin = false,
    List<ModelInfo>? models,
    DateTime? createdAt,
  })  : id = id ?? const Uuid().v4(),
        models = models ?? [],
        createdAt = createdAt ?? DateTime.now();

  factory LlmProvider.fromJson(Map<String, dynamic> json) {
    return LlmProvider(
      id: json['id'] as String,
      name: json['name'] as String,
      baseUrl: json['base_url'] as String,
      apiKey: json['api_key'] as String? ?? '',
      isBuiltin: json['is_builtin'] as bool? ?? false,
      models: (json['models'] as List<dynamic>?)
              ?.map((m) => ModelInfo.fromJson(m as Map<String, dynamic>))
              .toList() ??
          [],
      createdAt: json['created_at'] != null
          ? DateTime.parse(json['created_at'] as String)
          : DateTime.now(),
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'base_url': baseUrl,
        'api_key': apiKey,
        'is_builtin': isBuiltin,
        'models': models.map((m) => m.toJson()).toList(),
        'created_at': createdAt.toIso8601String(),
      };

  LlmProvider copyWith({
    String? id,
    String? name,
    String? baseUrl,
    String? apiKey,
    bool? isBuiltin,
    List<ModelInfo>? models,
    DateTime? createdAt,
  }) =>
      LlmProvider(
        id: id ?? this.id,
        name: name ?? this.name,
        baseUrl: baseUrl ?? this.baseUrl,
        apiKey: apiKey ?? this.apiKey,
        isBuiltin: isBuiltin ?? this.isBuiltin,
        models: models ?? this.models,
        createdAt: createdAt ?? this.createdAt,
      );
}

// ==================== 模型信息 ====================

class ModelInfo {
  final String id;
  final String displayName;
  final bool supportsVision;
  final bool supportsStreaming;
  final int maxTokens;

  ModelInfo({
    required this.id,
    required this.displayName,
    this.supportsVision = false,
    this.supportsStreaming = true,
    this.maxTokens = 4096,
  });

  factory ModelInfo.fromJson(Map<String, dynamic> json) {
    return ModelInfo(
      id: json['id'] as String,
      displayName: json['display_name'] as String,
      supportsVision: json['supports_vision'] as bool? ?? false,
      supportsStreaming: json['supports_streaming'] as bool? ?? true,
      maxTokens: json['max_tokens'] as int? ?? 4096,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'display_name': displayName,
        'supports_vision': supportsVision,
        'supports_streaming': supportsStreaming,
        'max_tokens': maxTokens,
      };

  ModelInfo copyWith({
    String? id,
    String? displayName,
    bool? supportsVision,
    bool? supportsStreaming,
    int? maxTokens,
  }) =>
      ModelInfo(
        id: id ?? this.id,
        displayName: displayName ?? this.displayName,
        supportsVision: supportsVision ?? this.supportsVision,
        supportsStreaming: supportsStreaming ?? this.supportsStreaming,
        maxTokens: maxTokens ?? this.maxTokens,
      );
}

// ==================== 助手 ====================

class Assistant {
  final String id;
  final String name;
  final String emoji;
  final String modelProviderId;
  final String modelId;
  final String systemPrompt;
  final bool isDefault;
  final List<Conversation> conversations;
  final int currentConversationIndex;
  final DateTime createdAt;

  Assistant({
    String? id,
    required this.name,
    this.emoji = '🤖',
    required this.modelProviderId,
    required this.modelId,
    this.systemPrompt = '',
    this.isDefault = false,
    List<Conversation>? conversations,
    this.currentConversationIndex = 0,
    DateTime? createdAt,
  })  : id = id ?? const Uuid().v4(),
        conversations = conversations ?? [
          Conversation(title: '新对话')
        ],
        createdAt = createdAt ?? DateTime.now();

  Conversation get currentConversation {
    if (conversations.isEmpty) {
      return Conversation(title: '新对话');
    }
    final idx = currentConversationIndex.clamp(0, conversations.length - 1);
    return conversations[idx];
  }

  factory Assistant.fromJson(Map<String, dynamic> json) {
    return Assistant(
      id: json['id'] as String,
      name: json['name'] as String,
      emoji: json['emoji'] as String? ?? '🤖',
      modelProviderId: json['model_provider_id'] as String,
      modelId: json['model_id'] as String,
      systemPrompt: json['system_prompt'] as String? ?? '',
      isDefault: json['is_default'] as bool? ?? false,
      conversations: (json['conversations'] as List<dynamic>?)
              ?.map(
                  (c) => Conversation.fromJson(c as Map<String, dynamic>))
              .toList() ??
          [],
      currentConversationIndex:
          json['current_conversation_index'] as int? ?? 0,
      createdAt: json['created_at'] != null
          ? DateTime.parse(json['created_at'] as String)
          : DateTime.now(),
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'emoji': emoji,
        'model_provider_id': modelProviderId,
        'model_id': modelId,
        'system_prompt': systemPrompt,
        'is_default': isDefault,
        'conversations':
            conversations.map((c) => c.toJson()).toList(),
        'current_conversation_index': currentConversationIndex,
        'created_at': createdAt.toIso8601String(),
      };

  Assistant copyWith({
    String? id,
    String? name,
    String? emoji,
    String? modelProviderId,
    String? modelId,
    String? systemPrompt,
    bool? isDefault,
    List<Conversation>? conversations,
    int? currentConversationIndex,
    DateTime? createdAt,
  }) =>
      Assistant(
        id: id ?? this.id,
        name: name ?? this.name,
        emoji: emoji ?? this.emoji,
        modelProviderId: modelProviderId ?? this.modelProviderId,
        modelId: modelId ?? this.modelId,
        systemPrompt: systemPrompt ?? this.systemPrompt,
        isDefault: isDefault ?? this.isDefault,
        conversations: conversations ?? this.conversations,
        currentConversationIndex:
            currentConversationIndex ?? this.currentConversationIndex,
        createdAt: createdAt ?? this.createdAt,
      );
}

// ==================== 对话 ====================

class Conversation {
  final String id;
  String title;
  final DateTime createdAt;
  DateTime updatedAt;
  String? lastExtractedMessageId;

  Conversation({
    String? id,
    required this.title,
    DateTime? createdAt,
    DateTime? updatedAt,
    this.lastExtractedMessageId,
  })  : id = id ?? const Uuid().v4(),
        createdAt = createdAt ?? DateTime.now(),
        updatedAt = updatedAt ?? DateTime.now();

  factory Conversation.fromJson(Map<String, dynamic> json) {
    return Conversation(
      id: json['id'] as String,
      title: json['title'] as String? ?? '新对话',
      createdAt: json['created_at'] != null
          ? DateTime.parse(json['created_at'] as String)
          : DateTime.now(),
      updatedAt: json['updated_at'] != null
          ? DateTime.parse(json['updated_at'] as String)
          : DateTime.now(),
      lastExtractedMessageId: json['last_extracted_message_id'] as String?,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'created_at': createdAt.toIso8601String(),
        'updated_at': updatedAt.toIso8601String(),
        'last_extracted_message_id': lastExtractedMessageId,
      };

  Conversation copyWith({
    String? id,
    String? title,
    DateTime? createdAt,
    DateTime? updatedAt,
    String? lastExtractedMessageId,
  }) =>
      Conversation(
        id: id ?? this.id,
        title: title ?? this.title,
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
        lastExtractedMessageId:
            lastExtractedMessageId ?? this.lastExtractedMessageId,
      );
}