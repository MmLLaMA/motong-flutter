/// 模块 2 — 服务商管理页
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';
'import providers/provider_manager.dart';
import '../models/provider.dart';

class ProvidersPage extends StatelessWidget {
  const ProvidersPage({super.key});

  @override
  Widget build(BuildContext context) {
    final manager = context.watch<ProviderManager>();
    return Scaffold(
      appBar: AppBar(title: const Text('服务商管理')),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showProviderEditor(context),
        child: const Icon(LucideIcons.plus),
      ),
      body: ListView.builder(
        padding: const EdgeInsets.symmetric(vertical: 8),
        itemCount: manager.providers.length,
        itemBuilder: (context, index) {
          final p = manager.providers[index];
          return _buildProviderCard(context, p);
        },
      ),
    );
  }

  Widget _buildProviderCard(BuildContext context, LlmProvider p) {
    final mgr = context.read<ProviderManager>();
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(p.isBuiltin ? LucideIcons.badgeCheck : LucideIcons.server),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    p.name,
                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                  ),
                ),
                if (p.isBuiltin)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(
                      color: Colors.blue[100],
                      borderRadius: BorderRadius.circular(4),
                    ),
                    child: const Text('内置', style: TextStyle(fontSize: 11)),
                  ),
              ],
            ),
            const SizedBox(height: 4),
            Text(p.baseUrl, style: TextStyle(fontSize: 12, color: Colors.grey[600])),
            const SizedBox(height: 8),
            Wrap(
              spacing: 4,
              runSpacing: 4,
              children: p.models
                  .map((m) => Chip(
                        label: Text(m.displayName, style: const TextStyle(fontSize: 11)),
                        padding: EdgeInsets.zero,
                      ))
                  .toList(),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                TextButton.icon(
                  icon: const Icon(LucideIcons.zap, size: 16),
                  label: const Text('测试连接'),
                  onPressed: () async {
                    final ok = await mgr.testProviderConnection(p.id);
                    if (context.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text(ok ? '连接成功' : '连接失败')),
                      );
                    }
                  },
                ),
                TextButton(
                  onPressed: () => _showProviderEditor(context, existing: p),
                  child: const Text('编辑'),
                ),
                if (!p.isBuiltin)
                  TextButton(
                    onPressed: () => _confirmDelete(context, p),
                    style: TextButton.styleFrom(foregroundColor: Colors.red),
                    child: const Text('删除'),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _confirmDelete(BuildContext context, LlmProvider p) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('删除供应商'),
        content: Text('确定要删除 "${p.name}" 吗？'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('取消')),
          TextButton(
            onPressed: () {
              Navigator.pop(ctx);
              context.read<ProviderManager>().deleteProvider(p.id);
            },
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('删除'),
          ),
        ],
      ),
    );
  }

  void _showProviderEditor(BuildContext context, {LlmProvider? existing}) {
    final nameCtrl = TextEditingController(text: existing?.name ?? '');
    final urlCtrl = TextEditingController(text: existing?.baseUrl ?? '');
    final keyCtrl = TextEditingController(text: existing?.apiKey ?? '');
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(existing == null ? '添加供应商' : '编辑供应商'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: nameCtrl, decoration: const InputDecoration(labelText: '名称')),
            TextField(controller: urlCtrl, decoration: const InputDecoration(labelText: 'API 地址')),
            TextField(controller: keyCtrl, decoration: const InputDecoration(labelText: 'API Key')),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('取消')),
          TextButton(
            onPressed: () {
              if (existing != null) {
                context.read<ProviderManager>().updateProvider(
                      existing.id,
                      existing.copyWith(
                        name: nameCtrl.text,
                        baseUrl: urlCtrl.text,
                        apiKey: keyCtrl.text,
                      ),
                    );
              } else {
                context.read<ProviderManager>().addProvider(
                      LlmProvider(
                        name: nameCtrl.text,
                        baseUrl: urlCtrl.text,
                        apiKey: keyCtrl.text,
                      ),
                    );
              }
              Navigator.pop(ctx);
            },
            child: const Text('保存'),
          ),
        ],
      ),
    );
  }
}