/// 模块 2 — 助手管理页
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';
import '../../../core/providers/assistant_manager.dart';
import '../../../core/providers/provider_manager.dart';
import '../models/provider.dart';

class AssistantsPage extends StatelessWidget {
  const AssistantsPage({super.key});

  @override
  Widget build(BuildContext context) {
    final manager = context.watch<AssistantManager>();
    return Scaffold(
      appBar: AppBar(title: const Text('助手管理')),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showAssistantEditor(context),
        child: const Icon(LucideIcons.plus),
      ),
      body: ListView.builder(
        padding: const EdgeInsets.symmetric(vertical: 8),
        itemCount: manager.assistants.length,
        itemBuilder: (context, index) {
          final a = manager.assistants[index];
          return _buildAssistantCard(context, a);
        },
      ),
    );
  }

  Widget _buildAssistantCard(BuildContext context, Assistant a) {
    final pm = context.watch<ProviderManager>();
    final provider = pm.getProvider(a.modelProviderId);
    final model = provider?.models
        .where((m) => m.id == a.modelId)
        .firstOrNull;
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      child: ListTile(
        leading: Text(a.emoji, style: const TextStyle(fontSize: 28)),
        title: Text(a.name),
        subtitle: Text(model?.displayName ?? a.modelId,
            style: TextStyle(fontSize: 12, color: Colors.grey[600])),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextButton(
              onPressed: () => _showAssistantEditor(context, existing: a),
              child: const Text('编辑'),
            ),
            if (!a.isDefault)
              IconButton(
                icon: const Icon(LucideIcons.trash, color: Colors.red),
                onPressed: () =>
                    context.read<AssistantManager>().deleteAssistant(a.id),
              ),
          ],
        ),
      ),
    );
  }

  void _showAssistantEditor(BuildContext context, {Assistant? existing}) {
    final nameCtrl = TextEditingController(text: existing?.name ?? '');
    final emojiCtrl = TextEditingController(text: existing?.emoji ?? '🤖');
    final promptCtrl =
        TextEditingController(text: existing?.systemPrompt ?? '');
    String selectedProviderId =
        existing?.modelProviderId ?? 'builtin-deepseek';
    String selectedModelId = existing?.modelId ?? 'deepseek-chat';

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setState) {
          final pm = context.watch<ProviderManager>();
          final provider =
              pm.getProvider(selectedProviderId) ?? pm.providers.first;
          return AlertDialog(
            title: Text(existing == null ? '创建助手' : '编辑助手'),
            content: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextField(
                    controller: emojiCtrl,
                    decoration: const InputDecoration(labelText: 'Emoji'),
                  ),
                  TextField(
                    controller: nameCtrl,
                    decoration: const InputDecoration(labelText: '名称'),
                  ),
                  DropdownButtonFormField<String>(
                    initialValue: selectedProviderId,
                    decoration: const InputDecoration(labelText: '供应商'),
                    items: pm.providers
                        .map((p) => DropdownMenuItem(
                              value: p.id,
                              child: Text(p.name),
                            ))
                        .toList(),
                    onChanged: (v) {
                      if (v == null) return;
                      setState(() {
                        selectedProviderId = v;
                        selectedModelId = pm
                                .getProvider(v)
                                ?.models
                                .first
                                .id ??
                            'deepseek-chat';
                      });
                    },
                  ),
                  DropdownButtonFormField<String>(
                    initialValue: selectedModelId,
                    decoration: const InputDecoration(labelText: '模型'),
                    items: provider.models
                        .map((m) => DropdownMenuItem(
                              value: m.id,
                              child: Text(m.displayName),
                            ))
                        .toList(),
                    onChanged: (v) => setState(() => selectedModelId = v ?? ''),
                  ),
                  TextField(
                    controller: promptCtrl,
                    maxLines: 3,
                    decoration:
                        const InputDecoration(labelText: '系统提示词'),
                  ),
                ],
              ),
            ),
            actions: [
              TextButton(
                  onPressed: () => Navigator.pop(ctx),
                  child: const Text('取消')),
              TextButton(
                onPressed: () {
                  if (existing != null) {
                    context.read<AssistantManager>().updateAssistant(
                          existing.id,
                          existing.copyWith(
                            name: nameCtrl.text,
                            emoji: emojiCtrl.text,
                            systemPrompt: promptCtrl.text,
                            modelProviderId: selectedProviderId,
                            modelId: selectedModelId,
                          ),
                        );
                  } else {
                    context.read<AssistantManager>().addAssistant(
                          Assistant(
                            name: nameCtrl.text,
                            emoji: emojiCtrl.text,
                            systemPrompt: promptCtrl.text,
                            modelProviderId: selectedProviderId,
                            modelId: selectedModelId,
                          ),
                        );
                  }
                  Navigator.pop(ctx);
                },
                child: const Text('保存'),
              ),
            ],
          );
        },
      ),
    );
  }
}

extension _FirstOrNull<E> on Iterable<E> {
  E? get firstOrNull => isEmpty ? null : first;
}