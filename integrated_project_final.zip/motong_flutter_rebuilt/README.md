# 墨瞳 · 聊天模块 1

Flutter 项目骨架 + 聊天界面核心交互，包含消息渲染、底部操作栏、TTS 语音播放和翻译功能。

## 目录结构

```
lib/
├── main.dart                                 # 启动入口
├── app.dart                                  # MaterialApp + Provider 配置
├── features/
│   └── chat/
│       ├── models/
│       │   └── message.dart                  # 消息数据模型
│       ├── pages/
│       │   └── chat_page.dart                # 聊天主界面
│       └── widgets/
│           ├── message_bubble.dart           # 消息气泡
│           ├── message_action_bar.dart       # 消息操作栏（7 按钮）
│           ├── tts_player.dart               # TTS 语音播放按钮
│           └── translate_button.dart         # 翻译按钮 + 语言选择
└── core/
    ├── providers/
    │   └── chat_provider.dart                # 聊天状态（消息/流式/CRUD）
    ├── network/
    │   └── api_client.dart                   # API 客户端（OpenAI + TTS）
    └── widgets/
        └── custom_bottom_sheet.dart          # 自定义底部面板
```

## 快速开始

```bash
# 安装依赖
flutter pub get

# 运行项目
flutter run
```

## pub 包依赖

| 包名 | 版本 | 用途 |
|---|---|---|
| `flutter` | sdk | Flutter 框架 |
| `flutter_localizations` | sdk | 本地化支持 |
| `lucide_icons_flutter` | ^1.1.0 | 图标库（Copy/RefreshCw/Trash2/Share2/Pencil/Volume2/Languages） |
| `http` | ^1.2.0 | HTTP 请求 |
| `uuid` | ^4.3.3 | 生成消息/对话唯一 ID |
| `path_provider` | ^2.1.2 | 获取临时目录存放 TTS 音频 |
| `audioplayers` | ^6.1.0 | 音频播放 |
| `provider` | ^6.1.1 | 状态管理 |
| `fluttertoast` | ^8.2.4 | 轻提示（"已复制"等） |
| `share_plus` | ^7.2.1 | 系统分享面板 |
| `intl` | ^0.19.0 | 日期/语言格式化 |

## 已实现功能

| 功能 | 状态 | 说明 |
|---|---|---|
| 消息模型（UUID/角色/状态/parentMessageId） | ✅ 完整 | 含 copyWith、JSON 序列化 |
| 消息列表渲染（用户右对齐/AI 左对齐） | ✅ 完整 | MessageBubble 组件 |
| 流式输出（SSE） | ✅ 完整 | chatCompletionStream 逐 token 回调 |
| 自动滚动到底部 | ✅ 完整 | ListView + ScrollController |
| 复制按钮 | ✅ 完整 | Clipboard + Toast |
| 重新生成按钮 | ✅ 完整 | 通过 parentMessageId 找用户消息重新请求 |
| 删除按钮 | ✅ 完整 | 确认弹窗后删除 |
| 分享按钮 | ✅ 完整 | share_plus 系统分享 |
| 编辑按钮 | ✅ 完整 | 切换为 TextField 编辑模式 |
| TTS 语音按钮 | ✅ 完整 | Cloudflare TTS + 缓存到 temp + audioplayers |
| 翻译按钮 + 撤销 | ✅ 完整 | 4 种语言、原地替换、originalContent 撤销 |
| 自定义 BottomSheet | ✅ 完整 | CustomBottomSheet + 路由动画 |
| ChatProvider 状态管理 | ✅ 完整 | ChangeNotifier + Provider |

## 待后续模块补齐

| 功能 | 状态 | 说明 |
|---|---|---|
| Drift 数据库持久化 | ⏳ 后续模块 | 当前消息仅在内存中，刷新即失 |
| API Key / BaseURL 设置页 | ⏳ settings 模块 | 当前为硬编码占位 `sk-your-api-key-here` |
| Markdown 代码块渲染 | ⏳ 后续模块 | 当前 SelectableText 仅支持纯文本 |
| 多 Agent 支持 | ⏳ agents 模块 | 当前只有单一 ChatProvider |
| 记忆/上下文检索 | ⏳ memory 模块 | 当前只取最近 20 条消息 |
| 无障碍/语音输入 | ⏳ accessibility 模块 | |
| 多端同步 | ⏳ sync 模块 | |

## API 配置

修改 `lib/app.dart` 中的 ApiClient 配置：

```dart
static final ApiClient _apiClient = ApiClient(
  baseUrl: 'https://api.openai.com',       // 替换为你的 BaseURL
  apiKey: 'sk-your-api-key-here',          // 替换为你的 API Key
);
```

TTS 服务地址在 `lib/core/network/api_client.dart` 中默认为 `https://motong.2807118872.workers.dev`（Cloudflare Workers AI TTS）。